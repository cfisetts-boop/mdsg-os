'use client'

import { useState, useEffect, useCallback } from 'react'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
)

const STAGE_COLORS = {
  'Bid':           { bg: '#EEEDFE', text: '#3C3489' },
  'Awarded':       { bg: '#EAF3DE', text: '#3B6D11' },
  'Shop Drawings': { bg: '#FAEEDA', text: '#633806' },
  'Ordered':       { bg: '#E6F1FB', text: '#0C447C' },
  'Delivered':     { bg: '#E1F5EE', text: '#085041' },
  'Installed':     { bg: '#EAF3DE', text: '#27500A' },
  'Lost':          { bg: '#FCEBEB', text: '#A32D2D' },
}

const STAGES = ['Bid', 'Awarded', 'Shop Drawings', 'Ordered', 'Delivered', 'Installed']

const fmt = (n) => n ? '$' + Math.round(n).toLocaleString() : '—'
const fmtPct = (n) => n ? (n * 100).toFixed(1) + '%' : '—'

export default function Home() {
  const [jobs, setJobs] = useState([])
  const [view, setView] = useState('dashboard')
  const [selectedJob, setSelectedJob] = useState(null)
  const [loading, setLoading] = useState(true)
  const [showNewJob, setShowNewJob] = useState(false)
  const [newJob, setNewJob] = useState({ name: '', gc_name: '', address: '', city: 'Denver', state: 'CO', owner: 'Cole', stage: 'Bid', manufacturer: 'TBD' })
  const [quoteUploading, setQuoteUploading] = useState(false)
  const [quoteResult, setQuoteResult] = useState(null)
  const [reminders, setReminders] = useState([])
  const [proposalSender, setProposalSender] = useState('Cole')
  const [proposalNotes, setProposalNotes] = useState('')
  const [proposalLoading, setProposalLoading] = useState(false)
  const [stageUpdating, setStageUpdating] = useState(false)
  const [showReminderForm, setShowReminderForm] = useState(false)
  const [newReminder, setNewReminder] = useState({ due_date: '', reminder_type: 'Bid Follow-up', message: '', assigned_to: 'Cole' })

  const loadJobs = useCallback(async () => {
    setLoading(true)
    const { data } = await supabase
      .from('jobs')
      .select('*, unit_types(*), activity_log(*), reminders(*)')
      .order('created_at', { ascending: false })
    if (data) setJobs(data)
    setLoading(false)
  }, [])

  const loadReminders = useCallback(async () => {
    const res = await fetch('/api/reminders')
    const data = await res.json()
    if (Array.isArray(data)) setReminders(data)
  }, [])

  useEffect(() => {
    loadJobs()
    loadReminders()
  }, [loadJobs, loadReminders])

  async function createJob() {
    if (!newJob.name) return alert('Job name is required')
    const { data, error } = await supabase.from('jobs').insert(newJob).select().single()
    if (error) return alert('Error: ' + error.message)
    await supabase.from('activity_log').insert({ job_id: data.id, user_name: newJob.owner, action: `Job created — ${newJob.name}` })
    setShowNewJob(false)
    setNewJob({ name: '', gc_name: '', address: '', city: 'Denver', state: 'CO', owner: 'Cole', stage: 'Bid', manufacturer: 'TBD' })
    loadJobs()
  }

  async function handleQuoteUpload(e) {
    const file = e.target.files[0]
    if (!file || !file.name.endsWith('.pdf')) return alert('Please select a PDF file')
    if (!selectedJob) return alert('Select a job first')
    setQuoteUploading(true)
    setQuoteResult(null)
    const arrayBuffer = await file.arrayBuffer()
    const response = await fetch('/api/parse-quote', {
      method: 'POST',
      headers: { 'x-job-id': selectedJob.id, 'x-file-name': file.name, 'Content-Type': 'application/pdf' },
      body: arrayBuffer,
    })
    const result = await response.json()
    setQuoteUploading(false)
    if (result.success) {
      setQuoteResult(result)
      loadJobs()
      // Refresh selected job
      const { data } = await supabase.from('jobs').select('*, unit_types(*), activity_log(*), reminders(*)').eq('id', selectedJob.id).single()
      if (data) setSelectedJob(data)
    } else {
      alert('Error parsing quote: ' + (result.error || 'Unknown error'))
    }
  }

  async function generateProposal() {
    if (!selectedJob) return
    setProposalLoading(true)
    try {
      const response = await fetch('/api/generate-proposal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jobId: selectedJob.id,
          sender: proposalSender,
          notes: proposalNotes,
        }),
      })
      if (!response.ok) {
        const err = await response.json()
        throw new Error(err.error || 'Failed to generate proposal')
      }
      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `MDSG-Proposal-${selectedJob.name.replace(/[^a-z0-9]/gi, '-')}.pdf`
      a.click()
      URL.revokeObjectURL(url)
      loadJobs()
      const { data } = await supabase.from('jobs').select('*, unit_types(*), activity_log(*), reminders(*)').eq('id', selectedJob.id).single()
      if (data) setSelectedJob(data)
    } catch (err) {
      alert('Error generating proposal: ' + err.message)
    }
    setProposalLoading(false)
  }

  async function updateStage(newStage) {
    if (!selectedJob || stageUpdating) return
    setStageUpdating(true)
    const response = await fetch('/api/update-stage', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobId: selectedJob.id, stage: newStage, user: 'Cole' }),
    })
    const result = await response.json()
    if (result.success) {
      setSelectedJob(prev => ({ ...prev, stage: newStage }))
      loadJobs()
      loadReminders()
    } else {
      alert('Error updating stage: ' + result.error)
    }
    setStageUpdating(false)
  }

  async function completeReminder(id) {
    await fetch('/api/reminders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'complete', id }),
    })
    loadReminders()
  }

  async function createReminder() {
    if (!newReminder.due_date || !newReminder.message) return alert('Date and message required')
    await fetch('/api/reminders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'create', job_id: selectedJob?.id, ...newReminder }),
    })
    setShowReminderForm(false)
    setNewReminder({ due_date: '', reminder_type: 'Bid Follow-up', message: '', assigned_to: 'Cole' })
    loadReminders()
  }

  const pipelineValue = jobs.reduce((s, j) => s + (j.bid_value || 0), 0)
  const activeBids = jobs.filter(j => j.stage === 'Bid').length
  const awardedValue = jobs.filter(j => !['Bid', 'Lost'].includes(j.stage)).reduce((s, j) => s + (j.bid_value || 0), 0)
  const avgMargin = jobs.filter(j => j.gross_margin_pct > 0).reduce((s, j, _, arr) => s + j.gross_margin_pct / arr.length, 0)
  const overdueReminders = reminders.filter(r => r.due_date <= new Date().toISOString().split('T')[0])

  const navItem = (id, label, current) => (
    <div onClick={() => { setView(id); if (id !== 'job-detail') setSelectedJob(null) }}
      style={{ padding: '8px 16px', cursor: 'pointer', fontSize: 13,
        color: current === id ? '#1a1a1a' : '#666',
        background: current === id ? '#f5f5f3' : 'transparent',
        borderLeft: current === id ? '2px solid #3C3489' : '2px solid transparent',
        fontWeight: current === id ? 500 : 400 }}>
      {label}
    </div>
  )

  return (
    <div style={{ display: 'flex', height: '100vh', fontFamily: 'system-ui, sans-serif', fontSize: 14, background: '#f5f5f3' }}>

      {/* Sidebar */}
      <div style={{ width: 200, background: '#fff', borderRight: '0.5px solid #e5e5e0', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: 16, borderBottom: '0.5px solid #e5e5e0' }}>
          <div style={{ fontWeight: 600, fontSize: 13 }}>MDSG OS</div>
          <div style={{ fontSize: 11, color: '#888', marginTop: 2 }}>Manufacturer Direct Sales</div>
        </div>
        <div style={{ padding: '8px 0', flex: 1 }}>
          {navItem('dashboard', 'Dashboard', view)}
          {navItem('jobs', 'Jobs', view)}
          {navItem('takeoff', 'Upload Quote', view)}
          {navItem('reminders', `Reminders${reminders.length > 0 ? ` (${reminders.length})` : ''}`, view)}
        </div>
        <div style={{ padding: '12px 16px', borderTop: '0.5px solid #e5e5e0' }}>
          <div style={{ fontWeight: 500, fontSize: 12 }}>Cole Isetts</div>
          <div style={{ color: '#888', fontSize: 11 }}>Sales · Aurora, CO</div>
        </div>
      </div>

      {/* Main */}
      <div style={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '12px 24px', background: '#fff', borderBottom: '0.5px solid #e5e5e0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontWeight: 500, fontSize: 16 }}>
            {view === 'dashboard' && 'Dashboard'}
            {view === 'jobs' && 'Jobs'}
            {view === 'takeoff' && 'Upload Manufacturer Quote'}
            {view === 'reminders' && 'Reminders'}
            {view === 'job-detail' && selectedJob?.name}
          </div>
          <button onClick={() => setShowNewJob(true)}
            style={{ padding: '6px 14px', fontSize: 12, background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer' }}>
            + New Job
          </button>
        </div>

        <div style={{ padding: 24, flex: 1 }}>

          {/* ── DASHBOARD ── */}
          {view === 'dashboard' && (
            <div>
              {overdueReminders.length > 0 && (
                <div style={{ background: '#FAEEDA', border: '0.5px solid #EF9F27', borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontSize: 12, color: '#633806' }}>
                  ⚑ {overdueReminders.length} reminder{overdueReminders.length > 1 ? 's' : ''} due today or overdue —{' '}
                  <span onClick={() => setView('reminders')} style={{ textDecoration: 'underline', cursor: 'pointer' }}>view all</span>
                </div>
              )}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 24 }}>
                {[
                  { label: 'Pipeline Value', value: fmt(pipelineValue), sub: `${jobs.length} total jobs` },
                  { label: 'Active Bids', value: activeBids, sub: 'in bid stage' },
                  { label: 'Awarded Value', value: fmt(awardedValue), sub: 'ex. bids & lost' },
                  { label: 'Avg Margin', value: fmtPct(avgMargin), sub: 'across priced jobs' },
                ].map(m => (
                  <div key={m.label} style={{ background: '#f5f5f3', borderRadius: 8, padding: 14 }}>
                    <div style={{ fontSize: 11, color: '#888', fontWeight: 500, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>{m.label}</div>
                    <div style={{ fontSize: 22, fontWeight: 500 }}>{loading ? '—' : m.value}</div>
                    <div style={{ fontSize: 11, color: '#888', marginTop: 4 }}>{m.sub}</div>
                  </div>
                ))}
              </div>
              <div style={{ marginBottom: 8, fontWeight: 500, fontSize: 13 }}>Job Pipeline</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6,1fr)', gap: 8 }}>
                {STAGES.map(stage => (
                  <div key={stage} style={{ background: '#f5f5f3', borderRadius: 8, padding: 10, minHeight: 80 }}>
                    <div style={{ fontSize: 10, fontWeight: 500, color: '#888', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8, display: 'flex', justifyContent: 'space-between' }}>
                      {stage} <span style={{ background: '#fff', borderRadius: 10, padding: '1px 6px', fontSize: 10 }}>{jobs.filter(j => j.stage === stage).length}</span>
                    </div>
                    {jobs.filter(j => j.stage === stage).map(job => (
                      <div key={job.id} onClick={() => { setSelectedJob(job); setView('job-detail') }}
                        style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 6, padding: 10, marginBottom: 6, cursor: 'pointer' }}>
                        <div style={{ fontWeight: 500, fontSize: 12 }}>{job.name}</div>
                        <div style={{ fontSize: 11, color: '#888' }}>{job.gc_name || '—'}</div>
                        <div style={{ fontSize: 12, fontWeight: 500, color: '#3C3489', marginTop: 4 }}>{fmt(job.bid_value)}</div>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── JOBS LIST ── */}
          {view === 'jobs' && (
            <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead>
                  <tr style={{ background: '#f5f5f3' }}>
                    {['Project', 'GC', 'Stage', 'Manufacturer', 'Cabinets', 'Bid Value', 'Margin', 'Owner'].map(h => (
                      <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 500, color: '#888', borderBottom: '0.5px solid #e5e5e0', fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.4 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr><td colSpan={8} style={{ padding: 24, textAlign: 'center', color: '#888' }}>Loading...</td></tr>
                  ) : jobs.map(job => {
                    const colors = STAGE_COLORS[job.stage] || STAGE_COLORS['Bid']
                    return (
                      <tr key={job.id} onClick={() => { setSelectedJob(job); setView('job-detail') }}
                        style={{ cursor: 'pointer', borderBottom: '0.5px solid #f0f0ec' }}
                        onMouseEnter={e => e.currentTarget.style.background = '#fafaf8'}
                        onMouseLeave={e => e.currentTarget.style.background = ''}>
                        <td style={{ padding: '10px 14px', fontWeight: 500 }}>{job.name}</td>
                        <td style={{ padding: '10px 14px', color: '#555' }}>{job.gc_name || '—'}</td>
                        <td style={{ padding: '10px 14px' }}>
                          <span style={{ background: colors.bg, color: colors.text, borderRadius: 10, padding: '2px 8px', fontSize: 10, fontWeight: 500 }}>{job.stage}</span>
                        </td>
                        <td style={{ padding: '10px 14px', color: '#555' }}>{job.manufacturer}</td>
                        <td style={{ padding: '10px 14px', color: '#555' }}>{job.total_cabinet_count || '—'}</td>
                        <td style={{ padding: '10px 14px', fontWeight: 500 }}>{fmt(job.bid_value)}</td>
                        <td style={{ padding: '10px 14px', color: job.gross_margin_pct >= 0.25 ? '#3B6D11' : '#854F0B', fontWeight: 500 }}>{fmtPct(job.gross_margin_pct)}</td>
                        <td style={{ padding: '10px 14px', color: '#555' }}>{job.owner}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* ── JOB DETAIL ── */}
          {view === 'job-detail' && selectedJob && (
            <div>
              <div onClick={() => setView('jobs')} style={{ fontSize: 12, color: '#888', marginBottom: 16, cursor: 'pointer' }}>
                ← <span style={{ color: '#3C3489' }}>Jobs</span> / {selectedJob.name}
              </div>

              {/* Stage updater */}
              <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 16, marginBottom: 16 }}>
                <div style={{ fontSize: 12, fontWeight: 500, marginBottom: 10 }}>Pipeline Stage</div>
                <div style={{ display: 'flex', gap: 6 }}>
                  {STAGES.map(stage => {
                    const colors = STAGE_COLORS[stage]
                    const isCurrent = selectedJob.stage === stage
                    return (
                      <button key={stage} onClick={() => updateStage(stage)} disabled={stageUpdating}
                        style={{ padding: '6px 12px', fontSize: 11, borderRadius: 6, cursor: 'pointer', fontWeight: isCurrent ? 600 : 400,
                          background: isCurrent ? colors.bg : '#f5f5f3',
                          color: isCurrent ? colors.text : '#888',
                          border: isCurrent ? `1.5px solid ${colors.text}` : '0.5px solid #ddd' }}>
                        {stage}
                      </button>
                    )
                  })}
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div>
                  {/* Job info */}
                  <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 20, marginBottom: 16 }}>
                    <div style={{ fontWeight: 500, marginBottom: 16 }}>{selectedJob.name}</div>
                    {[
                      ['General Contractor', selectedJob.gc_name],
                      ['Address', [selectedJob.address, selectedJob.city, selectedJob.state, selectedJob.zip].filter(Boolean).join(', ')],
                      ['Manufacturer', selectedJob.manufacturer],
                      ['Quote #', selectedJob.manufacturer_quote_number],
                      ['Door Style', selectedJob.door_style],
                      ['Finish', selectedJob.finish_color],
                      ['Total Units', selectedJob.total_residential_units],
                      ['Total Cabinets', selectedJob.total_cabinet_count],
                      ['Bid Due', selectedJob.bid_due_date],
                      ['Owner', selectedJob.owner],
                    ].filter(([, v]) => v).map(([label, value]) => (
                      <div key={label} style={{ marginBottom: 10 }}>
                        <div style={{ fontSize: 10, color: '#888', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 2 }}>{label}</div>
                        <div style={{ fontSize: 13 }}>{value}</div>
                      </div>
                    ))}
                  </div>

                  {/* Upload quote */}
                  <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 20, marginBottom: 16 }}>
                    <div style={{ fontWeight: 500, marginBottom: 12 }}>Upload Manufacturer Quote PDF</div>
                    <label style={{ display: 'block', border: '1.5px dashed #ccc', borderRadius: 8, padding: 20, textAlign: 'center', cursor: 'pointer', background: '#fafaf8' }}>
                      <div style={{ color: '#555', fontSize: 13 }}>{quoteUploading ? 'Parsing with AI...' : 'Click to upload PDF quote'}</div>
                      <div style={{ color: '#999', fontSize: 11, marginTop: 4 }}>Leedo · Skyline · SMART · Ukon</div>
                      <input type="file" accept=".pdf" onChange={handleQuoteUpload} style={{ display: 'none' }} disabled={quoteUploading} />
                    </label>
                    {quoteResult && (
                      <div style={{ marginTop: 12, padding: 12, background: '#EAF3DE', borderRadius: 8, fontSize: 12 }}>
                        <div style={{ fontWeight: 500, color: '#3B6D11', marginBottom: 4 }}>Quote parsed successfully</div>
                        <div>Manufacturer: {quoteResult.summary.manufacturer}</div>
                        <div>Unit types: {quoteResult.summary.unit_type_count} · Cabinets: {quoteResult.summary.total_cabinets.toLocaleString()}</div>
                        <div style={{ fontWeight: 500 }}>Grand total: {fmt(quoteResult.summary.grand_total)}</div>
                      </div>
                    )}
                  </div>

                  {/* Proposal generator */}
                  <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 20 }}>
                    <div style={{ fontWeight: 500, marginBottom: 12 }}>Generate Proposal PDF</div>
                    <div style={{ marginBottom: 12 }}>
                      <label style={{ fontSize: 11, color: '#888', display: 'block', marginBottom: 4 }}>SENDER</label>
                      <select value={proposalSender} onChange={e => setProposalSender(e.target.value)}
                        style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }}>
                        <option>Cole</option><option>Pam</option><option>Blake</option>
                      </select>
                    </div>
                    <div style={{ marginBottom: 16 }}>
                      <label style={{ fontSize: 11, color: '#888', display: 'block', marginBottom: 4 }}>NOTES (optional)</label>
                      <textarea value={proposalNotes} onChange={e => setProposalNotes(e.target.value)}
                        placeholder="Any additional notes to include in the proposal..."
                        style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 12, height: 60, resize: 'vertical' }} />
                    </div>
                    <button onClick={generateProposal} disabled={proposalLoading}
                      style={{ width: '100%', padding: '10px', background: proposalLoading ? '#888' : '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: proposalLoading ? 'default' : 'pointer', fontSize: 13, fontWeight: 500 }}>
                      {proposalLoading ? 'Generating PDF...' : 'Generate & Download Proposal PDF'}
                    </button>
                  </div>
                </div>

                <div>
                  {/* Pricing */}
                  <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 20, marginBottom: 16 }}>
                    <div style={{ fontWeight: 500, marginBottom: 16 }}>Pricing Summary</div>
                    {[
                      ['Manufacturer Gross', selectedJob.manufacturer_gross_cost],
                      ['Freight', selectedJob.freight_cost],
                    ].map(([label, value]) => (
                      <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: 13, borderBottom: '0.5px solid #f0f0ec' }}>
                        <span style={{ color: '#555' }}>{label}</span>
                        <span style={{ fontWeight: 500 }}>{fmt(value)}</span>
                      </div>
                    ))}
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: 13, borderBottom: '0.5px solid #f0f0ec', color: '#3B6D11' }}>
                      <span>Dealer Discount ({((selectedJob.dealer_discount_pct || 0.05) * 100).toFixed(0)}%)</span>
                      <span style={{ fontWeight: 500 }}>− {fmt((selectedJob.manufacturer_gross_cost || 0) * (selectedJob.dealer_discount_pct || 0.05))}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: 13, borderBottom: '0.5px solid #f0f0ec' }}>
                      <span style={{ color: '#555' }}>Markup ({selectedJob.markup_multiplier || 1.34}×)</span>
                      <span style={{ fontWeight: 500 }}>applied</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0 0', fontSize: 16, fontWeight: 500 }}>
                      <span>Bid to GC</span>
                      <span style={{ color: '#3C3489' }}>{fmt(selectedJob.bid_value)}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: 12 }}>
                      <span style={{ color: '#888' }}>Gross Margin</span>
                      <span style={{ color: (selectedJob.gross_margin_pct || 0) >= 0.25 ? '#3B6D11' : '#854F0B', fontWeight: 500 }}>{fmtPct(selectedJob.gross_margin_pct)}</span>
                    </div>
                  </div>

                  {/* Unit types */}
                  {selectedJob.unit_types && selectedJob.unit_types.length > 0 && (
                    <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 20, marginBottom: 16 }}>
                      <div style={{ fontWeight: 500, marginBottom: 12 }}>Unit Types</div>
                      {selectedJob.unit_types.sort((a, b) => a.sort_order - b.sort_order).map(ut => (
                        <div key={ut.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: 12, borderBottom: '0.5px solid #f0f0ec' }}>
                          <span>{ut.unit_type_name}</span>
                          <span style={{ color: '#888' }}>{ut.cabinet_count} cabs · {fmt(ut.manufacturer_price)}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Reminders for this job */}
                  <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 20, marginBottom: 16 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                      <div style={{ fontWeight: 500 }}>Reminders</div>
                      <button onClick={() => setShowReminderForm(true)}
                        style={{ fontSize: 11, padding: '4px 10px', background: 'transparent', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer' }}>+ Add</button>
                    </div>
                    {showReminderForm && (
                      <div style={{ background: '#f5f5f3', borderRadius: 8, padding: 12, marginBottom: 12 }}>
                        <input type="date" value={newReminder.due_date} onChange={e => setNewReminder(p => ({ ...p, due_date: e.target.value }))}
                          style={{ width: '100%', padding: '6px 8px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 12, marginBottom: 8 }} />
                        <select value={newReminder.reminder_type} onChange={e => setNewReminder(p => ({ ...p, reminder_type: e.target.value }))}
                          style={{ width: '100%', padding: '6px 8px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 12, marginBottom: 8 }}>
                          <option>Bid Follow-up</option><option>Bid Deadline</option><option>Delivery Check</option><option>Payment</option><option>General</option>
                        </select>
                        <input placeholder="Message..." value={newReminder.message} onChange={e => setNewReminder(p => ({ ...p, message: e.target.value }))}
                          style={{ width: '100%', padding: '6px 8px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 12, marginBottom: 8 }} />
                        <div style={{ display: 'flex', gap: 6 }}>
                          <button onClick={createReminder} style={{ flex: 1, padding: '6px', background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12 }}>Save</button>
                          <button onClick={() => setShowReminderForm(false)} style={{ flex: 1, padding: '6px', background: '#f5f5f3', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer', fontSize: 12 }}>Cancel</button>
                        </div>
                      </div>
                    )}
                    {(selectedJob.reminders || []).filter(r => !r.completed).map(r => (
                      <div key={r.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0', fontSize: 12, borderBottom: '0.5px solid #f0f0ec' }}>
                        <div>
                          <div>{r.message}</div>
                          <div style={{ color: '#888', fontSize: 11 }}>{r.due_date} · {r.reminder_type}</div>
                        </div>
                        <button onClick={() => completeReminder(r.id)} style={{ fontSize: 10, padding: '3px 8px', background: '#EAF3DE', color: '#3B6D11', border: 'none', borderRadius: 6, cursor: 'pointer' }}>Done</button>
                      </div>
                    ))}
                    {(selectedJob.reminders || []).filter(r => !r.completed).length === 0 && !showReminderForm && (
                      <div style={{ color: '#888', fontSize: 12 }}>No open reminders</div>
                    )}
                  </div>

                  {/* Activity log */}
                  <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 20 }}>
                    <div style={{ fontWeight: 500, marginBottom: 12 }}>Activity Log</div>
                    {(selectedJob.activity_log || []).sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 8).map(log => (
                      <div key={log.id} style={{ paddingBottom: 10, marginBottom: 10, borderBottom: '0.5px solid #f0f0ec', fontSize: 12 }}>
                        <div>{log.action}</div>
                        <div style={{ color: '#888', fontSize: 11, marginTop: 2 }}>{log.user_name} · {new Date(log.created_at).toLocaleDateString()}</div>
                      </div>
                    ))}
                    {(selectedJob.activity_log || []).length === 0 && <div style={{ color: '#888', fontSize: 12 }}>No activity yet</div>}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── UPLOAD QUOTE ── */}
          {view === 'takeoff' && (
            <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 32, textAlign: 'center', maxWidth: 500, margin: '0 auto' }}>
              <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 8 }}>Upload Manufacturer Quote PDF</div>
              <div style={{ fontSize: 12, color: '#888', marginBottom: 24 }}>Select a job, then upload the PDF. Claude extracts all unit types, SKUs, and pricing automatically.</div>
              <div style={{ marginBottom: 16 }}>
                <select onChange={e => setSelectedJob(jobs.find(j => j.id === e.target.value))}
                  style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }}>
                  <option value="">Choose a job...</option>
                  {jobs.map(j => <option key={j.id} value={j.id}>{j.name}</option>)}
                </select>
              </div>
              {selectedJob && (
                <label style={{ display: 'block', border: '1.5px dashed #ccc', borderRadius: 8, padding: 32, cursor: 'pointer', background: '#fafaf8' }}>
                  <div style={{ fontSize: 13, color: '#555' }}>{quoteUploading ? 'AI is parsing your quote...' : 'Drop PDF here or click to upload'}</div>
                  <div style={{ fontSize: 11, color: '#999', marginTop: 4 }}>Leedo · Skyline · SMART · Ukon</div>
                  <input type="file" accept=".pdf" onChange={handleQuoteUpload} style={{ display: 'none' }} disabled={quoteUploading} />
                </label>
              )}
              {quoteResult && (
                <div style={{ marginTop: 16, padding: 16, background: '#EAF3DE', borderRadius: 8, textAlign: 'left', fontSize: 12 }}>
                  <div style={{ fontWeight: 500, color: '#3B6D11', marginBottom: 8 }}>Parsed successfully</div>
                  <div>Manufacturer: {quoteResult.summary.manufacturer} · Quote #: {quoteResult.summary.quote_number}</div>
                  <div>Unit types: {quoteResult.summary.unit_type_count} · Cabinets: {quoteResult.summary.total_cabinets.toLocaleString()}</div>
                  <div style={{ fontWeight: 500 }}>Grand total: {fmt(quoteResult.summary.grand_total)}</div>
                </div>
              )}
            </div>
          )}

          {/* ── REMINDERS ── */}
          {view === 'reminders' && (
            <div>
              <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, overflow: 'hidden' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                  <thead>
                    <tr style={{ background: '#f5f5f3' }}>
                      {['Due Date', 'Job', 'Type', 'Message', 'Assigned To', ''].map(h => (
                        <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 500, color: '#888', borderBottom: '0.5px solid #e5e5e0', fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.4 }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {reminders.length === 0 ? (
                      <tr><td colSpan={6} style={{ padding: 24, textAlign: 'center', color: '#888' }}>No upcoming reminders</td></tr>
                    ) : reminders.map(r => {
                      const isOverdue = r.due_date <= new Date().toISOString().split('T')[0]
                      return (
                        <tr key={r.id} style={{ borderBottom: '0.5px solid #f0f0ec', background: isOverdue ? '#FCEBEB' : '' }}>
                          <td style={{ padding: '10px 14px', fontWeight: 500, color: isOverdue ? '#A32D2D' : '#333' }}>{r.due_date}</td>
                          <td style={{ padding: '10px 14px' }}>{r.jobs?.name || '—'}</td>
                          <td style={{ padding: '10px 14px', color: '#555' }}>{r.reminder_type}</td>
                          <td style={{ padding: '10px 14px', color: '#555' }}>{r.message}</td>
                          <td style={{ padding: '10px 14px', color: '#555' }}>{r.assigned_to}</td>
                          <td style={{ padding: '10px 14px' }}>
                            <button onClick={() => completeReminder(r.id)}
                              style={{ fontSize: 10, padding: '3px 10px', background: '#EAF3DE', color: '#3B6D11', border: 'none', borderRadius: 6, cursor: 'pointer' }}>
                              Mark Done
                            </button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* New Job Modal */}
      {showNewJob && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
          <div style={{ background: '#fff', borderRadius: 12, padding: 28, width: 440, maxHeight: '80vh', overflowY: 'auto' }}>
            <div style={{ fontWeight: 500, fontSize: 15, marginBottom: 20 }}>New Job</div>
            {[
              { label: 'Project Name *', key: 'name' },
              { label: 'General Contractor', key: 'gc_name' },
              { label: 'Address', key: 'address' },
              { label: 'City', key: 'city' },
            ].map(field => (
              <div key={field.key} style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 11, color: '#888', display: 'block', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.4 }}>{field.label}</label>
                <input value={newJob[field.key] || ''} onChange={e => setNewJob(p => ({ ...p, [field.key]: e.target.value }))}
                  style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }} />
              </div>
            ))}
            {[
              { label: 'Owner', key: 'owner', options: ['Cole', 'Pam', 'Blake'] },
              { label: 'Manufacturer', key: 'manufacturer', options: ['TBD', 'Leedo', 'Skyline', 'SMART', 'Ukon', 'Multiple'] },
            ].map(field => (
              <div key={field.key} style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 11, color: '#888', display: 'block', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.4 }}>{field.label}</label>
                <select value={newJob[field.key]} onChange={e => setNewJob(p => ({ ...p, [field.key]: e.target.value }))}
                  style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }}>
                  {field.options.map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
            ))}
            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 11, color: '#888', display: 'block', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.4 }}>Bid Due Date</label>
              <input type="date" value={newJob.bid_due_date || ''} onChange={e => setNewJob(p => ({ ...p, bid_due_date: e.target.value }))}
                style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }} />
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={createJob} style={{ flex: 1, padding: 8, background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 13 }}>Create Job</button>
              <button onClick={() => setShowNewJob(false)} style={{ flex: 1, padding: 8, background: '#f5f5f3', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer', fontSize: 13 }}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
