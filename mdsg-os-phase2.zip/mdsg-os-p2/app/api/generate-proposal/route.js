import { createClient } from '@supabase/supabase-js'
import PDFDocument from 'pdfkit'

const SENDERS = {
  Cole: {
    name: 'Cole Isetts',
    title: 'Sales Representative',
    phone: '651-301-1068',
    email: 'cole@mdsgcabinets.com',
  },
  Pam: {
    name: 'Pamela Isetts',
    title: 'President',
    phone: '651/301-1063',
    email: 'pam@mdsgcabinets.com',
  },
  Blake: {
    name: 'Blake Isetts',
    title: 'Project Manager',
    phone: '',
    email: 'blake@mdsgcabinets.com',
  },
}

export async function POST(request) {
  try {
    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
    )

    const { jobId, sender = 'Cole', markupMultiplier, hardwareAllowance, notes } = await request.json()

    if (!jobId) return Response.json({ error: 'Job ID required' }, { status: 400 })

    // Fetch full job data
    const { data: job, error: jobError } = await supabase
      .from('jobs')
      .select('*, unit_types(*)')
      .eq('id', jobId)
      .single()

    if (jobError || !job) return Response.json({ error: 'Job not found' }, { status: 404 })

    const senderInfo = SENDERS[sender] || SENDERS.Cole
    const markup = markupMultiplier || job.markup_multiplier || 1.34
    const hardware = hardwareAllowance || job.hardware_allowance || 0
    const discount = job.dealer_discount_pct || 0.05
    const grossCost = job.manufacturer_gross_cost || 0
    const freight = job.freight_cost || 0
    const netCost = (grossCost * (1 - discount)) + freight
    const cabinetsToGC = netCost * markup
    const totalBid = cabinetsToGC + hardware
    const margin = totalBid > 0 ? ((totalBid - netCost - hardware) / totalBid * 100).toFixed(1) : 0

    const today = new Date()
    const validUntil = new Date(today)
    validUntil.setDate(validUntil.getDate() + 90)
    const fmt = (d) => d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
    const fmtMoney = (n) => '$' + Math.round(n || 0).toLocaleString()

    // Generate proposal number
    const proposalNum = `MDSG-${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}${String(today.getDate()).padStart(2, '0')}-${job.name.substring(0, 3).toUpperCase()}`

    // Build PDF
    const doc = new PDFDocument({ margin: 50, size: 'LETTER' })
    const chunks = []
    doc.on('data', chunk => chunks.push(chunk))

    // ── Header ──────────────────────────────────────────────────────────
    doc.fontSize(18).font('Helvetica-Bold').fillColor('#1a1a2e')
      .text('MANUFACTURER DIRECT SALES GROUP, LLC', 50, 50)

    doc.fontSize(9).font('Helvetica').fillColor('#555')
      .text('23463 E. Moraine Pl., Aurora, CO 80016', 50, 75)
      .text(`${senderInfo.email}  |  ${senderInfo.phone}  |  mdsgcabinets.com`, 50, 87)

    // Divider
    doc.moveTo(50, 105).lineTo(562, 105).strokeColor('#1a1a2e').lineWidth(2).stroke()

    // Proposal title
    doc.fontSize(14).font('Helvetica-Bold').fillColor('#1a1a2e')
      .text('CABINET PROPOSAL', 50, 115)

    doc.fontSize(9).font('Helvetica').fillColor('#555')
      .text(`Proposal #: ${proposalNum}`, 50, 132)
      .text(`Date: ${fmt(today)}`, 50, 144)
      .text(`Valid Until: ${fmt(validUntil)}`, 50, 156)

    // ── Customer / Project info ──────────────────────────────────────────
    doc.fontSize(10).font('Helvetica-Bold').fillColor('#1a1a2e')
      .text('CUSTOMER', 320, 115)
    doc.fontSize(9).font('Helvetica').fillColor('#333')
      .text(job.gc_name || '—', 320, 130)
      .text(job.name, 320, 142)
      .text([job.address, job.city, job.state, job.zip].filter(Boolean).join(', '), 320, 154)

    doc.moveTo(50, 175).lineTo(562, 175).strokeColor('#ddd').lineWidth(0.5).stroke()

    // ── Sender info ──────────────────────────────────────────────────────
    doc.fontSize(10).font('Helvetica-Bold').fillColor('#1a1a2e').text('SUBMITTED BY', 50, 185)
    doc.fontSize(9).font('Helvetica').fillColor('#333')
      .text(senderInfo.name, 50, 200)
      .text(senderInfo.title, 50, 212)
      .text(senderInfo.email, 50, 224)
      .text(senderInfo.phone, 50, 236)

    doc.moveTo(50, 255).lineTo(562, 255).strokeColor('#ddd').lineWidth(0.5).stroke()

    // ── Specifications ───────────────────────────────────────────────────
    doc.fontSize(10).font('Helvetica-Bold').fillColor('#1a1a2e').text('SPECIFICATIONS', 50, 265)

    const specs = [
      ['Cabinet Line', `${job.manufacturer || '—'} — ${job.box_construction || 'Framed, Plywood'}`],
      ['Door Style', job.door_style || '—'],
      ['Finish / Color', job.finish_color || '—'],
      ['Box Construction', job.box_construction || 'Framed — Plywood w/ Dovetail'],
      ['Drawer / Glide', 'Standard'],
      ['Hinges', 'Euro 6-Way Soft Close'],
      ['Total Residential Units', job.total_residential_units || '—'],
      ['Total Cabinets', (job.total_cabinet_count || 0).toLocaleString()],
    ]

    let y = 282
    specs.forEach(([label, value]) => {
      doc.fontSize(9).font('Helvetica-Bold').fillColor('#555').text(label + ':', 50, y)
      doc.fontSize(9).font('Helvetica').fillColor('#333').text(String(value), 220, y)
      y += 14
    })

    doc.moveTo(50, y + 5).lineTo(562, y + 5).strokeColor('#ddd').lineWidth(0.5).stroke()
    y += 18

    // ── Unit Type Breakdown ──────────────────────────────────────────────
    if (job.unit_types && job.unit_types.length > 0) {
      doc.fontSize(10).font('Helvetica-Bold').fillColor('#1a1a2e').text('UNIT TYPE BREAKDOWN', 50, y)
      y += 16

      // Table header
      doc.rect(50, y, 512, 16).fill('#f0f0f0')
      doc.fontSize(8).font('Helvetica-Bold').fillColor('#333')
        .text('Unit Type', 55, y + 4)
        .text('Units', 300, y + 4)
        .text('Cabinets', 360, y + 4)
        .text('Manufacturer Price', 420, y + 4)
      y += 16

      job.unit_types.sort((a, b) => a.sort_order - b.sort_order).forEach((ut, i) => {
        if (i % 2 === 0) doc.rect(50, y, 512, 14).fill('#fafafa')
        doc.fontSize(8).font('Helvetica').fillColor('#333')
          .text(ut.unit_type_name, 55, y + 3)
          .text(String(ut.unit_quantity || 1), 305, y + 3)
          .text(String(ut.cabinet_count || 0), 365, y + 3)
          .text(ut.manufacturer_price ? fmtMoney(ut.manufacturer_price) : '—', 425, y + 3)
        y += 14
      })
      y += 8
    }

    doc.moveTo(50, y).lineTo(562, y).strokeColor('#ddd').lineWidth(0.5).stroke()
    y += 12

    // ── Pricing Summary ──────────────────────────────────────────────────
    doc.fontSize(10).font('Helvetica-Bold').fillColor('#1a1a2e').text('PRICING SUMMARY', 50, y)
    y += 16

    const priceLines = [
      ['Base Cabinet Price', fmtMoney(cabinetsToGC), false],
      hardware > 0 ? ['Hardware Allowance', fmtMoney(hardware), false] : null,
      notes ? ['Additional Notes', notes, false] : null,
    ].filter(Boolean)

    priceLines.forEach(([label, value]) => {
      doc.fontSize(9).font('Helvetica').fillColor('#555').text(label, 55, y)
      doc.fontSize(9).font('Helvetica').fillColor('#333').text(value, 450, y, { align: 'right', width: 100 })
      y += 16
    })

    // Total box
    doc.rect(350, y, 212, 28).fill('#1a1a2e')
    doc.fontSize(11).font('Helvetica-Bold').fillColor('#ffffff')
      .text('TOTAL PROJECT PRICE', 355, y + 4)
      .text(fmtMoney(totalBid), 355, y + 4, { align: 'right', width: 200 })
    y += 40

    // ── Installation note ────────────────────────────────────────────────
    doc.fontSize(8).font('Helvetica').fillColor('#555')
      .text('INSTALLATION: By Greenworks Renovations under separate contract. Includes unloading, staging, cabinet & hardware installation.', 50, y, { width: 512 })
    y += 24

    // ── Not included ────────────────────────────────────────────────────
    doc.fontSize(8).font('Helvetica-Bold').fillColor('#333').text('NOT INCLUDED IN BID:', 50, y)
    y += 12
    doc.fontSize(8).font('Helvetica').fillColor('#555')
      .text('Attic stock, locks, labor, shims, screws, supports, grommets, castors, blocking or backing material, crown molding, base shoe, out-of-phase delivery for mock unit, recessed linens, desks, entry benches, floating shelves, undercabinet lighting unless included in writing.', 50, y, { width: 512 })
    y += 36

    // ── Terms ────────────────────────────────────────────────────────────
    doc.moveTo(50, y).lineTo(562, y).strokeColor('#ddd').lineWidth(0.5).stroke()
    y += 10
    doc.fontSize(8).font('Helvetica').fillColor('#555')
      .text('Unit pricing will be honored for 90 days from the date of proposal. All quantities are estimated — final field measurements and approved shop drawings will prevail. Final price subject to final approval of shop drawings.', 50, y, { width: 512 })
    y += 30

    // ── Signature ────────────────────────────────────────────────────────
    doc.fontSize(9).font('Helvetica').fillColor('#333')
      .text('Accepted by:', 50, y)
      .text('Date:', 350, y)
    doc.moveTo(110, y + 20).lineTo(320, y + 20).strokeColor('#333').lineWidth(0.5).stroke()
    doc.moveTo(385, y + 20).lineTo(562, y + 20).strokeColor('#333').lineWidth(0.5).stroke()
    y += 35

    // ── Footer ───────────────────────────────────────────────────────────
    doc.fontSize(8).font('Helvetica').fillColor('#888')
      .text('MANUFACTURER DIRECT SALES GROUP, LLC  |  23463 E. Moraine Pl., Aurora, CO 80016  |  mdsgcabinets.com', 50, 740, { align: 'center', width: 512 })

    doc.end()

    await new Promise(resolve => doc.on('end', resolve))
    const pdfBuffer = Buffer.concat(chunks)

    // Save proposal record to DB
    await supabase.from('proposals').insert({
      job_id: jobId,
      proposal_number: proposalNum,
      status: 'Draft',
      total_amount: totalBid,
      valid_until: validUntil.toISOString().split('T')[0],
      sent_from: senderInfo.email,
    })

    await supabase.from('activity_log').insert({
      job_id: jobId,
      user_name: sender,
      action: `Proposal generated — ${proposalNum} · ${fmtMoney(totalBid)} · ${margin}% margin`,
    })

    return new Response(pdfBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="MDSG-Proposal-${job.name.replace(/[^a-z0-9]/gi, '-')}.pdf"`,
      },
    })
  } catch (error) {
    console.error('Proposal generation error:', error)
    return Response.json({ error: error.message }, { status: 500 })
  }
}
