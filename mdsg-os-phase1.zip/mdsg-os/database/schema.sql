-- MDSG OS Database Schema
-- Run this entire file in your Supabase SQL Editor (supabase.com → your project → SQL Editor)

-- ─────────────────────────────────────────
-- CONTACTS (GCs, developers, manufacturer reps)
-- ─────────────────────────────────────────
create table contacts (
  id uuid default gen_random_uuid() primary key,
  created_at timestamp with time zone default now(),
  name text not null,
  company text,
  role text,
  email text,
  phone text,
  notes text,
  type text check (type in ('gc', 'developer', 'manufacturer_rep', 'other')) default 'gc'
);

-- ─────────────────────────────────────────
-- JOBS (the core CRM record)
-- ─────────────────────────────────────────
create table jobs (
  id uuid default gen_random_uuid() primary key,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now(),

  -- Basic info
  name text not null,
  address text,
  city text,
  state text default 'CO',
  zip text,

  -- Relationships
  gc_name text,
  gc_contact_id uuid references contacts(id),
  owner text check (owner in ('Cole', 'Pam', 'Blake')) default 'Cole',

  -- Pipeline stage
  stage text check (stage in (
    'Bid', 'Awarded', 'Shop Drawings', 'Ordered', 'Delivered', 'Installed', 'Lost'
  )) default 'Bid',

  -- Bid details
  bid_due_date date,
  bid_submitted_date date,
  follow_up_date date,

  -- Manufacturer
  manufacturer text check (manufacturer in ('Leedo', 'Skyline', 'SMART', 'Ukon', 'Multiple', 'TBD')) default 'TBD',
  manufacturer_quote_number text,
  manufacturer_rep text,
  door_style text,
  finish_color text,
  box_construction text,

  -- Unit counts
  total_residential_units integer default 0,
  total_cabinet_count integer default 0,
  unit_type_count integer default 0,

  -- Financials (all stored as dollars)
  manufacturer_gross_cost numeric(12,2) default 0,   -- what mfr charges before discount
  freight_cost numeric(12,2) default 0,
  dealer_discount_pct numeric(5,4) default 0.05,      -- 5% default
  net_cost numeric(12,2) default 0,                   -- after discount + freight
  markup_multiplier numeric(5,4) default 1.34,         -- your default 1.34x
  hardware_allowance numeric(12,2) default 0,
  bid_value numeric(12,2) default 0,                  -- what you quote to GC
  gross_margin_pct numeric(5,4) default 0,

  -- Notes
  notes text,
  scope_notes text
);

-- ─────────────────────────────────────────
-- UNIT TYPES (the cabinet count breakdown per job)
-- ─────────────────────────────────────────
create table unit_types (
  id uuid default gen_random_uuid() primary key,
  job_id uuid references jobs(id) on delete cascade,
  created_at timestamp with time zone default now(),

  unit_type_name text not null,      -- e.g. "1BR/2BR (67)", "3BR (23)"
  unit_quantity integer default 1,
  cabinet_count integer default 0,
  total_cubes numeric(10,2) default 0,
  manufacturer_price numeric(12,2) default 0,
  sort_order integer default 0
);

-- ─────────────────────────────────────────
-- CABINET LINE ITEMS (individual SKUs per unit type)
-- ─────────────────────────────────────────
create table cabinet_line_items (
  id uuid default gen_random_uuid() primary key,
  unit_type_id uuid references unit_types(id) on delete cascade,
  job_id uuid references jobs(id) on delete cascade,

  sku text not null,                 -- e.g. "W2436R", "DB18-4", "TKPW"
  description text,                  -- e.g. "Plywood/PW w/ Clear Dovetail Standard"
  door_style text,
  finish text,
  hinge_side text,                   -- L, R, L/R, NA
  quantity integer default 1,
  extended_price numeric(12,2) default 0,
  sort_order integer default 0
);

-- ─────────────────────────────────────────
-- MANUFACTURER QUOTES (the raw PDF uploads)
-- ─────────────────────────────────────────
create table manufacturer_quotes (
  id uuid default gen_random_uuid() primary key,
  job_id uuid references jobs(id) on delete cascade,
  created_at timestamp with time zone default now(),

  manufacturer text,
  quote_number text,
  rep_name text,
  quote_date date,
  expiry_date date,

  -- Raw extracted data stored as JSON
  raw_extracted_json jsonb,

  -- Parsed totals
  gross_amount numeric(12,2) default 0,
  freight_amount numeric(12,2) default 0,
  grand_total numeric(12,2) default 0,
  total_units integer default 0,
  total_cabinets integer default 0,

  -- File reference
  file_name text,
  parsed_at timestamp with time zone
);

-- ─────────────────────────────────────────
-- ACTIVITY LOG (everything that happens on a job)
-- ─────────────────────────────────────────
create table activity_log (
  id uuid default gen_random_uuid() primary key,
  job_id uuid references jobs(id) on delete cascade,
  created_at timestamp with time zone default now(),

  user_name text,
  action text not null,
  notes text
);

-- ─────────────────────────────────────────
-- PROPOSALS (generated proposal records)
-- ─────────────────────────────────────────
create table proposals (
  id uuid default gen_random_uuid() primary key,
  job_id uuid references jobs(id) on delete cascade,
  created_at timestamp with time zone default now(),

  proposal_number text,
  sent_date date,
  sent_from text,
  sent_to text,
  status text check (status in ('Draft', 'Sent', 'Accepted', 'Rejected')) default 'Draft',
  total_amount numeric(12,2) default 0,
  valid_until date,
  notes text
);

-- ─────────────────────────────────────────
-- SHIPMENTS (per-load delivery tracking)
-- ─────────────────────────────────────────
create table shipments (
  id uuid default gen_random_uuid() primary key,
  job_id uuid references jobs(id) on delete cascade,
  created_at timestamp with time zone default now(),

  load_number integer default 1,
  total_loads integer default 1,
  tracking_number text,
  carrier text default 'UPS Freight',
  floors_covered text,              -- e.g. "1-4", "5-9"
  scheduled_date date,
  actual_delivery_date date,
  status text check (status in ('Scheduled', 'In Transit', 'Delivered', 'Delayed')) default 'Scheduled',
  notes text
);

-- ─────────────────────────────────────────
-- REMINDERS (follow-up alerts)
-- ─────────────────────────────────────────
create table reminders (
  id uuid default gen_random_uuid() primary key,
  job_id uuid references jobs(id) on delete cascade,
  created_at timestamp with time zone default now(),

  due_date date not null,
  reminder_type text check (reminder_type in ('Bid Follow-up', 'Bid Deadline', 'Delivery Check', 'Payment', 'General')) default 'General',
  message text,
  completed boolean default false,
  completed_at timestamp with time zone,
  assigned_to text default 'Cole'
);

-- ─────────────────────────────────────────
-- AUTO-UPDATE updated_at on jobs
-- ─────────────────────────────────────────
create or replace function update_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger jobs_updated_at
  before update on jobs
  for each row execute function update_updated_at();

-- ─────────────────────────────────────────
-- SEED DATA — Loretto Heights (your real job)
-- ─────────────────────────────────────────
insert into contacts (name, company, role, email, type) values
  ('Richard Knudson', 'Leedo', 'Sales Rep', 'r.knudson@leedo.com', 'manufacturer_rep');

insert into jobs (
  name, address, city, state, zip,
  gc_name, owner, stage,
  bid_due_date, follow_up_date,
  manufacturer, manufacturer_quote_number, manufacturer_rep,
  door_style, finish_color, box_construction,
  total_residential_units, total_cabinet_count, unit_type_count,
  manufacturer_gross_cost, freight_cost, dealer_discount_pct,
  net_cost, markup_multiplier, hardware_allowance,
  bid_value, gross_margin_pct,
  notes
) values (
  'Loretto Heights Apartments',
  '2980 South Pancratia St', 'Denver', 'CO', '80236',
  'Alliance Construction', 'Cole', 'Bid',
  '2026-02-15', '2026-02-01',
  'Leedo', 'SLS-3099-R-A', 'Richard Knudson',
  'Covington', 'Midnight Navy', 'Framed — Plywood w/ Clear Dovetail',
  97, 1186, 8,
  218401.62, 19881.20, 0.05,
  227282.82, 1.34, 4998.00,
  311193.00, 0.306,
  'Leedo quote QUOTE-Loretto Heights-UG. Quote expires 03/01/2026.'
);
