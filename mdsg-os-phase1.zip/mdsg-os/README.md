# MDSG OS — Setup Guide

## What This Is
A complete business operating system for Manufacturer Direct Sales Group.
Manages jobs, parses manufacturer quote PDFs with AI, calculates pricing, and tracks the full pipeline.

---

## Step-by-Step Setup (First Time)

### 1. Set Up Supabase (your database)
1. Go to supabase.com and sign in
2. Click "New Project" → name it `mdsg-os` → save the password
3. Wait ~2 minutes for it to spin up
4. Go to the "SQL Editor" tab on the left
5. Copy the entire contents of `database/schema.sql`
6. Paste it into the SQL editor and click "Run"
7. You should see "Success" — this creates all your tables

**Get your keys:**
- Go to Settings → API
- Copy "Project URL" → this is your NEXT_PUBLIC_SUPABASE_URL
- Copy "anon public" key → this is your NEXT_PUBLIC_SUPABASE_ANON_KEY

### 2. Get Your Anthropic API Key
1. Go to console.anthropic.com
2. Sign in (create account if needed — use cole@mdsgcabinets.com)
3. Click "API Keys" → "Create Key"
4. Copy the key (starts with sk-ant-)

### 3. Fill In Your .env.local File
Open the `.env.local` file in your mdsg-os folder and replace the placeholder values:

```
NEXT_PUBLIC_SUPABASE_URL=https://yourproject.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
ANTHROPIC_API_KEY=sk-ant-api03-...
```

### 4. Run the App
In Command Prompt, make sure you're in the mdsg-os folder, then:
```
npm run dev
```

Open your browser and go to: http://localhost:3000

---

## Daily Use

### Adding a New Job
Click "+ New Job" in the top right → fill in project name, GC, due date → Create

### Uploading a Manufacturer Quote PDF
1. Open a job (click it in the pipeline or jobs list)
2. Scroll to "Upload Manufacturer Quote PDF"
3. Click and select your Leedo/Skyline/SMART/Ukon PDF
4. Wait ~15 seconds — AI parses everything automatically
5. Unit types, cabinet counts, and pricing appear in the job

### Updating a Job Stage
(Coming in Phase 2 — for now, contact Cole to update via SQL)

---

## Monthly Costs (estimated)
- Supabase: Free (up to 500MB, plenty for MDSG volume)
- Vercel (hosting): Free tier
- Anthropic API: ~$30-80/month depending on quote volume
- Domain: Already have mdsgcabinets.com

---

## Files Overview
```
mdsg-os/
├── app/
│   ├── page.js              ← Main application (dashboard, jobs, CRM)
│   ├── layout.js            ← App wrapper
│   └── api/
│       ├── parse-quote/     ← PDF parsing endpoint (uses Claude API)
│       └── jobs/            ← Job CRUD API
├── lib/
│   ├── supabase.js          ← Database connection
│   └── pricing.js           ← Markup calculator logic
├── database/
│   └── schema.sql           ← Run this in Supabase SQL Editor
├── .env.local               ← Your secret keys (never share this file)
└── next.config.js           ← App configuration
```

---

## Phase 2 (Next Build)
- Proposal PDF generator (branded MDSG output)
- Gmail integration for email logging
- Shipment tracking
- Stage drag-and-drop in pipeline
- Bid reminder notifications
- Countertop module
