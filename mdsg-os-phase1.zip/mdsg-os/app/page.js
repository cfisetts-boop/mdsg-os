'use client'

import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

// Stage colors matching MDSG OS design
const STAGE_COLORS = {
  'Bid':           { bg: '#EEEDFE', text: '#3C3489' },
  'Awarded':       { bg: '#EAF3DE', text: '#3B6D11' },
  'Shop Drawings': { bg: '#FAEEDA', text: '#633806' },
  'Ordered':       { bg: '#E6F1FB', text: '#0C447C' },
  'Delivered':     { bg: '#E1F5EE', text: '#085041' },
  'Installed':     { bg: '#EAF3DE', text: '#27500A' },
  'Lost':          { bg: '#FCEBEB', text: '#A32D2D' },
}

const STAGES = ['Bid', 'Awarded', 'Shop Drawings', 'Ordered', 'Delivered', 'Installed']

export default function Home() {
  const [jobs, setJobs] = useState([])
  const [view, setView] = useState('dashboard')
  const [selectedJob, setSelectedJob] = useState(null)
  const [loading, setLoading] = useState(true)
  const [showNewJob, setShowNewJob] = useState(false)
  const [newJob, setNewJob] = useState({ name: '', gc_name: '', address: '', city: 'Denver', state: 'CO', owner: 'Cole', stage: 'Bid', manufacturer: 'TBD' })
  const [quoteUploading, setQuoteUploading] = useState(false)
  const [quoteResult, setQuoteResult] = useState(null)

  useEffect(() => {
    loadJobs()
  }, [])

  async function loadJobs() {
    setLoading(true)
    const { data, error } = await supabase
      .from('jobs')
      .select('*, unit_types(*), activity_log(*), reminders(*)')
      .order('created_at', { ascending: false })

    if (!error) setJobs(data || [])
    setLoading(false)
  }

  async function createJob() {
    if (!newJob.name) return alert('Job name is required')
    const { data, error } = await supabase.from('jobs').insert(newJob).select().single()
    if (error) return alert('Error creating job: ' + error.message)
    await supabase.from('activity_log').insert({ job_id: data.id, user_name: newJob.owner, action: `Job created — ${newJob.name}` })
    setShowNewJob(false)
    setNewJob({ name: '', gc_name: '', address: '', city: 'Denver', state: 'CO', owner: 'Cole', stage: 'Bid', manufacturer: 'TBD' })
    loadJobs()
  }

  async function handleQuoteUpload(e) {
    const file = e.target.files[0]
    if (!file || !file.name.endsWith('.pdf')) return alert('Please select a PDF file')
    if (!selectedJob) return alert('Select a job first')

    setQuoteUploading(true)
    setQuoteResult(null)

    const formData = new FormData()
    formData.append('file', file)

    const arrayBuffer = await file.arrayBuffer()
    const response = await fetch('/api/parse-quote', {
      method: 'POST',
      headers: {
        'x-job-id': selectedJob.id,
        'x-file-name': file.name,
        'Content-Type': 'application/pdf',
      },
      body: arrayBuffer,
    })

    const result = await response.json()
    setQuoteUploading(false)

    if (result.success) {
      setQuoteResult(result)
      loadJobs()
    } else {
      alert('Error parsing quote: ' + (result.error || 'Unknown error'))
    }
  }

  // ── Derived metrics ────────────────────────────────────────────────────
  const pipelineValue = jobs.reduce((sum, j) => sum + (j.bid_value || 0), 0)
  const activeBids = jobs.filter(j => j.stage === 'Bid').length
  const awardedValue = jobs.filter(j => !['Bid', 'Lost'].includes(j.stage)).reduce((sum, j) => sum + (j.bid_value || 0), 0)
  const avgMargin = jobs.filter(j => j.gross_margin_pct > 0).reduce((sum, j, _, arr) => sum + j.gross_margin_pct / arr.length, 0)

  const fmt = (n) => n ? '$' + Math.round(n).toLocaleString() : '—'
  const fmtPct = (n) => n ? (n * 100).toFixed(1) + '%' : '—'

  return (
    <div style={{ display: 'flex', height: '100vh', fontFamily: 'system-ui, sans-serif', fontSize: 14, background: '#f5f5f3' }}>

      {/* ── Sidebar ── */}
      <div style={{ width: 200, background: '#fff', borderRight: '0.5px solid #e5e5e0', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '16px', borderBottom: '0.5px solid #e5e5e0' }}>
          <div style={{ fontWeight: 600, fontSize: 13, letterSpacing: 0.5 }}>MDSG OS</div>
          <div style={{ fontSize: 11, color: '#888', marginTop: 2 }}>Manufacturer Direct Sales</div>
        </div>
        <div style={{ padding: '8px 0', flex: 1 }}>
          {[
            { id: 'dashboard', label: 'Dashboard' },
            { id: 'jobs', label: 'Jobs' },
            { id: 'takeoff', label: 'Upload Quote' },
          ].map(item => (
            <div key={item.id}
              onClick={() => setView(item.id)}
              style={{
                padding: '8px 16px', cursor: 'pointer', fontSize: 13,
                color: view === item.id ? '#1a1a1a' : '#666',
                background: view === item.id ? '#f5f5f3' : 'transparent',
                borderLeft: view === item.id ? '2px solid #3C3489' : '2px solid transparent',
                fontWeight: view === item.id ? 500 : 400,
              }}>
              {item.label}
            </div>
          ))}
        </div>
        <div style={{ padding: '12px 16px', borderTop: '0.5px solid #e5e5e0', fontSize: 12 }}>
          <div style={{ fontWeight: 500 }}>Cole Isetts</div>
          <div style={{ color: '#888', fontSize: 11 }}>Sales · Aurora, CO</div>
        </div>
      </div>

      {/* ── Main ── */}
      <div style={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column' }}>

        {/* Topbar */}
        <div style={{ padding: '12px 24px', background: '#fff', borderBottom: '0.5px solid #e5e5e0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontWeight: 500, fontSize: 16 }}>
            {view === 'dashboard' && 'Dashboard'}
            {view === 'jobs' && 'Jobs'}
            {view === 'takeoff' && 'Upload Manufacturer Quote'}
            {view === 'job-detail' && selectedJob?.name}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => setShowNewJob(true)} style={{ padding: '6px 14px', fontSize: 12, background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer' }}>
              + New Job
            </button>
          </div>
        </div>

        <div style={{ padding: 24, flex: 1 }}>

          {/* ── DASHBOARD ── */}
          {view === 'dashboard' && (
            <div>
              {/* Metrics */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 24 }}>
                {[
                  { label: 'Pipeline Value', value: fmt(pipelineValue), sub: `${jobs.length} total jobs` },
                  { label: 'Active Bids', value: activeBids, sub: 'in bid stage' },
                  { label: 'Awarded Value', value: fmt(awardedValue), sub: 'ex. bids & lost' },
                  { label: 'Avg Margin', value: fmtPct(avgMargin), sub: 'across priced jobs' },
                ].map(m => (
                  <div key={m.label} style={{ background: '#f5f5f3', borderRadius: 8, padding: 14 }}>
                    <div style={{ fontSize: 11, color: '#888', fontWeight: 500, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>{m.label}</div>
                    <div style={{ fontSize: 22, fontWeight: 500 }}>{loading ? '—' : m.value}</div>
                    <div style={{ fontSize: 11, color: '#888', marginTop: 4 }}>{m.sub}</div>
                  </div>
                ))}
              </div>

              {/* Pipeline board */}
              <div style={{ marginBottom: 8, fontWeight: 500, fontSize: 13 }}>Job Pipeline</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8 }}>
                {STAGES.map(stage => {
                  const stageJobs = jobs.filter(j => j.stage === stage)
                  const colors = STAGE_COLORS[stage]
                  return (
                    <div key={stage} style={{ background: '#f5f5f3', borderRadius: 8, padding: 10, minHeight: 80 }}>
                      <div style={{ fontSize: 10, fontWeight: 500, color: '#888', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8, display: 'flex', justifyContent: 'space-between' }}>
                        {stage} <span style={{ background: '#fff', borderRadius: 10, padding: '1px 6px', fontSize: 10 }}>{stageJobs.length}</span>
                      </div>
                      {stageJobs.map(job => (
                        <div key={job.id}
                          onClick={() => { setSelectedJob(job); setView('job-detail') }}
                          style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 6, padding: 10, marginBottom: 6, cursor: 'pointer' }}>
                          <div style={{ fontWeight: 500, fontSize: 12 }}>{job.name}</div>
                          <div style={{ fontSize: 11, color: '#888' }}>{job.gc_name || '—'}</div>
                          <div style={{ fontSize: 12, fontWeight: 500, color: '#3C3489', marginTop: 4 }}>{fmt(job.bid_value)}</div>
                        </div>
                      ))}
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* ── JOBS LIST ── */}
          {view === 'jobs' && (
            <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead>
                  <tr style={{ background: '#f5f5f3' }}>
                    {['Project', 'GC', 'Stage', 'Manufacturer', 'Cabinets', 'Bid Value', 'Margin', 'Owner'].map(h => (
                      <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 500, color: '#888', borderBottom: '0.5px solid #e5e5e0', fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.4 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr><td colSpan={8} style={{ padding: 24, textAlign: 'center', color: '#888' }}>Loading jobs...</td></tr>
                  ) : jobs.map(job => {
                    const colors = STAGE_COLORS[job.stage] || STAGE_COLORS['Bid']
                    return (
                      <tr key={job.id}
                        onClick={() => { setSelectedJob(job); setView('job-detail') }}
                        style={{ cursor: 'pointer', borderBottom: '0.5px solid #f0f0ec' }}
                        onMouseEnter={e => e.currentTarget.style.background = '#fafaf8'}
                        onMouseLeave={e => e.currentTarget.style.background = ''}>
                        <td style={{ padding: '10px 14px', fontWeight: 500 }}>{job.name}</td>
                        <td style={{ padding: '10px 14px', color: '#555' }}>{job.gc_name || '—'}</td>
                        <td style={{ padding: '10px 14px' }}>
                          <span style={{ background: colors.bg, color: colors.text, borderRadius: 10, padding: '2px 8px', fontSize: 10, fontWeight: 500 }}>{job.stage}</span>
                        </td>
                        <td style={{ padding: '10px 14px', color: '#555' }}>{job.manufacturer}</td>
                        <td style={{ padding: '10px 14px', color: '#555' }}>{job.total_cabinet_count || '—'}</td>
                        <td style={{ padding: '10px 14px', fontWeight: 500 }}>{fmt(job.bid_value)}</td>
                        <td style={{ padding: '10px 14px', color: job.gross_margin_pct >= 0.25 ? '#3B6D11' : '#854F0B', fontWeight: 500 }}>{fmtPct(job.gross_margin_pct)}</td>
                        <td style={{ padding: '10px 14px', color: '#555' }}>{job.owner}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* ── JOB DETAIL ── */}
          {view === 'job-detail' && selectedJob && (
            <div>
              <div onClick={() => setView('jobs')} style={{ fontSize: 12, color: '#888', marginBottom: 16, cursor: 'pointer' }}>
                ← <span style={{ color: '#3C3489' }}>Jobs</span> / {selectedJob.name}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div>
                  <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 20, marginBottom: 16 }}>
                    <div style={{ fontWeight: 500, marginBottom: 16 }}>{selectedJob.name}</div>
                    {[
                      ['General Contractor', selectedJob.gc_name],
                      ['Address', [selectedJob.address, selectedJob.city, selectedJob.state, selectedJob.zip].filter(Boolean).join(', ')],
                      ['Stage', selectedJob.stage],
                      ['Manufacturer', selectedJob.manufacturer],
                      ['Quote #', selectedJob.manufacturer_quote_number],
                      ['Door Style', selectedJob.door_style],
                      ['Finish', selectedJob.finish_color],
                      ['Total Units', selectedJob.total_residential_units],
                      ['Total Cabinets', selectedJob.total_cabinet_count],
                      ['Bid Due', selectedJob.bid_due_date],
                      ['Owner', selectedJob.owner],
                    ].map(([label, value]) => value ? (
                      <div key={label} style={{ marginBottom: 12 }}>
                        <div style={{ fontSize: 11, color: '#888', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 2 }}>{label}</div>
                        <div>{value}</div>
                      </div>
                    ) : null)}
                  </div>

                  {/* Upload quote for this job */}
                  <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 20, marginBottom: 16 }}>
                    <div style={{ fontWeight: 500, marginBottom: 12 }}>Upload Manufacturer Quote PDF</div>
                    <label style={{ display: 'block', border: '1.5px dashed #ccc', borderRadius: 8, padding: 20, textAlign: 'center', cursor: 'pointer', background: '#fafaf8' }}>
                      <div style={{ color: '#555', fontSize: 13 }}>{quoteUploading ? 'Parsing with AI...' : 'Click to upload PDF quote'}</div>
                      <div style={{ color: '#999', fontSize: 11, marginTop: 4 }}>Leedo, Skyline, SMART, Ukon</div>
                      <input type="file" accept=".pdf" onChange={handleQuoteUpload} style={{ display: 'none' }} disabled={quoteUploading} />
                    </label>
                    {quoteResult && (
                      <div style={{ marginTop: 12, padding: 12, background: '#EAF3DE', borderRadius: 8, fontSize: 12 }}>
                        <div style={{ fontWeight: 500, color: '#3B6D11', marginBottom: 4 }}>Quote parsed successfully</div>
                        <div>Manufacturer: {quoteResult.summary.manufacturer}</div>
                        <div>Quote #: {quoteResult.summary.quote_number}</div>
                        <div>Unit types: {quoteResult.summary.unit_type_count}</div>
                        <div>Total cabinets: {quoteResult.summary.total_cabinets}</div>
                        <div style={{ fontWeight: 500 }}>Grand total: {fmt(quoteResult.summary.grand_total)}</div>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  {/* Pricing */}
                  <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 20, marginBottom: 16 }}>
                    <div style={{ fontWeight: 500, marginBottom: 16 }}>Pricing Summary</div>
                    {[
                      ['Manufacturer Gross', selectedJob.manufacturer_gross_cost],
                      ['Freight', selectedJob.freight_cost],
                    ].map(([label, value]) => (
                      <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: 13, borderBottom: '0.5px solid #f0f0ec' }}>
                        <span style={{ color: '#555' }}>{label}</span>
                        <span style={{ fontWeight: 500 }}>{fmt(value)}</span>
                      </div>
                    ))}
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: 13, borderBottom: '0.5px solid #f0f0ec', color: '#3B6D11' }}>
                      <span>Dealer Discount ({(selectedJob.dealer_discount_pct * 100).toFixed(0)}%)</span>
                      <span style={{ fontWeight: 500 }}>− {fmt(selectedJob.manufacturer_gross_cost * selectedJob.dealer_discount_pct)}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: 13, borderBottom: '0.5px solid #f0f0ec' }}>
                      <span style={{ color: '#555' }}>Markup ({selectedJob.markup_multiplier}×)</span>
                      <span style={{ fontWeight: 500 }}>applied</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0 0', fontSize: 16, fontWeight: 500 }}>
                      <span>Bid to GC</span>
                      <span style={{ color: '#3C3489' }}>{fmt(selectedJob.bid_value)}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: 12 }}>
                      <span style={{ color: '#888' }}>Gross Margin</span>
                      <span style={{ color: selectedJob.gross_margin_pct >= 0.25 ? '#3B6D11' : '#854F0B', fontWeight: 500 }}>
                        {fmtPct(selectedJob.gross_margin_pct)}
                      </span>
                    </div>
                  </div>

                  {/* Activity log */}
                  <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 20 }}>
                    <div style={{ fontWeight: 500, marginBottom: 12 }}>Activity Log</div>
                    {(selectedJob.activity_log || []).sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).map(log => (
                      <div key={log.id} style={{ paddingBottom: 12, marginBottom: 12, borderBottom: '0.5px solid #f0f0ec', fontSize: 12 }}>
                        <div>{log.action}</div>
                        <div style={{ color: '#888', fontSize: 11, marginTop: 2 }}>
                          {log.user_name} · {new Date(log.created_at).toLocaleDateString()}
                        </div>
                      </div>
                    ))}
                    {(selectedJob.activity_log || []).length === 0 && (
                      <div style={{ color: '#888', fontSize: 12 }}>No activity yet</div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── UPLOAD QUOTE (standalone) ── */}
          {view === 'takeoff' && (
            <div>
              <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 32, textAlign: 'center', maxWidth: 500, margin: '0 auto' }}>
                <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 8 }}>Upload Manufacturer Quote PDF</div>
                <div style={{ fontSize: 12, color: '#888', marginBottom: 24 }}>Select a job first, then upload the PDF quote. Claude will extract all unit types, cabinet SKUs, quantities, and pricing automatically.</div>
                <div style={{ marginBottom: 16 }}>
                  <label style={{ fontSize: 12, color: '#555', display: 'block', marginBottom: 6, textAlign: 'left' }}>Select Job</label>
                  <select
                    onChange={e => setSelectedJob(jobs.find(j => j.id === e.target.value))}
                    style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }}>
                    <option value="">Choose a job...</option>
                    {jobs.map(j => <option key={j.id} value={j.id}>{j.name}</option>)}
                  </select>
                </div>
                {selectedJob && (
                  <label style={{ display: 'block', border: '1.5px dashed #ccc', borderRadius: 8, padding: 32, cursor: 'pointer', background: '#fafaf8' }}>
                    <div style={{ fontSize: 13, color: '#555' }}>{quoteUploading ? 'AI is parsing your quote...' : 'Drop PDF here or click to upload'}</div>
                    <div style={{ fontSize: 11, color: '#999', marginTop: 4 }}>Leedo · Skyline · SMART · Ukon</div>
                    <input type="file" accept=".pdf" onChange={handleQuoteUpload} style={{ display: 'none' }} disabled={quoteUploading} />
                  </label>
                )}
                {quoteResult && (
                  <div style={{ marginTop: 16, padding: 16, background: '#EAF3DE', borderRadius: 8, textAlign: 'left', fontSize: 12 }}>
                    <div style={{ fontWeight: 500, color: '#3B6D11', marginBottom: 8 }}>Parsed successfully</div>
                    <div>Manufacturer: {quoteResult.summary.manufacturer}</div>
                    <div>Quote #: {quoteResult.summary.quote_number}</div>
                    <div>Unit types: {quoteResult.summary.unit_type_count}</div>
                    <div>Total cabinets: {quoteResult.summary.total_cabinets.toLocaleString()}</div>
                    <div style={{ fontWeight: 500, marginTop: 4 }}>Grand total: {fmt(quoteResult.summary.grand_total)}</div>
                    <button onClick={() => { setSelectedJob(jobs.find(j => j.id === selectedJob?.id)); setView('job-detail') }}
                      style={{ marginTop: 12, padding: '6px 14px', background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12 }}>
                      View Job Detail →
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

        </div>
      </div>

      {/* ── New Job Modal ── */}
      {showNewJob && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
          <div style={{ background: '#fff', borderRadius: 12, padding: 28, width: 440, maxHeight: '80vh', overflowY: 'auto' }}>
            <div style={{ fontWeight: 500, fontSize: 15, marginBottom: 20 }}>New Job</div>
            {[
              { label: 'Project Name *', key: 'name', type: 'text' },
              { label: 'General Contractor', key: 'gc_name', type: 'text' },
              { label: 'Address', key: 'address', type: 'text' },
              { label: 'City', key: 'city', type: 'text' },
            ].map(field => (
              <div key={field.key} style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 11, color: '#888', display: 'block', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.4 }}>{field.label}</label>
                <input
                  value={newJob[field.key] || ''}
                  onChange={e => setNewJob(p => ({ ...p, [field.key]: e.target.value }))}
                  style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }}
                />
              </div>
            ))}
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 11, color: '#888', display: 'block', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.4 }}>Owner</label>
              <select value={newJob.owner} onChange={e => setNewJob(p => ({ ...p, owner: e.target.value }))}
                style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }}>
                <option>Cole</option><option>Pam</option><option>Blake</option>
              </select>
            </div>
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 11, color: '#888', display: 'block', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.4 }}>Manufacturer</label>
              <select value={newJob.manufacturer} onChange={e => setNewJob(p => ({ ...p, manufacturer: e.target.value }))}
                style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }}>
                <option>TBD</option><option>Leedo</option><option>Skyline</option><option>SMART</option><option>Ukon</option><option>Multiple</option>
              </select>
            </div>
            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 11, color: '#888', display: 'block', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.4 }}>Bid Due Date</label>
              <input type="date" value={newJob.bid_due_date || ''} onChange={e => setNewJob(p => ({ ...p, bid_due_date: e.target.value }))}
                style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }} />
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={createJob} style={{ flex: 1, padding: '8px', background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 13 }}>
                Create Job
              </button>
              <button onClick={() => setShowNewJob(false)} style={{ flex: 1, padding: '8px', background: '#f5f5f3', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer', fontSize: 13 }}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
