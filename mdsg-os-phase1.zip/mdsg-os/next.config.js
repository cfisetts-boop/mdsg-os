/** @type {import('next').NextConfig} */
const nextConfig = {
  api: {
    bodyParser: false,
    responseLimit: '50mb',
  },
  experimental: {
    serverComponentsExternalPackages: ['pdf-parse'],
  },
}

module.exports = nextConfig
