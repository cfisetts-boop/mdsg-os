import Anthropic from '@anthropic-ai/sdk'
import { createClient } from '@supabase/supabase-js'
import ExcelJS from 'exceljs'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

// POST /api/parse-ct-quote — deterministic parser for West USA countertop
// quote workbooks (one sheet per material; unit-type sets with per-set pricing)
export async function POST(request) {
  try {
    const jobId = request.headers.get('x-job-id')
    const formData = await request.formData()
    const file = formData.get('file')
    if (!file) return Response.json({ error: 'No file' }, { status: 400 })

    const fileNameL = (file.name || '').toLowerCase()

    // ── PDF path: fabricator estimates (Capo etc.) read by AI ────────────────
    if (fileNameL.endsWith('.pdf')) {
      const b64 = Buffer.from(await file.arrayBuffer()).toString('base64')
      const stream = anthropic.messages.stream({
        model: 'claude-opus-4-5',
        max_tokens: 4000,
        messages: [{
          role: 'user',
          content: [
            { type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: b64 } },
            { type: 'text', text: `This is a countertop fabricator estimate/quote. Extract as JSON only (no prose, no markdown fences):
{
  "fabricator": "company name",
  "quote_number": "estimate/quote number or empty",
  "sections": [{ "name": "e.g. Slabs / Kitchens / Vanities", "total": 0 }],
  "subtotal": 0,
  "tax": 0,
  "grand_total": 0,
  "total_sqft": 0
}
Rules: numbers as plain numbers without commas or $. If a value is absent use 0 or "". sections = the document's own groupings with their printed totals. grand_total = the final total including tax.` },
          ],
        }],
      })
      const msg = await stream.finalMessage()
      const raw = msg.content.filter(b => b.type === 'text').map(b => b.text).join('')
      let q
      try { q = JSON.parse(raw.replace(/```json|```/g, '').trim()) }
      catch { return Response.json({ error: 'Could not read this PDF as a countertop quote — is it a fabricator estimate?' }, { status: 422 }) }
      const grand = Number(q.grand_total) || 0
      const gross = Number(q.subtotal) || grand
      const tax   = Number(q.tax) || 0
      if (!grand) return Response.json({ error: 'No total found in PDF' }, { status: 422 })

      let recorded = false
      if (jobId) {
        const { error } = await supabase.from('manufacturer_quotes').insert({
          job_id: jobId, manufacturer: q.fabricator || 'CT Fabricator', quote_type: 'countertops',
          quote_number: q.quote_number || null,
          gross_amount: gross, tax_amount: tax, grand_total: grand,
          raw_extracted_json: q,
          file_name: file.name || 'CT Quote.pdf', parsed_at: new Date().toISOString(),
        })
        recorded = !error
        if (error) console.error('CT PDF quote insert FAILED:', error.message)
        await supabase.from('activity_log').insert({ job_id: jobId, user_name: 'MDSG', action: `CT quote parsed (PDF) — ${q.fabricator || 'Fabricator'} · ${fmtM(grand)}` })
      }
      return Response.json({
        success: true, recorded,
        fabricator: q.fabricator || 'CT Fabricator',
        total_amount: grand,
        material_type: (q.sections || []).map(s => s.name).join(', '),
        summary: {
          isOptions: false,
          materials: (q.sections || []).map(s => ({ code: s.name, items: 0, total: Number(s.total) || 0, sqft: 0 })),
          grandTotal: grand, totalSqft: Number(q.total_sqft) || 0, totalSets: 0, unitTypeCount: 0,
        },
      })
    }

    const wb = new ExcelJS.Workbook()
    await wb.xlsx.load(Buffer.from(await file.arrayBuffer()))

    const val = (ws, r, c) => {
      const v = ws.getCell(r, c).value
      if (v == null) return ''
      if (typeof v === 'object') return v.result ?? v.text ?? ''
      return v
    }
    const num = (x) => { const n = parseFloat(String(x).replace(/[^0-9.\-]/g, '')); return isNaN(n) ? 0 : n }

    const materials = []
    wb.eachSheet(ws => {
      // find header row
      let hr = 0
      for (let r = 1; r <= Math.min(ws.rowCount, 20); r++) {
        if (String(val(ws, r, 1)).trim().toUpperCase() === 'ITEM #') { hr = r; break }
      }
      if (!hr) return
      const items = []
      let sheetTotal = 0, sheetSqft = 0
      for (let r = hr + 1; r <= ws.rowCount; r++) {
        const c1 = String(val(ws, r, 1)).trim()
        const c13 = String(val(ws, r, 13)).trim().toUpperCase()
        if (c13 === 'TOTAL') { sheetTotal = num(val(ws, r, 14)); continue }
        if (c13.startsWith('TOTAL SQFT')) { sheetSqft = num(val(ws, r, 14)); continue }
        if (/^\d+$/.test(c1)) {
          const total = num(val(ws, r, 14))
          if (total > 0 || num(val(ws, r, 12)) > 0) {
            items.push({
              item: Number(c1),
              category: String(val(ws, r, 2)).trim(),
              material: String(val(ws, r, 3)).trim(),
              unit_type: String(val(ws, r, 4)).trim(),
              sets: num(val(ws, r, 12)),
              unit_price: Math.round(num(val(ws, r, 13)) * 100) / 100,
              total: Math.round(total * 100) / 100,
            })
          }
        }
      }
      if (items.length) {
        if (!sheetTotal) sheetTotal = items.reduce((s, i) => s + i.total, 0)
        materials.push({ material_code: ws.name, items, total: Math.round(sheetTotal * 100) / 100, sqft: sheetSqft })
      }
    })

    if (!materials.length) return Response.json({ error: 'No countertop pricing found — is this a West USA quote workbook?' }, { status: 422 })

    // Multiple sheets with near-identical sqft = ALTERNATIVE material options,
    // not additive scopes. Never sum options.
    const sqfts = materials.map(m => m.sqft).filter(Boolean)
    const isOptions = materials.length > 1 && sqfts.length === materials.length &&
      (Math.max(...sqfts) - Math.min(...sqfts)) / Math.max(...sqfts) < 0.02
    const primary    = materials[0]
    const grandTotal = isOptions ? primary.total : Math.round(materials.reduce((s, m) => s + m.total, 0) * 100) / 100
    const totalSqft  = isOptions ? primary.sqft : materials.reduce((s, m) => s + m.sqft, 0)
    const totalSets  = primary.items.reduce((x, i) => x + i.sets, 0)
    const unitTypes  = primary.items.filter(i => i.unit_type).map(i => i.unit_type)

    let recorded = false
    if (jobId) {
      const { error } = await supabase.from('manufacturer_quotes').insert({
        job_id: jobId, manufacturer: 'West USA International', quote_type: 'countertops',
        gross_amount: grandTotal, grand_total: grandTotal,  // primary option when multiple
        total_units: totalSets, raw_extracted_json: { materials, isOptions, grandTotal, totalSqft },
        file_name: file.name || 'CT Quote', parsed_at: new Date().toISOString(),
      })
      recorded = !error
      if (error) console.error('CT quote insert FAILED:', error.message)
      await supabase.from('activity_log').insert({ job_id: jobId, user_name: 'MDSG', action: `CT quote parsed — ${materials.length} material(s) · ${fmtM(grandTotal)} · ${totalSqft.toLocaleString()} sqft` })
    }

    return Response.json({
      success: true, recorded,
      // Compat fields for the fabricator-quote display block
      fabricator: 'West USA International',
      total_amount: grandTotal,
      material_type: isOptions ? `${materials.length} material options` : primary.material_code,
      summary: {
        isOptions,
        materials: materials.map(m => ({ code: m.material_code, items: m.items.length, total: m.total, sqft: m.sqft })),
        grandTotal, totalSqft, totalSets, unitTypeCount: new Set(unitTypes).size,
      },
    })
  } catch (err) {
    return Response.json({ error: err.message }, { status: 500 })
  }
}

const fmtM = (n) => '$' + Number(n).toLocaleString(undefined, { maximumFractionDigits: 0 })
