'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { supabase } from '@/lib/supabase'
import TakeoffEngine from './components/TakeoffEngine'
import CountertopCalc from './components/CountertopCalc'
import { calculateHardware, getSection, isAppliance } from '@/lib/hardwareUtils'
import AgentPipeline from './components/AgentPipeline'


// Merge duplicate unit_type rows — same name (accent-normalized) collapses into one,
// preferring the row with a manufacturer price and the highest cabinet count.
function mergeUnitTypes(rows) {
  const norm = s => (s || '').trim().toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
  const groups = {}
  ;[...rows].sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0)).forEach(ut => {
    const k = norm(ut.unit_type_name)
    if (!groups[k]) groups[k] = []
    groups[k].push(ut)
  })
  return Object.values(groups).map(g => {
    const priced   = g.find(r => (r.manufacturer_price || 0) > 0) || g[0]
    const maxQty   = Math.max(...g.map(r => r.unit_quantity || 1))
    const maxCabs  = Math.max(...g.map(r => r.cabinet_count || 0))
    const perUnit  = maxCabs > 0 && maxQty > 1 && maxCabs % maxQty === 0 && maxCabs / maxQty <= 60 ? maxCabs / maxQty : maxCabs
    const maxPrice = Math.max(...g.map(r => r.manufacturer_price || 0))
    return { ...priced, unit_quantity: maxQty, cabinet_count: perUnit, manufacturer_price: maxPrice }
  })
}

const STAGE_COLORS = {
  'RFQ':            { bg: '#EEEDFE', text: '#3C3489' },
  'Open Proposals': { bg: '#E6F1FB', text: '#0C447C' },
  'On Hold':        { bg: '#FAF3DA', text: '#7A6206' },
  'Awarded':        { bg: '#EAF3DE', text: '#3B6D11' },
  'Shop Drawings':  { bg: '#FAEEDA', text: '#633806' },
  'Ordered':        { bg: '#E6F1FB', text: '#0C447C' },
  'Delivered':      { bg: '#E1F5EE', text: '#085041' },
  'Closeout':       { bg: '#EAF3DE', text: '#27500A' },
  'Lost':           { bg: '#FCEBEB', text: '#A32D2D' },
  // Legacy stage names still render (existing jobs keep working until re-staged)
  'Bid':            { bg: '#EEEDFE', text: '#3C3489' },
  'Pricing':        { bg: '#E6F1FB', text: '#0C447C' },
  'Proposal Sent':  { bg: '#E6F1FB', text: '#0C447C' },
  'Active':         { bg: '#EEEDFE', text: '#3C3489' },
  'Rebid':          { bg: '#FAF3DA', text: '#7A6206' },
  'Installed':      { bg: '#EAF3DE', text: '#27500A' },
}

const SHIPMENT_STATUS_COLORS = {
  'Scheduled':  { bg: '#E6F1FB', text: '#0C447C' },
  'In Transit': { bg: '#FAEEDA', text: '#633806' },
  'Delivered':  { bg: '#EAF3DE', text: '#27500A' },
  'Delayed':    { bg: '#FCEBEB', text: '#A32D2D' },
}

const STAGES = ['RFQ', 'Open Proposals', 'On Hold', 'Awarded', 'Shop Drawings', 'Ordered', 'Delivered', 'Closeout', 'Lost']
const FRONT_STAGES = ['RFQ', 'Open Proposals', 'On Hold', 'Awarded']
const PRODUCTION_STAGES = ['Shop Drawings', 'Ordered', 'Delivered', 'Closeout']
const CARRIERS = ['UPS Freight', 'FedEx Freight', 'Old Dominion', 'XPO Logistics', 'Estes Express', 'R+L Carriers', 'Other']
const fmt = (n) => n ? '$' + Math.round(n).toLocaleString() : '—'
const OWNER_EMAILS = { Cole: 'cole@mdsgcabinets.com', Pam: 'pam@mdsgcabinets.com', Vicki: 'vicki@mdsgcabinets.com', Blake: 'csr@mdsgcabinets.com', Tabetha: 'tabetha@mdsgcabinets.com' }
const fmtD = (d) => { if (!d) return '—'; const [y, m, dd] = String(d).split('T')[0].split('-'); return y && m && dd ? `${Number(m)}/${Number(dd)}/${y.substring(2)}` : d }
const fmtPct = (n) => n ? (n * 100).toFixed(1) + '%' : '—'

const emptyShipment = {
  load_number: 1, total_loads: 1, carrier: 'UPS Freight',
  tracking_number: '', floors_covered: '', cabinet_count: '',
  scheduled_date: '', delivery_contact: '', notes: '', status: 'Scheduled',
}

export default function Home() {
  const [jobs, setJobs] = useState([])
  const [view, setView] = useState('dashboard')
  const [selectedJob, setSelectedJob] = useState(null)
  const [loading, setLoading] = useState(true)
  const [showNewJob, setShowNewJob] = useState(false)
  const [newJob, setNewJob] = useState({ name: '', gc_name: '', address: '', city: 'Denver', state: 'CO', owner: 'Cole', stage: 'Bid', manufacturer: 'TBD' })
  const [quoteUploading, setQuoteUploading] = useState(false)
  const [quoteResult, setQuoteResult] = useState(null)
  const [reminders, setReminders] = useState([])
  const [proposalSender, setProposalSender] = useState('Cole')
  const [proposalNotes, setProposalNotes] = useState('')
  const DEFAULT_CT_BID_SECTIONS = {
    includedInBid: 'Sales Tax  |  Delivery to Job Site  |  Sink cutouts per sink specifications',
    assembly: 'By Greenworks Renovations under separate contract — Contact: Anthony (Willy) Ramirez  |  619-718-1578  |  greenworksrenovationsllc@gmail.com',
    notIncluded: 'Installation — under separate contract with Greenworks Renovations\nPlumbing connections, faucets, undermount sink brackets\nTile backsplash installation or materials\nModel unit "Out of Phase" delivery',
    bottomNotes: 'Final price subject to approved shop drawings. All quantities are estimated — field measurements and approved shop drawings will prevail.',
  }
  const [ctSender,      setCtSender]      = useState('Cole')
  const [ctWastePct,    setCtWastePct]    = useState(10)
  const [ctMargin,      setCtMargin]      = useState(20)
  const [ctGross,       setCtGross]       = useState('')
  const [ctNotes,       setCtNotes]       = useState('')
  const [ctBidSections, setCtBidSections] = useState(DEFAULT_CT_BID_SECTIONS)
  const DEFAULT_BID_SECTIONS = {
    includedInBid: 'Sales Tax  |  Delivery to Job Site',
    assembly: 'By Greenworks Renovations under separate contract — Contact: Anthony (Willy) Ramirez  |  619-718-1578  |  greenworksrenovationsllc@gmail.com',
    notIncluded: 'Installation — under separate contract with Greenworks Renovations\nAttic stock, locks, labor, shims, screws, supports, grommets, castors, blocking or backing\nCrown molding, scribe or base shoe unless included in writing\nRecessed linen cabinets, desks, entry benches, floating shelves or undercabinet lighting unless included in writing\nModel unit "Out of Phase" delivery',
    bottomNotes: 'Final price subject to approved shop drawings. The first red-line revision is free — subsequent revisions subject to additional fees.',
    aliases: '',
  }
  const [bidSections, setBidSections] = useState(DEFAULT_BID_SECTIONS)
  useEffect(() => {
    setBidSections(selectedJob?.proposal_sections ? { ...DEFAULT_BID_SECTIONS, ...selectedJob.proposal_sections } : DEFAULT_BID_SECTIONS)
    setProposalGross(selectedJob?.manufacturer_gross_cost > 0 ? String(selectedJob.manufacturer_gross_cost) : '')
    setSowRows(Array.isArray(selectedJob?.scope_of_work) ? selectedJob.scope_of_work : null)
    setSowEditing(false)
    setPaRows(Array.isArray(selectedJob?.post_award) ? selectedJob.post_award : null)
    setPaEditing(false)
    if (selectedJob?.id && selectedJob.activity_log === undefined) {
      Promise.all([
        supabase.from('activity_log').select('*').eq('job_id', selectedJob.id),
        supabase.from('reminders').select('*').eq('job_id', selectedJob.id),
      ]).then(([a, r]) => setSelectedJob(prev => prev && prev.id === selectedJob.id
        ? { ...prev, activity_log: a.data || [], reminders: r.data || [] } : prev))
    }
    setSavedQuotes([])
    if (selectedJob?.id) fetch('/api/quotes?jobId=' + selectedJob.id).then(r=>r.json()).then(d=>{
      setSavedQuotes(d.quotes || [])
      const wq = (d.quotes || []).find(q => q.id === selectedJob.working_quote_id)
      if (wq) applyQuoteToProposal(wq)
    }).catch(()=>{})
    setProposalFreight(selectedJob?.freight_cost > 0 ? String(selectedJob.freight_cost) : '')
    setProposalMfrTax('')
    setJobFiles([])
    setCabList(null)
    if (selectedJob?.id) {
      setFilesLoading(true)
      fetch('/api/job-files?jobId=' + selectedJob.id)
        .then(r => r.json()).then(d => { setJobFiles(d.files || []); setFilesLoading(false) })
        .catch(() => setFilesLoading(false))
      setCabListLoading(true)
      fetch('/api/cab-list?jobId=' + selectedJob.id)
        .then(r => r.json()).then(d => {
          setCabList(d.cabList || null); setCabLoadedAt(d.updatedAt || null); setCabListLoading(false)
          const uts = d.cabList?.unit_types || []
          const pieces = uts.reduce((s,u)=>s+(u.skus||[]).reduce((x,r2)=>x+(Number(r2.hardware_count)||0)*(Number(r2.quantity_per_unit)||0),0)*(Number(u.unit_quantity)||1),0)
          if (pieces > 0) setHwPieces(String(pieces))
          const leedo = d.cabList?.leedo
          if (leedo?.freight > 0) setProposalFreight(String(leedo.freight))
          if (leedo?.grandTotal > 0 && leedo?.grossAmount > 0) {
            const t = Math.max(0, leedo.grandTotal - leedo.grossAmount - (leedo.freight || 0))
            if (t > 0) setProposalMfrTax(t.toFixed(2))
          }
        })
        .catch(() => setCabListLoading(false))
      setCabEditing(false); setCabDraft(null)
    }
  }, [selectedJob?.id])
  const [proposalMargin, setProposalMargin] = useState(20)
  const [proposalGross,  setProposalGross]  = useState('')
  const [proposalFreight, setProposalFreight] = useState('')
  const [proposalMfrTax,  setProposalMfrTax]  = useState('')
  const [applyDiscount,   setApplyDiscount]   = useState(true)
  const [hwPieces,        setHwPieces]        = useState('')
  const [hwRate,          setHwRate]          = useState('4.00')
  const [quoteCheck,      setQuoteCheck]      = useState(null)
  const [quoteChecking,   setQuoteChecking]   = useState(false)
  const [skuSuggest,      setSkuSuggest]      = useState([])
  const [productLine,     setProductLine]     = useState('framed')
  const [hideUnitPricing, setHideUnitPricing] = useState(false)
  const [totalOnly,       setTotalOnly]       = useState(false)
  const [brandAs,         setBrandAs]         = useState('mdsg')
  const [discountPct,     setDiscountPct]     = useState('')
  const [rfqImporting,    setRfqImporting]    = useState(false)
  const [specLib,         setSpecLib]         = useState([])
  const [libUploading,    setLibUploading]    = useState(false)
  const [litSelected,     setLitSelected]     = useState([])
  const [kanbanSort,      setKanbanSort]      = useState('date')
  const [kanbanOwner,     setKanbanOwner]     = useState('all')
  const [sowRows,         setSowRows]         = useState(null)
  const [sowEditing,      setSowEditing]      = useState(false)
  const [sowSaving,       setSowSaving]       = useState(false)
  const [authSession,     setAuthSession]     = useState(undefined)   // undefined=checking, null=logged out
  const [authProfile,     setAuthProfile]     = useState(null)
  const [loginEmail,      setLoginEmail]      = useState('')
  const [loginPw,         setLoginPw]         = useState('')
  const [loginErr,        setLoginErr]        = useState('')
  const [loginBusy,       setLoginBusy]       = useState(false)
  const [savedQuotes,      setSavedQuotes]      = useState([])
  const [propQuoteId,      setPropQuoteId]      = useState('')
  const [collapsed,        setCollapsed]        = useState({})
  const tog = (k) => setCollapsed(c => ({ ...c, [k]: !c[k] }))
  const Chevron = ({ k }) => <button onClick={()=>tog(k)} style={{ background:'none', border:'none', cursor:'pointer', fontSize:13, color:'#999', padding:'0 6px 0 0' }}>{collapsed[k] ? '▸' : '▾'}</button>
  const [paRows,          setPaRows]          = useState(null)
  const [paEditing,       setPaEditing]       = useState(false)
  const [paSaving,        setPaSaving]        = useState(false)
  const [emailOpen,       setEmailOpen]       = useState(false)
  const [emailTo,         setEmailTo]         = useState('')
  const [emailCc,         setEmailCc]         = useState('')
  const [emailSubject,    setEmailSubject]    = useState('')
  const [emailBody,       setEmailBody]       = useState('')
  const [emailSending,    setEmailSending]    = useState(false)
  const [emailResult,     setEmailResult]     = useState(null)
  const [emailAttachQuote, setEmailAttachQuote] = useState(true)
  const [emailFollowUp,   setEmailFollowUp]   = useState('')
  const [sigEditing,      setSigEditing]      = useState(false)
  const [sigDraft,        setSigDraft]        = useState('')
  const REP_QUICKPICKS = [
    ['Richard Knudson', 'rk@eclipsesalesgroup.com'],
    ['Lorine Dockstader', 'ld@eclipsesalesgroup.com'],
  ]
  const PA_TEMPLATE = [
    ['CONTRACT', 'Scope list review & schedule of deliveries'],
    ['CONTRACT', 'Review & negotiate contract changes'],
    ['CONTRACT', 'Receive contract from GC'],
    ['CONTRACT', 'Execute contract & return to GC for signature'],
    ['COI', 'Order COI from Erin at Pacific'],
    ['COI', 'Receive COI & forward to GC'],
    ['SUBMITTALS', 'Samples submitted — cabinets'],
    ['SUBMITTALS', 'Samples submitted — countertops'],
    ['SHOP DRAWINGS', 'Prepare shop drawings'],
    ['SHOP DRAWINGS', 'Send to GC for approval / red-line'],
    ['SHOP DRAWINGS', 'Red-line changes made & resubmitted (if needed)'],
    ['SHOP DRAWINGS', 'Shops APPROVED'],
    ['ORDER', 'Prepare order — double-check against approved shops'],
    ['ORDER', 'Send order to manufacturer'],
    ['ORDER', 'Receive acknowledgement — double-check against approved shops'],
    ['ORDER', 'Confirm order'],
    ['ORDER', 'Confirm delivery dates'],
    ['ORDER', 'Request deposits (imports: deposit w/ order + balance before delivery)'],
    ['DELIVERY', 'Communicate with GC and Willy (installer)'],
    ['DELIVERY', 'Call-ahead requested — Willy schedules crew'],
    ['DELIVERY', 'Follow up GC + Willy on delivery changes'],
    ['DELIVERY', 'Weekly GC check for delivery updates'],
    ['CLOSEOUT', 'Deliveries completed'],
    ['CLOSEOUT', 'Invoice / Textura for materials delivered'],
    ['CLOSEOUT', 'Willy punch complete — additional materials identified'],
    ['CLOSEOUT', 'Change order (if GC responsibility): prepared, executed, material ordered'],
  ]
  const sowTemplate = () => {
    const j = selectedJob || {}
    return [
      ['— MDSG CONTACT —', ''],
      ['MDSG SALES CONTACT', authProfile?.name || j.owner || ''],
      ['TELEPHONE', ''],
      ['EMAIL', authProfile?.email || ''],
      ['— GENERAL CONTRACTOR —', ''],
      ['GENERAL CONTRACTOR', j.gc_name || ''],
      ['PROJECT MANAGER', j.gc_contact || ''],
      ['TELEPHONE', j.gc_phone || ''],
      ['EMAIL', j.gc_email || ''],
      ['SITE CONTACT', ''], ['SITE TELEPHONE', ''], ['SITE EMAIL', ''],
      ['— CABINETS —', ''],
      ['DOOR STYLE', j.door_style || ''],
      ['COLOR', j.finish_color || ''],
      ['BOX CONSTRUCTION', j.cabinet_construction || j.box_construction || ''],
      ['DRAWER BOX & GLIDE', j.drawer_box || ''],
      ['HINGES', j.hinge_type || ''],
      ['MANUFACTURER CONTACT', j.manufacturer || ''],
      ['ESTIMATED DELIVERY DATE', j.est_delivery || ''],
      ['NUMBER OF TRUCKLOADS', ''],
      ['— COUNTERTOPS: KITCHEN —', ''],
      ['MATERIAL (QUARTZ/GRANITE/SOLID SURFACE)', ''], ['2 OR 3 CM', ''], ['MANUFACTURER/SUPPLIER', ''], ['COLOR/FINISH', ''], ['EDGE FINISH', ''],
      ['— COUNTERTOPS: BATH —', ''],
      ['MATERIAL (QUARTZ/GRANITE/SOLID SURFACE)', ''], ['2 OR 3 CM', ''], ['MANUFACTURER/SUPPLIER', ''], ['COLOR/FINISH', ''], ['EDGE FINISH', ''],
      ['— COUNTERTOPS: AMENITIES —', ''],
      ['MATERIAL (QUARTZ/GRANITE/SOLID SURFACE)', ''], ['2 OR 3 CM', ''], ['MANUFACTURER/SUPPLIER', ''], ['COLOR/FINISH', ''], ['EDGE FINISH', ''],
      ['CT SUPPLIER/FABRICATOR CONTACT', ''],
      ['CT ESTIMATED DELIVERY DATE', ''],
      ['NUMBER OF CONTAINERS/DELIVERIES', ''],
      ['— SINKS —', ''],
      ['UNIT KITCHEN: MANUFACTURER/MODEL', ''], ['UNIT KITCHEN: UNDERMOUNT/DROP-IN', ''],
      ['UNIT BATHS: MANUFACTURER/MODEL', ''], ['UNIT BATHS: UNDERMOUNT/DROP-IN', ''],
      ['AMENITIES: MANUFACTURER/MODEL', ''], ['AMENITIES: UNDERMOUNT/DROP-IN', ''],
      ['— INSTALLATION —', ''],
      ['INSTALLATION (YES/NO)', ''],
      ['INSTALLER & CONTACT', 'Greenworks — Willy Ramirez · 619-718-1578'],
    ]
  }
  const DOOR_STYLES = {
    framed: ['CHANNING','COVINGTON','PERRYTON','ROSSER','CANYON','HARDIN','RIDGELAND','ALLIANCE 5-PC','ASHTON','AUSTIN','CONCORD SHAKER','PARKER','RIVERSIDE 5-PC','SLATON','FILLMORE','HARTFORD SHAKER','RADISSON','RAINIER','FOSTER','MIDWAY','SAVOY','TAYLOR','VANCOUVER','SHELBY','LUCINA','HUNTINGTON','SHELDON'],
    frameless: ['CHATEAU','COSTA','PRATO','RISANO','ALTO 5-PC','ASTRA','CAVA','PARC','SIENA','CORSO','FORTE','SORANO','TORANO','VITTORIA','LUCERNE'],
  }
  const DOOR_FINISHES = ['TruWhite','Arbor Grey','Graphite','Linen','Mid Grey','Midnight Navy','Onyx','Sagebrush','Ash','Caramel','Chestnut','Espresso','Harvest','Java','Natural','Oyster','Sable','Alabaster','Baritone','Charwood','Coastal Grey','Driftwood','Libretti','Linea Black','Pebblebrook','Sagestone','Sandy Alder','Steel Grey','Urban Walnut','Vintage Grey','White Satin','Wood Grain White','Morning Fog','Natural Elm','Weathered Oak','Light Teak','Texas Cypress','Midnight Teak','Glacier','Grey Cashmere','Harmony','Obsidian Ash','Timeless','White Tusk']
  const DRAWER_BOXES = {
    framed: ['PB Standard','PB Undermount w/Soft Close','PW Standard','PW Dovetail Standard','PW Dovetail w/Undermount Soft Close'],
    frameless: ['PB','PB Undermount Soft Close','Double Wall Metal Soft Close','PW Dovetail w/Undermount Soft Close'],
  }
  const FILE_CATEGORIES = ['Drawings', 'Floor Plans (Redacted)', 'Contract', 'COI', 'Shop Drawings', 'Acknowledgement', 'Quote', 'Change Order', 'Proposal', 'Photo', 'Other']
  const [jobFiles,       setJobFiles]       = useState([])
  const [filesLoading,   setFilesLoading]   = useState(false)
  const [fileUploading,  setFileUploading]  = useState(false)
  const [fileCategory,   setFileCategory]   = useState('Drawings')
  const CAB_CATEGORIES = ['BASES', 'VANITIES', 'WALLS', 'TALLS', 'ACCESSORIES', 'HARDWARE ALLOWANCES']
  const normCat = (c) => (c === 'TRIM' || c === 'MOLDING' || !c) ? null : c
  const [cabList,        setCabList]        = useState(null)
  const [cabListLoading, setCabListLoading] = useState(false)
  const [cabSeeding,     setCabSeeding]     = useState(false)
  const [cabEditing,     setCabEditing]     = useState(false)
  const [cabDraft,       setCabDraft]       = useState(null)
  const [cabLoadedAt,    setCabLoadedAt]    = useState(null)
  const [cabSaving,      setCabSaving]      = useState(false)
  const [cabExporting,   setCabExporting]   = useState(false)
  const [cabCopyTarget,  setCabCopyTarget]  = useState('')
  const [jobSearch,      setJobSearch]      = useState('')
  const [ownerFilter,    setOwnerFilter]    = useState('All')
  const [gcFilter,       setGcFilter]       = useState('All')
  const [proposalSalesTax, setProposalSalesTax] = useState(9.15)
  const [proposalLoading, setProposalLoading] = useState(false)
  const [stageUpdating, setStageUpdating] = useState(false)
  const [showReminderForm, setShowReminderForm] = useState(false)
  const [newReminder, setNewReminder] = useState({ due_date: '', reminder_type: 'Bid Follow-up', message: '', assigned_to: 'Cole' })
  const [editingProposal, setEditingProposal] = useState(false)
  const [editFields, setEditFields] = useState({})
  const [editUnitTypes, setEditUnitTypes] = useState([])
  const [additionalLineItems, setAdditionalLineItems] = useState([])
  const [savingEdits, setSavingEdits] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [deletingJob, setDeletingJob] = useState(false)

  // Countertop state
  const [ctSavedData,       setCtSavedData]       = useState(null)
  const [ctQuoteUploading,  setCtQuoteUploading]  = useState(false)
  const [ctQuoteResult,     setCtQuoteResult]     = useState(null)
  const [ctMarkup,          setCtMarkup]          = useState(1.25)
  const [ctIncludeCabinets, setCtIncludeCabinets] = useState(true)
  const [ctGenerating,      setCtGenerating]      = useState(false)

  // Shipment state
  const [shipments, setShipments] = useState([])
  const [allActiveShipments, setAllActiveShipments] = useState([])
  const [showShipmentForm, setShowShipmentForm] = useState(false)
  const [newShipment, setNewShipment] = useState(emptyShipment)
  const [editingShipment, setEditingShipment] = useState(null)
  const [savingShipment, setSavingShipment] = useState(false)

  const loadJobs = useCallback(async () => {
    setLoading(true)
    const { data } = await supabase
      .from('jobs')
      .select('*, unit_types(*)')
      .order('created_at', { ascending: false })
    if (data) setJobs(data)
    setLoading(false)
  }, [])

  const loadReminders = useCallback(async () => {
    const res = await fetch('/api/reminders')
    const data = await res.json()
    if (Array.isArray(data)) setReminders(data)
  }, [])

  const loadAllActiveShipments = useCallback(async () => {
    const res = await fetch('/api/shipments')
    const data = await res.json()
    if (Array.isArray(data)) setAllActiveShipments(data)
  }, [])

  const loadJobShipments = useCallback(async (jobId) => {
    const res = await fetch(`/api/shipments?jobId=${jobId}`)
    const data = await res.json()
    if (Array.isArray(data)) setShipments(data)
  }, [])

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setAuthSession(data.session ?? null))
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setAuthSession(s ?? null))
    return () => sub.subscription.unsubscribe()
  }, [])

  const visibleJobs = authProfile?.scope === 'own' ? jobs.filter(j => j.owner === authProfile.name) : jobs

  useEffect(() => {
    if (!authSession?.user?.email) { setAuthProfile(null); return }
    supabase.from('user_profiles').select('*').eq('email', authSession.user.email).single()
      .then(({ data }) => setAuthProfile(data || { email: authSession.user.email, name: authSession.user.email.split('@')[0], role: 'sales' }))
  }, [authSession])

  const loadSpecLib = useCallback(async () => {
    const { data } = await supabase.from('spec_library').select('*').order('title')
    setSpecLib(data || [])
  }, [])
  useEffect(() => { if (authSession) { loadJobs(); loadReminders(); loadAllActiveShipments(); loadSpecLib() } }, [authSession, loadJobs, loadReminders, loadAllActiveShipments, loadSpecLib])
  useEffect(() => {
    if (!authSession) return
    const id = setInterval(() => { loadJobs() }, 60000)
    return () => clearInterval(id)
  }, [authSession, loadJobs])
  useEffect(() => {
    if (!selectedJob) return
    if (editingProposal || cabEditing || sowEditing || paEditing || emailOpen) return
    const fresh = jobs.find(j => j.id === selectedJob.id)
    if (!fresh) return
    const { activity_log, reminders: rem, ...bare } = selectedJob
    if (JSON.stringify(fresh) !== JSON.stringify(bare)) setSelectedJob({ ...fresh, activity_log, reminders: rem })
  }, [jobs])  // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (selectedJob) {
      setEditFields({
        name: selectedJob.name || '',
        door_style: selectedJob.door_style || '',
        drawer_box: selectedJob.drawer_box || '',
        cabinet_construction: selectedJob.cabinet_construction || '',
        interior_color: selectedJob.interior_color || '',
        shelf_thickness: selectedJob.shelf_thickness || '',
        hinge_type: selectedJob.hinge_type || '',
        finish_color: selectedJob.finish_color || '',
        box_construction: selectedJob.box_construction || '',
        hardware_allowance: selectedJob.hardware_allowance || 0,
        scope_notes: selectedJob.scope_notes || '',
        gc_name:      selectedJob.gc_name      || '',
        address:      selectedJob.address      || '',
        city:         selectedJob.city         || '',
        state:        selectedJob.state        || '',
        zip:          selectedJob.zip          || '',
        manufacturer: selectedJob.manufacturer || '',
        bid_due_date: selectedJob.bid_due_date || '',
        gc_contact:   selectedJob.gc_contact   || '',
        gc_phone:     selectedJob.gc_phone     || '',
        gc_email:     selectedJob.gc_email     || '',
        units_override:     selectedJob.units_override ?? '',
        amenities_override: selectedJob.amenities_override ?? '',
        est_delivery:       selectedJob.est_delivery || '',
        deliveries_count:   selectedJob.deliveries_count || '',
      })
      setEditUnitTypes(mergeUnitTypes(selectedJob.unit_types || []))
      setAdditionalLineItems([])
      setEditingProposal(false)
      setConfirmDelete(false)
      setCtSavedData(null)
      setCtQuoteResult(null)
      setShipments([])
      setShowShipmentForm(false)
      loadJobShipments(selectedJob.id)
      supabase.from('activity_log')
        .select('action, created_at')
        .eq('job_id', selectedJob.id)
        .like('action', '__CT_TAKEOFF__:%')
        .order('created_at', { ascending: false })
        .limit(1)
        .then(({ data }) => {
          if (data?.[0]) {
            try { setCtSavedData(JSON.parse(data[0].action.replace('__CT_TAKEOFF__:', ''))) } catch(_) {}
          }
        })
    }
  }, [selectedJob?.id, loadJobShipments])

  async function saveProposalEdits() {
    if (!selectedJob) return
    setSavingEdits(true)
    await supabase.from('jobs').update({
      name: editFields.name || selectedJob.name,
      door_style: editFields.door_style,
      drawer_box: editFields.drawer_box || null,
      cabinet_construction: editFields.cabinet_construction || null,
      interior_color: editFields.interior_color || null,
      shelf_thickness: editFields.shelf_thickness || null,
      hinge_type: editFields.hinge_type || null,
      finish_color: editFields.finish_color,
      box_construction: editFields.box_construction,
      hardware_allowance: Number(editFields.hardware_allowance) || 0,
      scope_notes: editFields.scope_notes,
      gc_name:      editFields.gc_name,
      address:      editFields.address,
      city:         editFields.city,
      state:        editFields.state,
      zip:          editFields.zip,
      manufacturer: editFields.manufacturer,
      units_override:     editFields.units_override !== '' && editFields.units_override != null ? Number(editFields.units_override) : null,
      amenities_override: editFields.amenities_override !== '' && editFields.amenities_override != null ? Number(editFields.amenities_override) : null,
      est_delivery:       editFields.est_delivery || null,
      deliveries_count:   editFields.deliveries_count || null,
      bid_due_date: editFields.bid_due_date || null,
      gc_contact:   editFields.gc_contact,
      gc_phone:     editFields.gc_phone,
      gc_email:     editFields.gc_email,
    }).eq('id', selectedJob.id)
    for (const ut of editUnitTypes) {
      await supabase.from('unit_types').update({ unit_quantity: ut.unit_quantity }).eq('id', ut.id)
    }
    await supabase.from('activity_log').insert({ job_id: selectedJob.id, user_name: 'Cole', action: 'Proposal details edited' })
    const { data } = await supabase.from('jobs').select('*, unit_types(*), activity_log(*), reminders(*)').eq('id', selectedJob.id).single()
    if (data) setSelectedJob(data)
    setSavingEdits(false)
    setEditingProposal(false)
    loadJobs()
  }

  async function createShipment() {
    if (!selectedJob) return
    setSavingShipment(true)
    const res = await fetch('/api/shipments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'create', job_id: selectedJob.id, user: 'Pam', ...newShipment }),
    })
    const result = await res.json()
    if (result.success) {
      setShowShipmentForm(false)
      setNewShipment(emptyShipment)
      loadJobShipments(selectedJob.id)
      loadAllActiveShipments()
      loadJobs()
    } else {
      alert('Error: ' + result.error)
    }
    setSavingShipment(false)
  }

  async function updateShipmentStatus(id, status, jobId) {
    await fetch('/api/shipments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update', id, status, job_id: jobId, user: 'Pam' }),
    })
    loadJobShipments(selectedJob?.id || jobId)
    loadAllActiveShipments()
    loadJobs()
  }

  async function saveShipmentEdit() {
    if (!editingShipment) return
    setSavingShipment(true)
    await fetch('/api/shipments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update', ...editingShipment, user: 'Pam' }),
    })
    setEditingShipment(null)
    loadJobShipments(selectedJob.id)
    loadAllActiveShipments()
    setSavingShipment(false)
  }

  async function deleteShipment(id) {
    if (!confirm('Delete this shipment record?')) return
    await fetch('/api/shipments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'delete', id }),
    })
    loadJobShipments(selectedJob.id)
    loadAllActiveShipments()
  }

  async function createJob() {
    if (!newJob.name) return alert('Job name is required')
    const { data, error } = await supabase.from('jobs').insert(newJob).select().single()
    if (error) return alert('Error: ' + error.message)
    await supabase.from('activity_log').insert({ job_id: data.id, user_name: newJob.owner, action: `Job created — ${newJob.name}` })
    setShowNewJob(false)
    setNewJob({ name: '', gc_name: '', address: '', city: 'Denver', state: 'CO', owner: 'Cole', stage: 'Bid', manufacturer: 'TBD' })
    loadJobs()
  }

  async function deleteJob() {
    if (!selectedJob) return
    setDeletingJob(true)
    await supabase.from('activity_log').delete().eq('job_id', selectedJob.id)
    await supabase.from('reminders').delete().eq('job_id', selectedJob.id)
    await supabase.from('cabinet_line_items').delete().eq('job_id', selectedJob.id)
    await supabase.from('unit_types').delete().eq('job_id', selectedJob.id)
    await supabase.from('shipments').delete().eq('job_id', selectedJob.id)
    await supabase.from('jobs').delete().eq('id', selectedJob.id)
    setDeletingJob(false)
    setConfirmDelete(false)
    setSelectedJob(null)
    setView('jobs')
    loadJobs()
  }

  async function handleQuoteUpload(e) {
    const file = e.target.files[0]
    if (!file || !file.name.endsWith('.pdf')) return alert('Please select a PDF file')
    if (!selectedJob) return alert('Select a job first')
    setQuoteUploading(true)
    setQuoteResult(null)
    const arrayBuffer = await file.arrayBuffer()
    const response = await fetch('/api/parse-quote', {
      method: 'POST',
      headers: { 'x-job-id': selectedJob.id, 'x-file-name': file.name, 'Content-Type': 'application/octet-stream' },
      body: arrayBuffer,
    })
    const result = await response.json()
    setQuoteUploading(false)
    if (result.success) {
      setQuoteResult(result)
      refreshSavedQuotes()
      loadJobs()
      const { data } = await supabase.from('jobs').select('*, unit_types(*), activity_log(*), reminders(*)').eq('id', selectedJob.id).single()
      if (data) setSelectedJob(data)
    } else {
      alert('Error parsing quote: ' + (result.error || 'Unknown error'))
    }
  }

  async function handleCtQuoteUpload(e) {
    const file = e.target.files[0]
    if (!file || !file.name.endsWith('.pdf')) return alert('Please select a PDF file')
    setCtQuoteUploading(true)
    const arrayBuffer = await file.arrayBuffer()
    const res = await fetch('/api/parse-countertop-quote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/pdf', 'x-job-id': selectedJob?.id || '' },
      body: arrayBuffer,
    })
    const result = await res.json()
    setCtQuoteUploading(false)
    if (result.success) {
      setCtQuoteResult(result)
      loadJobs()
    } else {
      alert('Error parsing quote: ' + (result.error || 'Unknown error'))
    }
  }

  async function saveCabList(list, source) {
    await fetch('/api/cab-list', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ jobId: selectedJob.id, cabList: list, source }) })
    setCabList(list)
  }

  async function seedCabListFromExcel(e) {
    const file = e.target.files?.[0]; if (!file) return
    setCabSeeding(true)
    try {
      const fd = new FormData()
      fd.append('files', file)
      const res = await fetch('/api/takeoff/excel', { method: 'POST', body: fd })
      const result = await res.json()
      if (result.success && result.data) {
        await saveCabList({ ...result.data, product_line: productLine }, 'seeded from Excel')
      } else {
        alert('Could not parse that file: ' + (result.error || 'unknown error'))
      }
    } catch (err) { alert('Seed failed: ' + err.message) }
    setCabSeeding(false); e.target.value = ''
  }

  async function importLeedoSummary(e) {
    const file = e.target.files?.[0]; if (!file) return
    setCabSeeding(true)
    try {
      const buf = await file.arrayBuffer()
      const res = await fetch('/api/parse-leedo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/octet-stream', 'x-job-id': selectedJob.id, 'x-file-name': file.name },
        body: buf,
      })
      const result = await res.json()
      if (result.success && result.cabList) {
        const v = result.cabList.verification || {}
        await saveCabList({ ...result.cabList, product_line: productLine }, 'Leedo summary import')
        refreshSavedQuotes()
        const msg = v.leedoUnits != null
          ? `Imported ${result.cabList.unit_types.length} unit types.\nLeedo summary says: ${v.leedoUnits} units / ${v.leedoCabinets} cabinets.\nParsed: ${v.parsedUnits} units / ${v.parsedCabs} total pieces (incl. accessories).${v.unitsMatch ? '\n✓ Unit counts match.' : '\n⚠ UNIT COUNT MISMATCH — review before sending for pricing.'}${v.quoteRecorded === false ? '\n⚠ Quote history NOT recorded — quote check will not see this import.' : v.quoteRecorded ? '\n✓ Recorded in quote history.' : ''}`
          : `Imported ${result.cabList.unit_types.length} unit types.`
        alert(msg)
      } else {
        alert('Leedo import failed: ' + (result.error || 'unknown error'))
      }
    } catch (err) { alert('Leedo import failed: ' + err.message) }
    setCabSeeding(false); e.target.value = ''
  }

  async function startBlankCabList() {
    await saveCabList({ project_name: selectedJob.name, product_line: productLine, unit_types: [], sheet_totals: null }, 'started blank')
  }

  async function fetchSkuSuggestions(q) {
    const line = (cabEditing ? cabDraft : cabList)?.product_line || 'framed'
    if (!q || q.length < 2) { setSkuSuggest([]); return }
    try {
      const r = await fetch(`/api/leedo-catalog?line=${line}&q=${encodeURIComponent(q)}`)
      const d = await r.json()
      setSkuSuggest(d.items || [])
    } catch { setSkuSuggest([]) }
  }

  function startCabEdit() {
    setCabDraft(JSON.parse(JSON.stringify(cabList)))  // deep copy
    setCabEditing(true)
  }
  function cabDraftUpdate(fn) {
    setCabDraft(d => { const n = JSON.parse(JSON.stringify(d)); fn(n); return n })
  }
  async function saveCabEdit() {
    setCabSaving(true)
    try {
      const res = await fetch('/api/cab-list', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobId: selectedJob.id, cabList: cabDraft, source: 'editor', baseUpdatedAt: cabLoadedAt }),
      })
      if (res.status === 409) {
        const d = await res.json()
        alert(d.message || 'Conflict — reload the job first.')
      } else if (res.ok) {
        setCabList(cabDraft); setCabEditing(false); setCabDraft(null)
        setCabLoadedAt(new Date().toISOString())
      } else {
        const d = await res.json(); alert('Save failed: ' + (d.error || 'unknown'))
      }
    } catch (err) { alert('Save failed: ' + err.message) }
    setCabSaving(false)
  }
  async function exportCabList() {
    if (!cabList) return
    setCabExporting(true)
    try {
      const base = { jobSpecs: { product_line: cabList?.product_line, door_style: selectedJob.door_style, finish_color: selectedJob.finish_color, drawer_box: selectedJob.drawer_box, cabinet_construction: selectedJob.cabinet_construction, box_construction: selectedJob.box_construction, interior_color: selectedJob.interior_color, shelf_thickness: selectedJob.shelf_thickness, hinge_type: selectedJob.hinge_type }, takeoffData: cabList, projectName: cabList.project_name || selectedJob.name, supplierName: cabList.specs?.cabinet_line || selectedJob.manufacturer || 'TBD', catalogRef: 'TBD', printDate: new Date().toLocaleDateString('en-US') }
      const safe = (cabList.project_name || selectedJob.name || 'Cabinet_Schedule').replace(/[^a-zA-Z0-9_-]/g, '_')
      const results = await Promise.all([['internal', 'Full_List'], ['manufacturer', 'Quote']].map(async ([mode, suffix]) => {
        const res = await fetch('/api/export/excel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...base, mode }) })
        if (!res.ok) throw new Error('Export failed (' + mode + ')')
        return [suffix, await res.blob()]
      }))
      for (const [suffix, blob] of results) {
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a'); a.href = url; a.download = safe + '_' + suffix + '.xlsx'; a.click(); URL.revokeObjectURL(url)
        await new Promise(r => setTimeout(r, 400))
      }
    } catch (err) { alert(err.message) }
    setCabExporting(false)
  }

  async function saveSow(rows) {
    setSowSaving(true)
    await supabase.from('jobs').update({ scope_of_work: rows }).eq('id', selectedJob.id)
    setSelectedJob({ ...selectedJob, scope_of_work: rows })
    setSowRows(rows); setSowSaving(false); setSowEditing(false)
    await supabase.from('activity_log').insert({ job_id: selectedJob.id, user_name: 'Cole', action: 'Scope of Work updated' })
  }

  async function handleCtQuoteUpload(e) {
    const file = e.target.files?.[0]
    if (!file) return
    setCtQuoteUploading(true); setCtQuoteResult(null)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const res = await fetch('/api/parse-ct-quote', { method: 'POST', headers: { 'x-job-id': selectedJob.id }, body: fd })
      const d = await res.json()
      setCtQuoteResult(d.error ? { error: d.error } : d)
      if (!d.error) { refreshSavedQuotes(); if (d.total_amount > 0) setCtGross(String(d.total_amount)) }
    } catch (err) { setCtQuoteResult({ error: err.message }) }
    setCtQuoteUploading(false)
    e.target.value = ''
  }

  const mySig = () => authProfile?.signature || `${authProfile?.name || ''}\nMDSG Cabinets`
  function openEmailPanel(kind = 'quote') {
    setEmailAttachQuote(kind === 'quote')
    setEmailFollowUp('')
    if (kind === 'generic') {
      setEmailSubject(`${selectedJob.name} — `)
      setEmailBody(`Hi,\n\n\n\nThank you,\n${mySig()}`)
      setEmailResult(null); setEmailOpen(true)
      return
    }
    setEmailSubject(`${selectedJob.name} — Cabinet List for Pricing`)
    setEmailBody(`Hi,\n\nPlease find attached the cabinet list for ${selectedJob.name} for pricing.\n\nProduct line: ${cabList?.product_line || 'framed'}. Please include freight and lead time with your quote.\n\nThank you,\n${mySig()}`)
    setEmailResult(null); setEmailOpen(true)
  }

  async function sendQuoteEmail() {
    setEmailSending(true); setEmailResult(null)
    try {
      let b64 = null
      if (emailAttachQuote && cabList) {
      // Build the Quote export server-side, attach as base64
      const res = await fetch('/api/export/excel', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobSpecs: { product_line: cabList?.product_line, door_style: selectedJob.door_style, finish_color: selectedJob.finish_color, drawer_box: selectedJob.drawer_box, cabinet_construction: selectedJob.cabinet_construction, box_construction: selectedJob.box_construction, interior_color: selectedJob.interior_color, shelf_thickness: selectedJob.shelf_thickness, hinge_type: selectedJob.hinge_type }, takeoffData: cabList, mode: 'manufacturer', projectName: selectedJob.name }),
      })
      if (!res.ok) throw new Error('Quote export failed')
      const blob = await res.blob()
      b64 = await new Promise((resolve, reject) => {
        const r = new FileReader()
        r.onload = () => resolve(r.result.split(',')[1])
        r.onerror = reject
        r.readAsDataURL(blob)
      })
      }
      const to = emailTo.split(/[,;]/).map(s => s.trim()).filter(Boolean)
      const cc = emailCc.split(/[,;]/).map(s => s.trim()).filter(Boolean)
      const resp = await fetch('/api/send-email', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jobId: selectedJob.id, to, cc,
          fromEmail: authProfile?.email, fromName: authProfile?.name,
          senderName: authProfile?.name,
          subject: emailSubject, body: emailBody,
          attachmentName: b64 ? `${selectedJob.name.replace(/[^a-zA-Z0-9]/g, '_')}_Quote.xlsx` : undefined,
          attachmentB64: b64 || undefined,
        }),
      })
      const d = await resp.json()
      setEmailResult(d.success ? { ok: true } : { error: d.error })
      if (d.success && emailFollowUp) {
        const nv = [...(selectedJob.tasks||[]), [`Follow up: ${emailSubject}`.substring(0, 120), authProfile?.name || 'Cole', emailFollowUp, false, null]]
        await supabase.from('jobs').update({ tasks: nv }).eq('id', selectedJob.id)
        setSelectedJob({ ...selectedJob, tasks: nv })
      }
    } catch (err) { setEmailResult({ error: err.message }) }
    setEmailSending(false)
  }

  async function savePa(rows) {
    setPaSaving(true)
    await supabase.from('jobs').update({ post_award: rows }).eq('id', selectedJob.id)
    setSelectedJob({ ...selectedJob, post_award: rows })
    setPaRows(rows); setPaSaving(false); setPaEditing(false)
  }
  function togglePaTask(i) {
    const rows = paRows.map((r, j) => j === i
      ? [r[0], r[1], !r[2], !r[2] ? new Date().toISOString().split('T')[0] : null]
      : r)
    setPaRows(rows); savePa(rows)
  }

  async function logContact(job) {
    const today = new Date().toISOString().split('T')[0]
    await supabase.from('jobs').update({ last_contacted_at: today }).eq('id', job.id)
    await supabase.from('activity_log').insert({ job_id: job.id, user_name: job.owner || 'Cole', action: 'Contact logged — GC follow-up' })
    loadJobs()
    if (selectedJob?.id === job.id) setSelectedJob({ ...selectedJob, last_contacted_at: today })
  }

  function applyQuoteToProposal(q) {
    if (!q) return
    setPropQuoteId(q.id)
    if (q.gross_amount > 0) setProposalGross(String(q.gross_amount))
    setProposalFreight(q.freight_amount > 0 ? String(q.freight_amount) : '')
    // Leedo rows: tax = grand − gross − freight; NexGen: tariff in tax_amount
    const tax = q.tax_amount > 0 ? q.tax_amount
      : (q.grand_total > 0 && q.gross_amount > 0 ? Math.max(0, Math.round((q.grand_total - q.gross_amount - (q.freight_amount || 0)) * 100) / 100) : 0)
    setProposalMfrTax(tax > 0 ? String(tax) : '')
  }

  function refreshSavedQuotes() {
    if (selectedJob?.id) fetch('/api/quotes?jobId=' + selectedJob.id).then(r=>r.json()).then(d=>setSavedQuotes(d.quotes || [])).catch(()=>{})
  }

  async function runQuoteCheck() {
    setQuoteChecking(true); setQuoteCheck(null)
    try {
      const r = await fetch('/api/quote-check?jobId=' + selectedJob.id)
      const d = await r.json()
      setQuoteCheck(d.error ? { error: d.error } : d)
    } catch (err) { setQuoteCheck({ error: err.message }) }
    setQuoteChecking(false)
  }

  async function copyCabListToJob() {
    if (!cabCopyTarget || !cabList) return
    const target = jobs.find(j => j.id === cabCopyTarget)
    if (!target) return
    // Warn if the target already has a list
    const check = await fetch('/api/cab-list?jobId=' + cabCopyTarget).then(r => r.json()).catch(() => ({}))
    if (check.cabList && !confirm(`${target.name} already has a cabinet list. Overwrite it?`)) return
    if (!check.cabList && !confirm(`Copy this cabinet list to ${target.name}?`)) return
    const copy = JSON.parse(JSON.stringify(cabList))
    copy.project_name = target.name
    const res = await fetch('/api/cab-list', {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobId: cabCopyTarget, cabList: copy, source: `copied from ${selectedJob.name}` }),
    })
    if (res.ok) { alert(`Copied to ${target.name}`); setCabCopyTarget('') }
    else alert('Copy failed')
  }

  async function uploadJobFile(e) {
    const file = e.target.files?.[0]; if (!file) return
    setFileUploading(true)
    try {
      const clean = file.name.replace(/[^a-zA-Z0-9._-]/g, '_')
      const path = `${selectedJob.id}/${fileCategory}__${Date.now()}_${clean}`
      const { error } = await supabase.storage.from('job-files').upload(path, file)
      if (error) { alert('Upload failed: ' + error.message); setFileUploading(false); e.target.value = ''; return }
      const r = await fetch('/api/job-files?jobId=' + selectedJob.id)
      const d = await r.json(); setJobFiles(d.files || [])
    } catch {}
    setFileUploading(false); e.target.value = ''
  }
  async function downloadJobFile(path, name) {
    const r = await fetch('/api/job-files', { method: 'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ path }) })
    const d = await r.json()
    if (d.url) { const a = document.createElement('a'); a.href = d.url; a.target='_blank'; a.download = name; a.click() }
  }
  async function deleteJobFile(path) {
    if (!confirm('Delete this file?')) return
    await fetch('/api/job-files', { method: 'DELETE', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ jobId: selectedJob.id, path }) })
    setJobFiles(f => f.filter(x => x.path !== path))
  }
  async function generateCtProposal() {
    if (!selectedJob) return
    if (!(Number(ctGross) > 0)) return alert('Enter or pick a countertop material cost first (upload a CT quote or type the cost)')
    setCtGenerating(true)
    try {
      const quoteTotal   = ctQuoteResult?.total_amount || 0
      const ctBidToGC    = quoteTotal * ctMarkup
      const unitTypesPayload = ctSavedData?.unitTypes || []
      const totalsPayload = {
        kSF:       ctSavedData?.kSF       || 0,
        vSF:       ctSavedData?.vSF       || 0,
        kLF:       ctSavedData?.kLF       || 0,
        vLF:       ctSavedData?.vLF       || 0,
        backLF:    ctSavedData?.backLF    || 0,
        sideSF:    ctSavedData?.sideSF    || 0,
        sidesLF:   ctSavedData?.sidesLF   || 0,
        cuts:      ctSavedData?.cuts      || 0,
        materialSF: (ctSavedData?.kSF||0) + (ctSavedData?.vSF||0) + (ctSavedData?.sideSF||0),
        totalLF:   (ctSavedData?.kLF||0) + (ctSavedData?.vLF||0),
      }
      const propConfig = {
        material_type: ctQuoteResult?.material_type || 'Countertop',
        fabricator:    ctQuoteResult?.fabricator    || '—',
        color:         ctQuoteResult?.color         || '',
        thickness:     '3CM',
        edge:          'Eased Edge',
        quote_total:   quoteTotal,
        markup:        ctMarkup,
        bid_to_gc:     ctBidToGC,
        include_cabinets: ctIncludeCabinets,
      }
      const res = await fetch('/api/generate-countertop-proposal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobId: selectedJob.id, unitTypes: unitTypesPayload, totals: totalsPayload, wastePct: ctWastePct, propConfig, sender: ctSender, bidSections: ctBidSections, marginPct: Number(ctMargin), grossCostOverride: Number(ctGross) || 0, notes: ctNotes, hideUnitPricing, totalOnly, brandAs }),
      })
      if (!res.ok) { const e = await res.json(); throw new Error(e.error || 'Failed') }
      const blob = await res.blob()
      const url  = URL.createObjectURL(blob)
      const a    = document.createElement('a'); a.href = url
      a.download = `MDSG-CT-Proposal-${selectedJob.name.replace(/[^a-z0-9]/gi,'-')}.pdf`
      a.click(); URL.revokeObjectURL(url)
      loadJobs()
    } catch (err) { alert('Error: ' + err.message) }
    setCtGenerating(false)
  }

  async function generateProposal() {
    if (!selectedJob) return
    setProposalLoading(true)
    try {
      const response = await fetch('/api/generate-proposal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobId: selectedJob.id, sender: proposalSender, notes: proposalNotes, marginPct: Number(proposalMargin), grossCostOverride: Number(proposalGross) || 0, salesTaxPct: Number(proposalSalesTax), additionalLineItems, bidSections, freightPassThrough: proposalFreight !== '' ? Number(proposalFreight) : null, mfrTaxPassThrough: proposalMfrTax !== '' ? Number(proposalMfrTax) : null, applyDealerDiscount: applyDiscount, dealerDiscountPct: discountPct, literaturePaths: litSelected.map(id => (specLib.find(s => s.id === id) || {}).file_path).filter(Boolean), hideUnitPricing, totalOnly, brandAs, hwPieces: Number(hwPieces) || 0, hwRate: Number(hwRate) || 4 }),
      })
      if (!response.ok) { const err = await response.json(); throw new Error(err.error || 'Failed') }
      // Persist the bid sections on the job so they reload next time (needs jobs.proposal_sections jsonb column)
      supabase.from('jobs').update({ proposal_sections: bidSections }).eq('id', selectedJob.id).then(() => {})
      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `MDSG-Proposal-${selectedJob.name.replace(/[^a-z0-9]/gi, '-')}.pdf`
      a.click()
      URL.revokeObjectURL(url)
      loadJobs()
      const { data } = await supabase.from('jobs').select('*, unit_types(*), activity_log(*), reminders(*)').eq('id', selectedJob.id).single()
      if (data) setSelectedJob(data)
    } catch (err) { alert('Error: ' + err.message) }
    setProposalLoading(false)
  }

  async function updateStage(newStage) {
    if (!selectedJob || stageUpdating) return
    setStageUpdating(true)
    const res = await fetch('/api/update-stage', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobId: selectedJob.id, stage: newStage, user: 'Cole' }),
    })
    const result = await res.json()
    if (result.success) { setSelectedJob(prev => ({ ...prev, stage: newStage })); loadJobs(); loadReminders() }
    setStageUpdating(false)
  }

  async function completeReminder(id) {
    await fetch('/api/reminders', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'complete', id }) })
    loadReminders()
  }

  async function createReminder() {
    if (!newReminder.due_date || !newReminder.message) return alert('Date and message required')
    await fetch('/api/reminders', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'create', job_id: selectedJob?.id, ...newReminder }) })
    setShowReminderForm(false)
    setNewReminder({ due_date: '', reminder_type: 'Bid Follow-up', message: '', assigned_to: 'Cole' })
    loadReminders()
  }

  // Effective bid value: Monday TOTAL first, else derived from cost + margin
  // OS-generated proposal figures FIRST, Monday columns as fallback
  const effVal = (j) => (Number(j.os_bid_value) > 0 ? Number(j.os_bid_value)
    : Number(j.bid_value) > 0 ? Number(j.bid_value)
    : (Number(j.manufacturer_gross_cost) > 0 && Number(j.gross_margin_pct) > 0 && Number(j.gross_margin_pct) < 95
        ? Number(j.manufacturer_gross_cost) / (1 - Number(j.gross_margin_pct) / 100) : 0))
  const effCost = (j) => (Number(j.os_cost_value) > 0 ? Number(j.os_cost_value) : Number(j.manufacturer_gross_cost) || 0)
  const BID_STAGES      = ['RFQ', 'Open Proposals', 'On Hold', 'Bid', 'Pricing', 'Proposal Sent']
  const CONTRACT_STAGES = ['Awarded', 'Shop Drawings', 'Ordered', 'Delivered', 'Closeout']
  const pipelineValue = jobs.filter(j => BID_STAGES.includes(j.stage)).reduce((s, j) => s + effVal(j), 0)
  const activeBids = jobs.filter(j => BID_STAGES.includes(j.stage)).length
  const contractValue = jobs.filter(j => CONTRACT_STAGES.includes(j.stage)).reduce((s, j) => s + effVal(j), 0)
  const contractCount = jobs.filter(j => CONTRACT_STAGES.includes(j.stage)).length
  // Blended margin: $-weighted across jobs where both value and cost are known
  const marginJobs = jobs.filter(j => !['Lost'].includes(j.stage) && effVal(j) > 0 && effCost(j) > 0)
  const mSell = marginJobs.reduce((s, j) => s + effVal(j), 0)
  const mCost = marginJobs.reduce((s, j) => s + effCost(j), 0)
  const avgMargin = mSell > 0 ? Math.max(0, Math.min(1, (mSell - mCost) / mSell)) : 0
  const overdueReminders = reminders.filter(r => r.due_date <= new Date().toISOString().split('T')[0])
  // Bid follow-ups: bid-stage job, due date ≥7 days past, no contact since due date
  const todayISO = new Date().toISOString().split('T')[0]
  const daysPast = (d) => Math.floor((new Date(todayISO) - new Date(d)) / 86400000)
  // Milestones: 7-day, 1-month, 2-month past bid due; reappears at each unless contacted after that milestone
  const FOLLOWUP_MILESTONES = [[7, '7-day'], [30, '1-month'], [60, '2-month']]
  const visibleReminders = reminders.filter(r => !r.job_id || jobs.some(j => j.id === r.job_id))
  const customFollowUps = jobs.filter(j => j.next_followup_date && j.next_followup_date <= todayISO && !['Lost','Closeout'].includes(j.stage))
    .map(j => ({ ...j, __days: daysPast(j.next_followup_date), __milestone: 'scheduled' }))
  const followUps = jobs.map(j => {
    if (!['Open Proposals', 'Proposal Sent', 'On Hold'].includes(j.stage) || !j.bid_due_date) return null
    const days = daysPast(j.bid_due_date)
    let active = null
    for (const [ms, label] of FOLLOWUP_MILESTONES) {
      if (days < ms) break
      const msDate = new Date(new Date(j.bid_due_date).getTime() + ms * 86400000).toISOString().split('T')[0]
      if (!j.last_contacted_at || j.last_contacted_at < msDate) active = { ms, label, msDate }
    }
    return active ? { ...j, __days: days, __milestone: active.label } : null
  }).filter(Boolean)
    .concat(customFollowUps)
    .filter((j, i, arr) => arr.findIndex(x => x.id === j.id) === i)
    .sort((a, b) => b.__days - a.__days)
  const marginPricePreview = Number(proposalGross) > 0 && Number(proposalMargin) > 0 && Number(proposalMargin) < 95 ? '$' + Math.round(Number(proposalGross) / (1 - Number(proposalMargin) / 100)).toLocaleString() : null
  const inTransitCount = allActiveShipments.filter(s => s.status === 'In Transit').length
  const delayedCount = allActiveShipments.filter(s => s.status === 'Delayed').length

  async function doLogin(e) {
    e.preventDefault(); setLoginBusy(true); setLoginErr('')
    const { error } = await supabase.auth.signInWithPassword({ email: loginEmail.trim(), password: loginPw })
    if (error) setLoginErr(error.message)
    setLoginBusy(false)
  }

  if (authSession === undefined) {
    return <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'-apple-system, sans-serif', color:'#888' }}>Loading…</div>
  }
  if (authSession === null) {
    return (
      <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'#f5f5f3', fontFamily:'-apple-system, sans-serif' }}>
        <form onSubmit={doLogin} style={{ background:'#fff', borderRadius:14, padding:36, width:340, boxShadow:'0 4px 24px rgba(0,0,0,0.08)' }}>
          <div style={{ fontSize:22, fontWeight:600, color:'#3C3489', marginBottom:4 }}>MDSG OS</div>
          <div style={{ fontSize:12, color:'#888', marginBottom:22 }}>Sign in to continue</div>
          <label style={{ fontSize:11, color:'#888', fontWeight:600 }}>EMAIL</label>
          <input type="email" value={loginEmail} onChange={e2=>setLoginEmail(e2.target.value)} required style={{ width:'100%', padding:'10px 12px', border:'0.5px solid #ccc', borderRadius:8, fontSize:14, margin:'4px 0 14px', boxSizing:'border-box' }}/>
          <label style={{ fontSize:11, color:'#888', fontWeight:600 }}>PASSWORD</label>
          <input type="password" value={loginPw} onChange={e2=>setLoginPw(e2.target.value)} required style={{ width:'100%', padding:'10px 12px', border:'0.5px solid #ccc', borderRadius:8, fontSize:14, margin:'4px 0 18px', boxSizing:'border-box' }}/>
          {loginErr && <div style={{ fontSize:12, color:'#A32D2D', marginBottom:12 }}>{loginErr}</div>}
          <button type="submit" disabled={loginBusy} style={{ width:'100%', padding:'11px', background:'#3C3489', color:'#fff', border:'none', borderRadius:8, fontSize:14, fontWeight:500, cursor:'pointer' }}>{loginBusy ? 'Signing in…' : 'Sign In'}</button>
        </form>
      </div>
    )
  }

  const nav = (id, label) => (
    <div onClick={() => { setView(id); if (id !== 'job-detail') setSelectedJob(null) }}
      style={{ padding: '8px 16px', cursor: 'pointer', fontSize: 13,
        color: view === id ? '#1a1a1a' : '#666',
        background: view === id ? '#f5f5f3' : 'transparent',
        borderLeft: view === id ? '2px solid #3C3489' : '2px solid transparent',
        fontWeight: view === id ? 500 : 400 }}>
      {label}
    </div>
  )

  const inp = { width: '100%', padding: '7px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 12, boxSizing: 'border-box' }
  const lbl = { fontSize: 10, color: '#888', display: 'block', marginBottom: 3, textTransform: 'uppercase', letterSpacing: 0.4 }
  const card = { background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 20, marginBottom: 16 }

  const ShipmentBadge = ({ status }) => {
    const c = SHIPMENT_STATUS_COLORS[status] || SHIPMENT_STATUS_COLORS['Scheduled']
    return <span style={{ background: c.bg, color: c.text, borderRadius: 10, padding: '2px 8px', fontSize: 10, fontWeight: 500 }}>{status}</span>
  }

  const StatusButtons = ({ shipment }) => (
    <div style={{ display: 'flex', gap: 4 }}>
      {['Scheduled', 'In Transit', 'Delivered', 'Delayed'].map(s => (
        <button key={s} onClick={() => updateShipmentStatus(shipment.id, s, shipment.job_id)}
          style={{ padding: '3px 8px', fontSize: 10, borderRadius: 6, cursor: 'pointer',
            background: shipment.status === s ? SHIPMENT_STATUS_COLORS[s].bg : '#f5f5f3',
            color: shipment.status === s ? SHIPMENT_STATUS_COLORS[s].text : '#888',
            border: shipment.status === s ? `1px solid ${SHIPMENT_STATUS_COLORS[s].text}` : '0.5px solid #ddd',
            fontWeight: shipment.status === s ? 600 : 400 }}>
          {s}
        </button>
      ))}
    </div>
  )

  return (
    <div style={{ display: 'flex', height: '100vh', fontFamily: 'system-ui, sans-serif', fontSize: 14, background: '#f5f5f3' }}>

      {/* Sidebar */}
      <div style={{ width: 200, background: '#fff', borderRight: '0.5px solid #e5e5e0', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: 16, borderBottom: '0.5px solid #e5e5e0' }}>
          <div style={{ fontWeight: 600, fontSize: 13 }}>MDSG OS</div>
          <div style={{ fontSize: 11, color: '#888', marginTop: 2 }}>Manufacturer Direct Sales</div>
        </div>
        <div style={{ padding: '8px 0', flex: 1 }}>
          {authProfile && (
            <div style={{ padding: '6px 16px 10px', fontSize: 11, color: '#888', display:'flex', alignItems:'center', gap:8 }}>
              <span style={{ width:22, height:22, borderRadius:'50%', background:'#3C3489', color:'#fff', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:11, fontWeight:600 }}>{(authProfile.name||'?')[0]}</span>
              <span style={{ flex:1 }}>{authProfile.name} · {authProfile.role}</span>
              <span onClick={() => supabase.auth.signOut()} style={{ cursor:'pointer', color:'#A32D2D' }}>Sign out</span>
            </div>
          )}
          {nav('dashboard', 'Dashboard')}
          {nav('jobs', 'Jobs')}
          {nav('contacts', 'Contractors')}
          {nav('reports', 'Reports')}
          {nav('financials', 'Financials')}
          {nav('library', 'Spec Library')}
          {nav('agent-pipeline', '⚡ Agent Pipeline')}
          {nav('takeoff', 'Upload Mfr Quote')}
          {nav('shipments', `Shipments${inTransitCount > 0 ? ` (${inTransitCount})` : ''}`)}
          {nav('reminders', `Reminders${visibleReminders.length > 0 ? ` (${visibleReminders.length})` : ''}`)}
        </div>
        <div style={{ padding: '12px 16px', borderTop: '0.5px solid #e5e5e0' }}>
          <div style={{ fontWeight: 500, fontSize: 12 }}>Cole Isetts</div>
          <div style={{ color: '#888', fontSize: 11 }}>Sales · Aurora, CO</div>
        </div>
      </div>

      {/* Main */}
      <div style={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '12px 24px', background: '#fff', borderBottom: '0.5px solid #e5e5e0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontWeight: 500, fontSize: 16 }}>
            {view === 'dashboard' && 'Dashboard'}
            {view === 'jobs' && 'Jobs'}
            {view === 'contacts' && 'Contractors'}
            {view === 'reports' && 'Reports'}
            {view === 'financials' && 'Financials'}
            {view === 'library' && 'Spec Library'}
            {view === 'takeoff' && 'Upload Manufacturer Quote'}
            {view === 'agent-pipeline' && '⚡ Agent Pipeline'}
            {view === 'shipments' && 'Shipments'}
            {view === 'reminders' && 'Reminders'}
            {view === 'job-detail' && selectedJob?.name}
          </div>
          <button onClick={() => setShowNewJob(true)} style={{ padding: '6px 14px', fontSize: 12, background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer' }}>+ New Job</button>
                <label style={{ padding: '6px 14px', fontSize: 12, background: '#1B5EA6', color: '#fff', borderRadius: 6, cursor: 'pointer', fontWeight: 500 }}>
                  {rfqImporting ? 'Reading RFQ…' : '⬆ Import RFQ (PDF)'}
                  <input type="file" accept=".pdf" style={{ display:'none' }} disabled={rfqImporting} onChange={async e=>{
                    const f = e.target.files?.[0]; if (!f) return
                    setRfqImporting(true)
                    try {
                      const res = await fetch('/api/parse-rfq', { method:'POST', headers:{ 'Content-Type':'application/octet-stream', 'x-file-name': f.name, 'x-user-name': authProfile?.name || '' }, body: f })
                      const d = await res.json()
                      if (d.error) alert('RFQ import failed: ' + d.error)
                      else { await loadJobs(); setSelectedJob(d.job); setView('job-detail') }
                    } catch (err) { alert(err.message) }
                    setRfqImporting(false); e.target.value = ''
                  }}/>
                </label>
        </div>

        <div style={{ padding: view === 'agent-pipeline' ? 0 : 24, flex: 1 }}>

          {/* DASHBOARD */}
          {view === 'dashboard' && (
            <div>
              {(overdueReminders.length > 0 || delayedCount > 0) && (
                <div style={{ background: '#FAEEDA', border: '0.5px solid #EF9F27', borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontSize: 12, color: '#633806', display: 'flex', gap: 16 }}>
                  {overdueReminders.length > 0 && <span>⚑ {overdueReminders.length} reminder{overdueReminders.length > 1 ? 's' : ''} overdue — <span onClick={() => setView('reminders')} style={{ textDecoration: 'underline', cursor: 'pointer' }}>view</span></span>}
                  {delayedCount > 0 && <span>🚚 {delayedCount} shipment{delayedCount > 1 ? 's' : ''} delayed — <span onClick={() => setView('shipments')} style={{ textDecoration: 'underline', cursor: 'pointer' }}>view</span></span>}
                </div>
              )}
              {(() => {
                const mine = jobs.flatMap(j => (Array.isArray(j.tasks) ? j.tasks : []).map((t, i) => ({ j, t, i }))).filter(x => !x.t[3] && (x.t[1] === authProfile?.name || x.t[1] === 'Team'))
                if (!mine.length) return null
                return (
                  <div style={{ background:'#f0f6f1', border:'0.5px solid #c4dcc8', borderRadius:10, padding:14, marginBottom:12 }}>
                    <div style={{ fontSize:12, fontWeight:700, color:'#2D7A3A', marginBottom:6 }}>✔ My Tasks ({mine.length})</div>
                    {mine.sort((a,b)=>String(a.t[2]||'9999').localeCompare(String(b.t[2]||'9999'))).map((x, k) => (
                      <div key={k} style={{ display:'flex', gap:10, alignItems:'center', padding:'4px 0', borderTop:'0.5px dotted #c4dcc8', fontSize:12 }}>
                        <input type="checkbox" onChange={async()=>{ const nv = (x.j.tasks||[]).map((tt,jj)=> jj===x.i ? [tt[0],tt[1],tt[2],true,new Date().toISOString().split('T')[0]] : tt); await supabase.from('jobs').update({ tasks: nv }).eq('id', x.j.id); loadJobs() }} style={{ width:15, height:15, cursor:'pointer' }}/>
                        <span style={{ flex:1 }}>{x.t[0]}</span>
                        <span onClick={()=>{ setSelectedJob(x.j); setView('job-detail') }} style={{ color:'#1B5EA6', cursor:'pointer', textDecoration:'underline' }}>{x.j.name}</span>
                        {x.t[2] && <span style={{ fontSize:11, color: x.t[2] < todayISO ? '#A32D2D' : '#888', fontWeight: x.t[2] < todayISO ? 700 : 400 }}>{fmtD(x.t[2])}</span>}
                      </div>
                    ))}
                  </div>
                )
              })()}
              {jobs.filter(j => j.pending_review).length > 0 && (
                <div style={{ background:'#fdf8ee', border:'0.5px solid #e8d9b0', borderRadius:10, padding:14, marginBottom:12 }}>
                  <div style={{ fontSize:12, fontWeight:700, color:'#8B6914', marginBottom:8 }}>📥 Inbound RFQs — awaiting review ({jobs.filter(j => j.pending_review).length})</div>
                  {jobs.filter(j => j.pending_review).map(j => (
                    <div key={j.id} style={{ display:'flex', gap:10, alignItems:'center', padding:'6px 0', borderTop:'0.5px dotted #e8d9b0', fontSize:12 }}>
                      <span style={{ fontWeight:600, flex:1 }}>{j.name}</span>
                      <span style={{ color:'#888' }}>{j.gc_name || '—'}</span>
                      {j.bid_due_date && <span style={{ color:'#8B6914' }}>due {fmtD(j.bid_due_date)}</span>}
                      <button onClick={()=>{ setSelectedJob(j); setView('job-detail') }} style={{ padding:'3px 10px', fontSize:10, background:'#fff', border:'0.5px solid #ccc', borderRadius:5, cursor:'pointer' }}>Review</button>
                      <button onClick={async()=>{ await supabase.from('jobs').update({ pending_review: false, owner: authProfile?.name || null }).eq('id', j.id); await supabase.from('activity_log').insert({ job_id: j.id, user_name: authProfile?.name || 'MDSG', action: 'Inbound RFQ approved to pipeline' }); loadJobs() }} style={{ padding:'3px 10px', fontSize:10, background:'#2D7A3A', color:'#fff', border:'none', borderRadius:5, cursor:'pointer', fontWeight:600 }}>✓ Approve</button>
                      <button onClick={async()=>{ if(!confirm('Dismiss and delete this inbound RFQ?')) return; await supabase.from('jobs').delete().eq('id', j.id); loadJobs() }} style={{ padding:'3px 10px', fontSize:10, background:'#fff', color:'#A32D2D', border:'0.5px solid #A32D2D', borderRadius:5, cursor:'pointer' }}>✕ Dismiss</button>
                    </div>
                  ))}
                </div>
              )}
              <div style={{ display:'flex', justifyContent:'flex-end', marginBottom:8 }}>
                <div style={{ display:'flex', gap:4, alignItems:'center' }}>
                  <span style={{ fontSize:11, color:'#888' }}>Owner:</span>
                  {['all', ...new Set(jobs.map(j=>j.owner).filter(Boolean))].map(o => (
                    <button key={o} onClick={()=>setKanbanOwner(o)} style={{ padding:'3px 10px', fontSize:11, borderRadius:6, cursor:'pointer', background:kanbanOwner===o?'#3C3489':'#f5f5f3', color:kanbanOwner===o?'#fff':'#555', border:'0.5px solid #ddd' }}>{o==='all'?'All':o}</button>
                  ))}
                  <span style={{ fontSize:11, color:'#888', marginLeft:12 }}>Sort columns:</span>
                  {[['date','By Date'],['az','A–Z']].map(([k,l]) => (
                    <button key={k} onClick={()=>setKanbanSort(k)} style={{ padding:'3px 10px', fontSize:11, borderRadius:6, cursor:'pointer', background:kanbanSort===k?'#3C3489':'#f5f5f3', color:kanbanSort===k?'#fff':'#555', border:'0.5px solid #ddd' }}>{l}</button>
                  ))}
                </div>
              </div>
              {followUps.length > 0 && (
                <div style={{ background: '#FDF8EC', border: '0.5px solid #e0c98a', borderRadius: 10, padding: 14, marginBottom: 16 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#8B6914', marginBottom: 8 }}>⏰ Bid Follow-Ups Needed ({followUps.length})</div>
                  {followUps.slice(0, 8).map(j => (
                    <div key={j.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '5px 0', borderTop: '0.5px dotted #e8dcc0', fontSize: 12 }}>
                      <span onClick={() => { setSelectedJob(j); setView('job-detail') }} style={{ fontWeight: 600, cursor: 'pointer', color: '#1B5EA6', flex: 1 }}>{j.name}</span>
                      <span style={{ color: '#888' }}>{j.owner || '—'}</span>
                      <span style={{ color: '#A32D2D', fontWeight: 500 }}>{j.__milestone} follow-up · {j.__days}d past bid</span>
                      <span style={{ color: '#aaa', fontSize: 11 }}>{j.last_contacted_at ? 'last contact ' + j.last_contacted_at : 'no contact logged'}</span>
                      <button onClick={() => logContact(j)} style={{ padding: '3px 10px', fontSize: 11, background: '#2D7A3A', color: '#fff', border: 'none', borderRadius: 5, cursor: 'pointer' }}>✓ Log contact</button>
                    </div>
                  ))}
                </div>
              )}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 24 }}>
                {[
                  { label: 'Pipeline Value', value: fmt(pipelineValue), sub: `${activeBids} active bids` },
                  { label: 'Under Contract', value: fmt(contractValue), sub: `${contractCount} jobs awarded+` },
                  { label: 'Blended Margin', value: fmtPct(avgMargin), sub: `${marginJobs.length} priced jobs, $-weighted` },
                  { label: 'In Transit', value: inTransitCount, sub: 'loads on the way', alert: delayedCount > 0 },
                ].map(m => (
                  <div key={m.label} style={{ background: m.alert ? '#FAEEDA' : '#f5f5f3', borderRadius: 8, padding: 14 }}>
                    <div style={{ fontSize: 11, color: '#888', fontWeight: 500, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>{m.label}</div>
                    <div style={{ fontSize: 22, fontWeight: 500, color: m.alert ? '#854F0B' : 'inherit' }}>{loading ? '—' : m.value}</div>
                    <div style={{ fontSize: 11, color: '#888', marginTop: 4 }}>{m.sub}</div>
                  </div>
                ))}
              </div>

              {allActiveShipments.length > 0 && (
                <div style={{ marginBottom: 20 }}>
                  <div style={{ marginBottom: 8, fontWeight: 500, fontSize: 13 }}>Active Shipments</div>
                  <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, overflow: 'hidden' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                      <thead><tr style={{ background: '#f5f5f3' }}>
                        {['Job', 'Load', 'Carrier', 'Expected', 'Floors / Units', 'Cabinets', 'Status'].map(h => (
                          <th key={h} style={{ padding: '8px 12px', textAlign: 'left', fontWeight: 500, color: '#888', borderBottom: '0.5px solid #e5e5e0', fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.4 }}>{h}</th>
                        ))}
                      </tr></thead>
                      <tbody>
                        {allActiveShipments.map(s => (
                          <tr key={s.id} style={{ borderBottom: '0.5px solid #f0f0ec', background: s.status === 'Delayed' ? '#FFF8F0' : '' }}
                            onClick={() => { const job = jobs.find(j => j.id === s.job_id); if (job) { setSelectedJob(job); setView('job-detail') } }}
                            onMouseEnter={e => e.currentTarget.style.cursor = 'pointer'}>
                            <td style={{ padding: '8px 12px', fontWeight: 500 }}>{s.jobs?.name || '—'}</td>
                            <td style={{ padding: '8px 12px', color: '#555' }}>Load {s.load_number} of {s.total_loads}</td>
                            <td style={{ padding: '8px 12px', color: '#555' }}>{s.carrier}</td>
                            <td style={{ padding: '8px 12px', color: s.status === 'Delayed' ? '#A32D2D' : '#555', fontWeight: s.status === 'Delayed' ? 500 : 400 }}>{s.scheduled_date || '—'}</td>
                            <td style={{ padding: '8px 12px', color: '#555' }}>{s.floors_covered || '—'}</td>
                            <td style={{ padding: '8px 12px', color: '#555' }}>{s.cabinet_count ? s.cabinet_count.toLocaleString() : '—'}</td>
                            <td style={{ padding: '8px 12px' }}><ShipmentBadge status={s.status} /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              <div style={{ marginBottom: 8, fontWeight: 500, fontSize: 13 }}>Job Pipeline</div>
              <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
              <div style={{ flex: 1, display: 'grid', gridTemplateColumns: `repeat(${FRONT_STAGES.length},1fr)`, gap: 8, overflowX: 'auto' }}>
                {FRONT_STAGES.map(stage => (
                  <div key={stage} style={{ background: '#f5f5f3', borderRadius: 8, padding: 10, minHeight: 80 }}>
                    <div style={{ fontSize: 10, fontWeight: 500, color: '#888', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8, display: 'flex', justifyContent: 'space-between' }}>
                      {stage} <span style={{ background: '#fff', borderRadius: 10, padding: '1px 6px', fontSize: 10 }}>{jobs.filter(j => j.stage === stage).length}</span>
                      {(() => { const v = jobs.filter(j => j.stage === stage).reduce((s, j) => s + effVal(j), 0); return v > 0 ? <span style={{ fontSize: 10, fontWeight: 400, marginLeft: 6, opacity: 0.75 }}>{fmt(v)}</span> : null })()}
                    </div>
                    {jobs.filter(j => j.stage === stage && !j.pending_review && (kanbanOwner==='all' || j.owner===kanbanOwner)).sort((a, b) => {
                      if (kanbanSort === 'az') return (a.name || '').localeCompare(b.name || '')
                      const key = (j) => { const ds = [j.next_followup_date, j.bid_due_date].filter(Boolean); return ds.length ? ds.sort()[0] : '9999-12-31' }
                      const ka = key(a), kb = key(b)
                      return ka !== kb ? ka.localeCompare(kb) : (a.name || '').localeCompare(b.name || '')
                    }).map(job => (
                      <div key={job.id} onClick={() => { setSelectedJob(job); setView('job-detail') }}
                        style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 7, padding: 13, marginBottom: 8, cursor: 'pointer' }}>
                        <div style={{ fontWeight: 500, fontSize: 13.5 }}>{(job.priority==='hot') ? '🔥 ' : ''}{job.name}{job.priority==='high' && <span style={{ marginLeft:5, fontSize:9, background:'#e0a800', color:'#fff', padding:'1px 5px', borderRadius:6, fontWeight:700 }}>HIGH</span>}</div>
                        {(job.tasks || []).filter(t=>!t[3])[0] && (
                          <div style={{ fontSize: 10.5, color:'#2D7A3A', marginTop: 2 }}>✔ {(job.tasks || []).filter(t=>!t[3])[0][0].substring(0, 60)}{(job.tasks || []).filter(t=>!t[3]).length > 1 ? ` (+${(job.tasks || []).filter(t=>!t[3]).length - 1})` : ''}</div>
                        )}
                        {(job.bid_due_date || job.next_followup_date) && (
                          <div style={{ fontSize: 11, marginTop: 3, display:'flex', gap:8 }}>
                            {job.bid_due_date && <span style={{ color: job.bid_due_date < new Date().toISOString().split('T')[0] ? '#A32D2D' : '#888' }}>📅 {fmtD(job.bid_due_date)}</span>}
                            {job.next_followup_date && <span style={{ color:'#8B6914' }}>⏰ {fmtD(job.next_followup_date)}</span>}
                          </div>
                        )}
                        <div style={{ fontSize: 11, color: '#888' }}>{job.gc_name || '—'}</div>
                        <div style={{ fontSize: 12, fontWeight: 500, color: '#3C3489', marginTop: 4 }}>{fmt(job.bid_value)}</div>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
              <div style={{ width: 230, flexShrink: 0 }}>
                <div style={{ background: '#f0eff9', borderRadius: 8, padding: 12 }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: '#3C3489', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>Production — Post Award</div>
                  {PRODUCTION_STAGES.map(ps => {
                    const rows = jobs.filter(j => j.stage === ps && !j.pending_review && (kanbanOwner==='all' || j.owner===kanbanOwner))
                    return (
                      <div key={ps} style={{ marginBottom: 10 }}>
                        <div style={{ fontSize: 10, fontWeight: 600, color: '#888', textTransform: 'uppercase', letterSpacing: 0.4, display: 'flex', justifyContent: 'space-between' }}>
                          <span>{ps}</span><span>{rows.length}{(() => { const v = rows.reduce((s, j) => s + effVal(j), 0); return v > 0 ? ' · ' + fmt(v) : '' })()}</span>
                        </div>
                        {rows.map(job => (
                          <div key={job.id} onClick={() => { setSelectedJob(job); setView('job-detail') }} style={{ background: '#fff', borderRadius: 6, padding: '6px 9px', marginTop: 4, cursor: 'pointer', fontSize: 11.5, fontWeight: 500 }}>
                            {(job.priority==='hot') ? '🔥 ' : ''}{job.name}
                            {job.est_delivery && <div style={{ fontSize: 9.5, color: '#888', fontWeight: 400 }}>ETA {fmtD(job.est_delivery)}</div>}
                          </div>
                        ))}
                        {rows.length === 0 && <div style={{ fontSize: 10, color: '#bbb', marginTop: 3 }}>—</div>}
                      </div>
                    )
                  })}
                </div>
              </div>

              </div>

              {jobs.filter(j => j.stage === 'Lost').length > 0 && (
                <div style={{ marginTop: 16 }}>
                  <div style={{ marginBottom: 8, fontWeight: 500, fontSize: 13, color: '#A32D2D', display: 'flex', alignItems: 'center', gap: 8 }}>
                    Jobs Lost
                    <span style={{ background: '#FCEBEB', color: '#A32D2D', borderRadius: 10, padding: '1px 8px', fontSize: 11, fontWeight: 500 }}>
                      {jobs.filter(j => j.stage === 'Lost').length}
                    </span>
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                    {jobs.filter(j => j.stage === 'Lost').map(job => (
                      <div key={job.id} onClick={() => { setSelectedJob(job); setView('job-detail') }}
                        style={{ background: '#FCEBEB', border: '0.5px solid #E8BABA', borderRadius: 8, padding: '8px 14px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12 }}>
                        <div>
                          <div style={{ fontWeight: 500, fontSize: 12, color: '#A32D2D' }}>{job.name}</div>
                          <div style={{ fontSize: 11, color: '#C06060' }}>{job.gc_name || '—'}</div>
                        </div>
                        {job.bid_value > 0 && <div style={{ fontSize: 12, color: '#A32D2D', fontWeight: 500 }}>{fmt(job.bid_value)}</div>}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* JOBS LIST */}
          {view === 'jobs' && (() => {
            const owners = ['All', ...[...new Set(jobs.map(j => j.owner).filter(Boolean))].sort()]
            const gcs = ['All', ...[...new Set(jobs.map(j => (j.gc_name || '').trim()).filter(Boolean))].sort()]
            const q = jobSearch.trim().toLowerCase()
            const filteredJobs = jobs.filter(j =>
              (ownerFilter === 'All' || j.owner === ownerFilter) &&
              (gcFilter === 'All' || (j.gc_name || '').trim() === gcFilter) &&
              (!q || [j.name, j.gc_name, j.manufacturer, j.address, j.city, j.stage].some(v => (v || '').toLowerCase().includes(q)))
            )
            return (
            <div>
              <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 12, flexWrap: 'wrap' }}>
                <input
                  value={jobSearch}
                  onChange={e => setJobSearch(e.target.value)}
                  placeholder="🔍 Search jobs — name, GC, manufacturer, city..."
                  style={{ flex: 1, minWidth: 240, padding: '9px 14px', border: '0.5px solid #ccc', borderRadius: 8, fontSize: 13 }}
                />
                <div style={{ display: 'flex', gap: 4 }}>
                  {owners.map(o => (
                    <button key={o} onClick={() => setOwnerFilter(o)}
                      style={{ padding: '6px 14px', fontSize: 12, borderRadius: 8, cursor: 'pointer', fontWeight: 500,
                        background: ownerFilter === o ? '#3C3489' : '#f5f5f3',
                        color: ownerFilter === o ? '#fff' : '#555',
                        border: '0.5px solid ' + (ownerFilter === o ? '#3C3489' : '#ddd') }}>
                      {o}{o !== 'All' ? ` (${jobs.filter(j => j.owner === o).length})` : ''}
                    </button>
                  ))}
                </div>
                <select value={gcFilter} onChange={e => setGcFilter(e.target.value)} style={{ padding: '7px 10px', fontSize: 12, border: '0.5px solid #ccc', borderRadius: 8, maxWidth: 200 }}>
                  {gcs.map(g => <option key={g} value={g}>{g === 'All' ? 'All GCs' : g}</option>)}
                </select>
                <span style={{ fontSize: 11, color: '#888' }}>{filteredJobs.length} of {jobs.length}</span>
              </div>
            <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead><tr style={{ background: '#f5f5f3' }}>
                  {['Project', 'GC', 'Stage', 'Manufacturer', 'Cabinets', 'Bid Value', 'Margin', 'Owner'].map(h => (
                    <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 500, color: '#888', borderBottom: '0.5px solid #e5e5e0', fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.4 }}>{h}</th>
                  ))}
                </tr></thead>
                <tbody>
                  {loading ? <tr><td colSpan={8} style={{ padding: 24, textAlign: 'center', color: '#888' }}>Loading...</td></tr>
                  : filteredJobs.map(job => {
                    const c = STAGE_COLORS[job.stage] || STAGE_COLORS['Bid']
                    return (
                      <tr key={job.id} onClick={() => { setSelectedJob(job); setView('job-detail') }}
                        style={{ cursor: 'pointer', borderBottom: '0.5px solid #f0f0ec' }}
                        onMouseEnter={e => e.currentTarget.style.background = '#fafaf8'}
                        onMouseLeave={e => e.currentTarget.style.background = ''}>
                        <td style={{ padding: '10px 14px', fontWeight: 500 }}>{job.name}</td>
                        <td style={{ padding: '10px 14px', color: '#555' }}>{job.gc_name || '—'}</td>
                        <td style={{ padding: '10px 14px' }}><span style={{ background: c.bg, color: c.text, borderRadius: 10, padding: '2px 8px', fontSize: 10, fontWeight: 500 }}>{job.stage}</span></td>
                        <td style={{ padding: '10px 14px', color: '#555' }}>{job.manufacturer}</td>
                        <td style={{ padding: '10px 14px', color: '#555' }}>{job.total_cabinet_count || '—'}</td>
                        <td style={{ padding: '10px 14px', fontWeight: 500 }}>{fmt(job.bid_value)}</td>
                        <td style={{ padding: '10px 14px', color: (job.gross_margin_pct || 0) >= 0.25 ? '#3B6D11' : '#854F0B', fontWeight: 500 }}>{fmtPct(job.gross_margin_pct)}</td>
                        <td style={{ padding: '10px 14px', color: '#555' }}>{job.owner}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          
            </div>
            )
          })()}

          {/* JOB DETAIL */}
          {view === 'job-detail' && selectedJob && (
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                <div onClick={() => { setView('jobs'); setConfirmDelete(false) }} style={{ fontSize: 12, color: '#888', cursor: 'pointer' }}>← <span style={{ color: '#3C3489' }}>Jobs</span> / {selectedJob.name}</div>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                  {confirmDelete ? (
                    <>
                      <span style={{ fontSize: 11, color: '#A32D2D' }}>Delete "{selectedJob.name}" and all its data?</span>
                      <button onClick={deleteJob} disabled={deletingJob} style={{ padding: '4px 12px', fontSize: 11, background: '#A32D2D', color: '#fff', border: 'none', borderRadius: 6, cursor: deletingJob ? 'default' : 'pointer', fontWeight: 600 }}>{deletingJob ? 'Deleting...' : 'Yes, Delete'}</button>
                      <button onClick={() => setConfirmDelete(false)} style={{ padding: '4px 10px', fontSize: 11, background: '#f5f5f3', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer' }}>Cancel</button>
                    </>
                  ) : (
                    <button onClick={() => setConfirmDelete(true)} style={{ padding: '4px 10px', fontSize: 11, background: '#FCEBEB', color: '#A32D2D', border: '0.5px solid #E8BABA', borderRadius: 6, cursor: 'pointer' }}>Delete Job</button>
                  )}
                </div>
              </div>

              <div style={{ ...card, marginBottom: 16, padding: 16 }}>
                <div style={{ fontSize: 12, fontWeight: 500, marginBottom: 10 }}>Pipeline Stage</div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button onClick={() => logContact(selectedJob)} style={{ padding: '6px 12px', fontSize: 11, borderRadius: 6, cursor: 'pointer', background: '#2D7A3A', color: '#fff', border: 'none', fontWeight: 500 }}>✓ Log contact{selectedJob.last_contacted_at ? ` (last: ${selectedJob.last_contacted_at})` : ''}</button>
                  {STAGES.map(stage => {
                    const c = STAGE_COLORS[stage]; const isCurrent = selectedJob.stage === stage
                    return <button key={stage} onClick={() => updateStage(stage)} disabled={stageUpdating}
                      style={{ padding: '6px 12px', fontSize: 11, borderRadius: 6, cursor: 'pointer', fontWeight: isCurrent ? 600 : 400,
                        background: isCurrent ? c.bg : '#f5f5f3', color: isCurrent ? c.text : '#888',
                        border: isCurrent ? `1.5px solid ${c.text}` : '0.5px solid #ddd' }}>{stage}</button>
                  })}
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div>
                  <div style={card}>
                    <div style={{ fontWeight: 500, marginBottom: 16 }}>{selectedJob.name}</div>
                    {[['General Contractor', selectedJob.gc_name], ['Address', [selectedJob.address, selectedJob.city, selectedJob.state, selectedJob.zip].filter(Boolean).join(', ')], ['Manufacturer', selectedJob.manufacturer], ['Quote #', selectedJob.manufacturer_quote_number], ['Total Units', selectedJob.total_residential_units], ['Total Cabinets', selectedJob.total_cabinet_count], ['Bid Due', fmtD(selectedJob.bid_due_date)], ['Owner', '__OWNER_SELECT__']].filter(([label, v]) => v || label === 'Owner').map(([label, value]) => (
                      <div key={label} style={{ marginBottom: 10 }}>
                        <div style={lbl}>{label}</div>
                        {value === '__OWNER_SELECT__' ? (
                          <select value={selectedJob.owner || ''} onChange={async e=>{ const v = e.target.value || null; await supabase.from('jobs').update({ owner: v }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, owner: v }); loadJobs(); if (v && v !== authProfile?.name && OWNER_EMAILS[v]) { fetch('/api/send-email', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ jobId: selectedJob.id, to: [OWNER_EMAILS[v]], fromEmail: authProfile?.email, fromName: authProfile?.name, senderName: authProfile?.name, subject: `Job assigned to you: ${selectedJob.name}`, body: `${selectedJob.name} has been assigned to you by ${authProfile?.name || 'MDSG'}.\n\nGC: ${selectedJob.gc_name || '—'}\nStage: ${selectedJob.stage}\nBid due: ${selectedJob.bid_due_date || '—'}\n\nOpen the OS: https://mdsg-os.vercel.app` }) }).catch(()=>{}) } }} style={{ fontSize: 13, padding:'3px 8px', border:'0.5px solid #ccc', borderRadius:6, background:'#fff' }}>
                            <option value="">— unassigned —</option>
                            {['Cole','Pam','Vicki','Blake','Tabetha'].map(o => <option key={o}>{o}</option>)}
                          </select>
                        ) : (
                          <div style={{ fontSize: 13 }}>{value}</div>
                        )}
                      </div>
                    ))}
                  </div>

                  <div style={card}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                      <div style={{ fontWeight: 500 }}><Chevron k="pd"/>Proposal Details</div>
                      {!editingProposal
                        ? <div style={{ display:'flex', gap:6 }}><button onClick={async()=>{ if(!confirm('Duplicate this job as a new RFQ? Copies GC info, specs, cab list, and scope — not quotes or history.')) return; const src = selectedJob; const copyFields = ['gc_name','gc_contact','gc_email','gc_phone','address','city','state','zip','manufacturer','door_style','finish_color','cabinet_construction','box_construction','drawer_box','interior_color','shelf_thickness','hinge_type','notes','owner','cab_list','scope_of_work','dealer_discount_pct']; const ins = { name: src.name + ' (Copy)', stage: 'RFQ' }; copyFields.forEach(k => { if (src[k] !== undefined && src[k] !== null) ins[k] = src[k] }); const { data: nj, error } = await supabase.from('jobs').insert(ins).select().single(); if (error) { alert(error.message); return } await supabase.from('activity_log').insert({ job_id: nj.id, user_name: authProfile?.name || 'MDSG', action: 'Duplicated from ' + src.name }); await loadJobs(); setSelectedJob(nj) }} style={{ fontSize: 11, padding: '4px 12px', background: '#f5f5f3', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer' }}>⧉ Duplicate</button><button onClick={() => setEditingProposal(true)} style={{ fontSize: 11, padding: '4px 12px', background: '#f5f5f3', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer' }}>Edit</button></div>
                        : <div style={{ display: 'flex', gap: 6 }}>
                            <button onClick={saveProposalEdits} disabled={savingEdits} style={{ fontSize: 11, padding: '4px 12px', background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer' }}>{savingEdits ? 'Saving...' : 'Save'}</button>
                            <button onClick={() => setEditingProposal(false)} style={{ fontSize: 11, padding: '4px 12px', background: '#f5f5f3', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer' }}>Cancel</button>
                          </div>
                      }
                    </div>
                    {!collapsed.pd && (<>
                    {!editingProposal ? (
                      <div>
                        {[['Door Style', selectedJob.door_style], ['Finish / Color', selectedJob.finish_color], ['Drawer Box', selectedJob.drawer_box], ['Construction', selectedJob.cabinet_construction], ['Interior', selectedJob.interior_color], ['Shelf', selectedJob.shelf_thickness], ['Hinge', selectedJob.hinge_type], ['Box Construction', selectedJob.box_construction], ['Hardware Allowance', selectedJob.hardware_allowance ? fmt(selectedJob.hardware_allowance) : null], ['Scope Notes', selectedJob.scope_notes]].filter(([, v]) => v).map(([label, value]) => (
                          <div key={label} style={{ marginBottom: 10 }}>
                            <div style={lbl}>{label}</div>
                            <div style={{ fontSize: 13 }}>{value}</div>
                          </div>
                        ))}
                        {editUnitTypes.length > 0 && (
                          <div style={{ marginTop: 10 }}>
                            <div style={lbl}>Unit Types</div>
                            {editUnitTypes.map((ut,i) => (
                              <div key={ut.id||i} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', fontSize: 12, borderBottom: '0.5px solid #f5f5f3' }}>
                                <span>{ut.unit_type_name}</span>
                                <span style={{ color: '#888' }}>{ut.unit_quantity} unit{ut.unit_quantity!==1?'s':''} · {ut.cabinet_count} cab{ut.cabinet_count!==1?'s':''}{ut.manufacturer_price>0?' · $'+ut.manufacturer_price.toLocaleString():''}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div>
                        <div style={{ fontSize:11, color:'#888', fontWeight:600, textTransform:'uppercase', letterSpacing:0.4, marginBottom:8 }}>Job Info</div>
                        <div style={{ marginBottom: 10 }}>
                          <label style={lbl}>Job Name</label>
                          <input value={editFields.name} onChange={e => setEditFields(pv => ({ ...pv, name: e.target.value }))} style={{ ...inp, fontWeight: 600 }} />
                        </div>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
                          <div><label style={lbl}>General Contractor</label><input value={editFields.gc_name} onChange={e => setEditFields(p => ({ ...p, gc_name: e.target.value }))} style={inp} /></div>
                          <div><label style={lbl}>Manufacturer</label><input value={editFields.manufacturer} onChange={e => setEditFields(p => ({ ...p, manufacturer: e.target.value }))} style={inp} /></div>
                          <div><label style={lbl}>Address</label><input value={editFields.address} onChange={e => setEditFields(p => ({ ...p, address: e.target.value }))} style={inp} /></div>
                          <div style={{ display:'flex', gap:6 }}>
                            <div style={{ flex:2 }}><label style={lbl}>City</label><input value={editFields.city} onChange={e => setEditFields(p => ({ ...p, city: e.target.value }))} style={inp} /></div>
                            <div style={{ flex:1 }}><label style={lbl}>State</label><input value={editFields.state} onChange={e => setEditFields(p => ({ ...p, state: e.target.value }))} style={inp} /></div>
                            <div style={{ flex:1 }}><label style={lbl}>Zip</label><input value={editFields.zip} onChange={e => setEditFields(p => ({ ...p, zip: e.target.value }))} style={inp} /></div>
                          </div>
                          <div><label style={lbl}>GC Contact</label><input value={editFields.gc_contact} onChange={e => setEditFields(p => ({ ...p, gc_contact: e.target.value }))} style={inp} /></div>
                          <div><label style={lbl}>GC Phone</label><input value={editFields.gc_phone} onChange={e => setEditFields(p => ({ ...p, gc_phone: e.target.value }))} style={inp} /></div>
                          <div><label style={lbl}>GC Email</label><input value={editFields.gc_email} onChange={e => setEditFields(p => ({ ...p, gc_email: e.target.value }))} style={inp} /></div>
                          <div><label style={lbl}>Bid Due Date</label><input type="date" value={editFields.bid_due_date} onChange={e => setEditFields(p => ({ ...p, bid_due_date: e.target.value }))} style={inp} /></div>
                        </div>
                        <div style={{ fontSize:11, color:'#888', fontWeight:600, textTransform:'uppercase', letterSpacing:0.4, marginBottom:8, marginTop:4 }}>Cabinet Specs</div>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
                          <div><label style={lbl}>Door Style</label>
                            <select value={editFields.door_style} onChange={e => setEditFields(pv => ({ ...pv, door_style: e.target.value }))} style={inp}>
                              <option value="">— select —</option>
                              {(DOOR_STYLES[cabList?.product_line || 'framed'] || []).map(d => <option key={d} value={d}>{d}</option>)}
                              {editFields.door_style && !(DOOR_STYLES[cabList?.product_line || 'framed'] || []).includes(editFields.door_style) && <option value={editFields.door_style}>{editFields.door_style}</option>}
                            </select></div>
                          <div><label style={lbl}>Drawer Box &amp; Glide</label>
                            <select value={editFields.drawer_box} onChange={e => setEditFields(pv => ({ ...pv, drawer_box: e.target.value }))} style={inp}>
                              <option value="">— select —</option>
                              {(DRAWER_BOXES[cabList?.product_line || 'framed'] || []).map(d => <option key={d} value={d}>{d}</option>)}
                            </select></div>
                          <div><label style={lbl}>Cabinet Construction</label>
                            <select value={editFields.cabinet_construction} onChange={e => setEditFields(pv => ({ ...pv, cabinet_construction: e.target.value }))} style={inp}>
                              <option value="">— select —</option><option>Framed-Particle Board</option><option>Framed-Plywood</option><option>Frameless-Particle Board</option><option>Frameless-Plywood</option>
                            </select></div>
                          <div><label style={lbl}>Interior Color</label><input value={editFields.interior_color} placeholder="White" onChange={e => setEditFields(pv => ({ ...pv, interior_color: e.target.value }))} style={inp} /></div>
                          <div><label style={lbl}>Shelf Thickness</label><input value={editFields.shelf_thickness} placeholder={'3/4"'} onChange={e => setEditFields(pv => ({ ...pv, shelf_thickness: e.target.value }))} style={inp} /></div>
                          <div><label style={lbl}>No. of Units (proposal)</label><input type="number" value={editFields.units_override ?? ''} placeholder="auto" onChange={e => setEditFields(pv => ({ ...pv, units_override: e.target.value }))} style={inp} /></div>
                          <div><label style={lbl}>No. of Amenities (proposal)</label><input type="number" value={editFields.amenities_override ?? ''} placeholder="auto" onChange={e => setEditFields(pv => ({ ...pv, amenities_override: e.target.value }))} style={inp} /></div>
                          <div><label style={lbl}>Est. Delivery</label><input type="date" value={editFields.est_delivery ?? ''} onChange={e => setEditFields(pv => ({ ...pv, est_delivery: e.target.value }))} style={inp} /></div>
                          <div><label style={lbl}>No. of Deliveries</label><input value={editFields.deliveries_count ?? ''} placeholder="e.g. 4 loads" onChange={e => setEditFields(pv => ({ ...pv, deliveries_count: e.target.value }))} style={inp} /></div>
                          <div><label style={lbl}>Door Hinge Type</label>
                            <select value={editFields.hinge_type} onChange={e => setEditFields(pv => ({ ...pv, hinge_type: e.target.value }))} style={inp}>
                              <option value="">— select —</option><option>Euro 6 Way</option><option>Soft-Close</option>
                            </select></div>
                          <div><label style={lbl}>Finish / Color</label><input list="door-finish-options" value={editFields.finish_color} onChange={e => setEditFields(pv => ({ ...pv, finish_color: e.target.value }))} style={inp} />
                            <datalist id="door-finish-options">{DOOR_FINISHES.map(f => <option key={f} value={f} />)}</datalist></div>
                        </div>
                        <div style={{ marginBottom: 12 }}><label style={lbl}>Box Construction</label><input value={editFields.box_construction} onChange={e => setEditFields(p => ({ ...p, box_construction: e.target.value }))} style={inp} /></div>
                        <div style={{ marginBottom: 14 }}><label style={lbl}>Scope Notes</label><textarea value={editFields.scope_notes} onChange={e => setEditFields(p => ({ ...p, scope_notes: e.target.value }))} style={{ ...inp, height: 56, resize: 'vertical' }} /></div>
                        {editUnitTypes.length > 0 && (
                          <div style={{ marginBottom: 14 }}>
                            <label style={lbl}>Unit Type Quantities</label>
                            <div style={{ background: '#f9f9f9', borderRadius: 6, padding: 10 }}>
                              {editUnitTypes.map((ut, i) => (
                                <div key={ut.id} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                                  <span style={{ flex: 1, fontSize: 12 }}>{ut.unit_type_name}</span>
                                  <label style={{ fontSize: 10, color: '#888' }}>Units:</label>
                                  <input type="number" min="0" value={ut.unit_quantity}
                                    onChange={e => { const u = [...editUnitTypes]; u[i] = { ...ut, unit_quantity: Number(e.target.value) }; setEditUnitTypes(u) }}
                                    style={{ width: 60, padding: '4px 6px', border: '0.5px solid #ccc', borderRadius: 4, fontSize: 12 }} />
                                  <span style={{ fontSize: 11, color: '#888' }}>{ut.cabinet_count} cabs</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        <div>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                            <label style={lbl}>Additional Line Items</label>
                            <button onClick={() => setAdditionalLineItems(p => [...p, { description: '', amount: 0 }])} style={{ fontSize: 10, padding: '3px 8px', background: 'transparent', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer' }}>+ Add</button>
                          </div>
                          {additionalLineItems.length === 0 && <div style={{ fontSize: 11, color: '#aaa' }}>No additional items</div>}
                          {additionalLineItems.map((item, i) => (
                            <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6, alignItems: 'center' }}>
                              <input placeholder="Description" value={item.description} onChange={e => { const u = [...additionalLineItems]; u[i] = { ...item, description: e.target.value }; setAdditionalLineItems(u) }} style={{ flex: 1, padding: '6px 8px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 12 }} />
                              <input type="number" placeholder="$" value={item.amount} onChange={e => { const u = [...additionalLineItems]; u[i] = { ...item, amount: Number(e.target.value) }; setAdditionalLineItems(u) }} style={{ width: 80, padding: '6px 8px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 12 }} />
                              <button onClick={() => setAdditionalLineItems(p => p.filter((_, j) => j !== i))} style={{ padding: '4px 8px', background: '#FCEBEB', color: '#A32D2D', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 11 }}>✕</button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </>)}
                    </div>

                  <div style={card}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                      <div style={{ fontWeight: 500 }}><Chevron k="cs"/>Cabinet Schedule</div>
                      {selectedJob.total_cabinet_count > 0 && (
                        <button onClick={async () => {
                            try {
                              const { data: uts } = await supabase.from('unit_types').select('*, cabinet_line_items(*)').eq('job_id', selectedJob.id).order('sort_order')
                              if (!uts?.length) return alert('No cabinet data saved yet')
                              const takeoffData = {
                                project_name: selectedJob.name,
                                unit_types: uts.map(ut => ({
                                  unit_type_name: ut.unit_type_name, unit_quantity: ut.unit_quantity || 1, cabinet_count: ut.cabinet_count || 0,
                                  skus:    (ut.cabinet_line_items || []).filter(li => li.sort_order < 1000).map(li => ({ sku: li.sku, description: li.description, quantity_per_unit: li.quantity, hinge_side: li.hinge_side })),
                                  fillers: (ut.cabinet_line_items || []).filter(li => li.sort_order >= 1000).map(li => ({ sku: li.sku, description: li.description, quantity_per_unit: li.quantity })),
                                })),
                                specs: { cabinet_line: selectedJob.manufacturer || 'TBD', door_style: selectedJob.door_style || 'TBD', finish: selectedJob.finish_color || 'TBD', box_construction: selectedJob.box_construction || 'TBD' },
                              }
                              const res = await fetch('/api/export/excel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ takeoffData, projectName: selectedJob.name, supplierName: selectedJob.manufacturer || 'TBD', catalogRef: 'TBD', printDate: new Date().toLocaleDateString('en-US') }) })
                              if (!res.ok) throw new Error('Export failed')
                              const blob = await res.blob(); const url = URL.createObjectURL(blob)
                              const a = document.createElement('a'); a.href = url
                              a.download = `${selectedJob.name.replace(/[^a-zA-Z0-9_-]/g,'_')}_Cabinet_Schedule.xlsx`
                              a.click(); URL.revokeObjectURL(url)
                            } catch (err) { alert('Download failed: ' + err.message) }
                          }}
                          style={{ padding: '4px 12px', fontSize: 11, background: '#2D7A3A', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontWeight: 500 }}>
                          ⬇ Download Excel
                        </button>
                      )}
                    </div>
                    {!collapsed.cs && (<>
                    {selectedJob.total_cabinet_count > 0 ? (
                      <div>
                        <div style={{ display: 'flex', gap: 16, marginBottom: 10 }}>
                          <div><div style={lbl}>Total Cabinets</div><div style={{ fontSize: 22, fontWeight: 700, color: '#3C3489' }}>{selectedJob.total_cabinet_count.toLocaleString()}</div></div>
                          <div><div style={lbl}>Unit Types</div><div style={{ fontSize: 22, fontWeight: 700, color: '#3C3489' }}>{(selectedJob.unit_types || []).length}</div></div>
                        </div>
                        {(selectedJob.unit_types || []).sort((a,b) => a.sort_order - b.sort_order).map(ut => (
                          <div key={ut.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', fontSize: 12, borderBottom: '0.5px solid #f0f0ec' }}>
                            <span>{ut.unit_type_name}</span>
                            <span style={{ color: '#888' }}>{ut.unit_quantity} units · {(ut.cabinet_count || 0).toLocaleString()} cabs · {((ut.cabinet_count || 0) * (ut.unit_quantity || 1)).toLocaleString()} total</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div style={{ color: '#aaa', fontSize: 12 }}>No cabinet data saved yet — use the <span style={{ color: '#3C3489', cursor: 'pointer', textDecoration: 'underline' }} onClick={() => setView('agent-pipeline')}>⚡ Agent Pipeline</span> to extract and save</div>
                    )}
                  </>)}
                    </div>

                  <div style={card}>
                    <div style={{ fontWeight: 500, marginBottom: 12 }}><Chevron k="uq"/>Upload Manufacturer Quote PDF</div>
                    {!collapsed.uq && (<>
                    <label style={{ display: 'block', border: '1.5px dashed #ccc', borderRadius: 8, padding: 20, textAlign: 'center', cursor: 'pointer', background: '#fafaf8' }}>
                      <div style={{ color: '#555', fontSize: 13 }}>{quoteUploading ? 'Parsing with AI...' : 'Click to upload PDF quote'}</div>
                      <div style={{ color: '#999', fontSize: 11, marginTop: 4 }}>Leedo · Skyline · SMART · Ukon</div>
                      <input type="file" accept=".pdf,.xlsx,.xls,.xlsm" onChange={handleQuoteUpload} style={{ display: 'none' }} disabled={quoteUploading} />
                    </label>
                    {quoteResult && (
                      <div style={{ marginTop: 12, padding: 12, background: '#EAF3DE', borderRadius: 8, fontSize: 12 }}>
                        <div style={{ fontWeight: 500, color: '#3B6D11', marginBottom: 4 }}>Parsed successfully</div>
                        <div>Manufacturer: {quoteResult.summary.manufacturer} · Unit types: {quoteResult.summary.unit_type_count} · Cabinets: {quoteResult.summary.total_cabinets?.toLocaleString()}</div>
                        <div style={{ fontWeight: 500 }}>Grand total: {fmt(quoteResult.summary.grand_total)}</div>
                        {quoteResult.quote_recorded === false && <div style={{ color:'#A32D2D', fontWeight:600, marginTop:4 }}>⚠ Quote history NOT saved: {quoteResult.quote_record_error}</div>}
                        {quoteResult.quote_recorded === true && <div style={{ color:'#2D7A3A', marginTop:4 }}>✓ Saved to quote history</div>}
                      </div>
                    )}
                    <div style={{ marginTop: 10 }}>
                      <button onClick={runQuoteCheck} disabled={quoteChecking} style={{ padding:'6px 14px', fontSize:12, background:'#8B4513', color:'#fff', border:'none', borderRadius:6, cursor:'pointer', fontWeight:500 }}>{quoteChecking ? 'Checking...' : '⚖ Check Quote vs Cabinet List'}</button>
                      <span style={{ fontSize:11, color:'#999', marginLeft:8 }}>Compares the latest uploaded quote against this job's cabinet list</span>
                    </div>
                    {savedQuotes.length > 0 && (
                      <div style={{ marginTop: 12, borderTop: '0.5px solid #eee', paddingTop: 10 }}>
                        <div style={{ fontSize: 11, fontWeight: 600, color: '#888', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 6 }}>Saved Quotes ({savedQuotes.length})</div>
                        {savedQuotes.map(q => (
                          <div key={q.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '5px 0', borderTop: '0.5px dotted #eee', fontSize: 12 }}>
                            <span style={{ fontWeight: 600, width: 130 }}>{q.manufacturer}{q.quote_type === 'countertops' ? ' (CT)' : ''}</span>
                            <span style={{ flex: 1, color: '#888', fontSize: 11 }}>{q.file_name || '—'}</span>
                            <span style={{ fontWeight: 600 }}>{q.grand_total > 0 ? '$' + Number(q.grand_total).toLocaleString(undefined,{maximumFractionDigits:0}) : '—'}</span>
                            <span style={{ color: '#aaa', fontSize: 11 }}>{new Date(q.created_at).toLocaleDateString()}</span>
                            <button title="Edit quote amounts" onClick={async()=>{
                              const g = prompt('Gross amount ($):', q.gross_amount || ''); if (g === null) return
                              let body
                              if (q.quote_type !== 'countertops') {
                                const f = prompt('Freight ($):', q.freight_amount || 0); if (f === null) return
                                const t = prompt('Tax / tariff ($):', q.tax_amount || 0); if (t === null) return
                                body = { id: q.id, jobId: selectedJob.id, gross_amount: Number(g)||0, freight_amount: Number(f)||0, tax_amount: Number(t)||0, grand_total: (Number(g)||0)+(Number(f)||0)+(Number(t)||0) }
                              } else {
                                const gr = prompt('Grand total ($) — same as gross if no tax:', q.grand_total || g); if (gr === null) return
                                body = { id: q.id, jobId: selectedJob.id, gross_amount: Number(g)||0, grand_total: Number(gr)||Number(g)||0 }
                              }
                              const res = await fetch('/api/quotes', { method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) })
                              const d = await res.json(); if (d.error) alert(d.error); else { refreshSavedQuotes(); if (propQuoteId === q.id) applyQuoteToProposal({ ...q, ...body }) }
                            }} style={{ background:'none', border:'none', cursor:'pointer', color:'#888', fontSize:12 }}>✎</button>
                            {q.quote_type !== 'countertops' && (
                              <button title="Set as working quote" onClick={async()=>{ await supabase.from('jobs').update({ working_quote_id: q.id }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, working_quote_id: q.id }); applyQuoteToProposal(q) }} style={{ background:'none', border:'none', cursor:'pointer', fontSize:14, color: selectedJob.working_quote_id===q.id ? '#e0a800' : '#ccc' }}>★</button>
                            )}
                            {q.quote_type !== 'countertops'
                              ? <button onClick={()=>applyQuoteToProposal(q)} style={{ padding:'3px 10px', fontSize:10, background: propQuoteId===q.id ? '#2D7A3A' : '#fff', color: propQuoteId===q.id ? '#fff' : '#2D7A3A', border:'0.5px solid #2D7A3A', borderRadius:5, cursor:'pointer', fontWeight:500 }}>{propQuoteId===q.id ? '✓ In Proposal' : '→ Proposal'}</button>
                              : <button onClick={()=>setCtGross(String(q.gross_amount || q.grand_total || ''))} style={{ padding:'3px 10px', fontSize:10, background:'#fff', color:'#8B6914', border:'0.5px solid #8B6914', borderRadius:5, cursor:'pointer', fontWeight:500 }}>→ CT Pricing</button>}
                            <button onClick={async()=>{ if(!confirm('Delete this saved quote from history?')) return; await fetch('/api/quotes', { method:'DELETE', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id: q.id, jobId: selectedJob.id }) }); refreshSavedQuotes() }} style={{ background:'none', border:'none', cursor:'pointer', color:'#A32D2D', fontSize:13 }}>🗑</button>
                          </div>
                        ))}
                      </div>
                    )}
                    {quoteCheck && (
                          <div style={{ marginBottom:10, border:'0.5px solid ' + (quoteCheck.error ? '#ddd' : quoteCheck.clean ? '#4caf50' : '#e0a800'), borderRadius:8, padding:'10px 12px', background: quoteCheck.error ? '#fafaf8' : quoteCheck.clean ? '#f0f9f0' : '#fdf8ec' }}>
                            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                              <div style={{ fontSize:12, fontWeight:600, color: quoteCheck.error ? '#888' : quoteCheck.clean ? '#2D7A3A' : '#8B6914' }}>
                                {quoteCheck.error ? quoteCheck.error : (quoteCheck.clean ? '✓ ' : '⚠ ') + quoteCheck.summary}
                              </div>
                              <button onClick={()=>setQuoteCheck(null)} style={{ background:'none', border:'none', cursor:'pointer', color:'#bbb', fontSize:13 }}>✕</button>
                            </div>
                            {!quoteCheck.error && quoteCheck.issues?.length > 0 && (
                              <div style={{ maxHeight:180, overflowY:'auto', marginTop:8 }}>
                                {quoteCheck.issues.map((iss, ix) => (
                                  <div key={ix} style={{ fontSize:11, padding:'3px 0', borderTop:'0.5px dotted #eee', color: iss.level==='unit' ? '#A32D2D' : '#8B6914' }}>
                                    <strong>{iss.unit}</strong>{iss.sku ? ' · ' + iss.sku : ''} — {iss.detail}
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        )}
                  </>)}
                    </div>

                  <div style={card}>
                    <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom: 14 }}>
                      <div style={{ fontWeight: 500 }}><Chevron k="gp"/>Generate Proposal PDF</div>
                      {selectedJob.proposal_status === 'sent' && <span style={{ fontSize:10, fontWeight:700, background:'#2D7A3A', color:'#fff', padding:'2px 8px', borderRadius:10 }}>SENT {fmtD(selectedJob.proposal_sent_at)}</span>}
                      {selectedJob.proposal_status === 'final' && <span style={{ fontSize:10, fontWeight:700, background:'#e0a800', color:'#fff', padding:'2px 8px', borderRadius:10 }}>FINAL</span>}
                      <div style={{ marginLeft:'auto', display:'flex', gap:6 }}>
                        <button onClick={async()=>{ const st = selectedJob.proposal_status === 'draft' ? 'final' : 'draft'; const upd2 = { proposal_status: st }; await supabase.from('jobs').update(upd2).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, ...upd2 }); await supabase.from('activity_log').insert({ job_id: selectedJob.id, user_name: authProfile?.name || 'MDSG', action: 'Proposal ' + (st==='final' ? 'marked FINAL' : 'FINAL removed') }) }} style={{ padding:'4px 12px', fontSize:11, background: selectedJob.proposal_status !== 'draft' ? '#e0a800' : '#f5f5f3', color: selectedJob.proposal_status !== 'draft' ? '#fff' : '#555', border:'0.5px solid #ddd', borderRadius:6, cursor:'pointer', fontWeight:600 }}>★ FINAL</button>
                        <button onClick={async()=>{ const st = selectedJob.proposal_status === 'sent' ? 'final' : 'sent'; const upd2 = { proposal_status: st, proposal_sent_at: st==='sent' ? new Date().toISOString().split('T')[0] : null }; await supabase.from('jobs').update(upd2).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, ...upd2 }); await supabase.from('activity_log').insert({ job_id: selectedJob.id, user_name: authProfile?.name || 'MDSG', action: 'Proposal ' + (st==='sent' ? 'marked SENT' : 'SENT removed') }) }} style={{ padding:'4px 12px', fontSize:11, background: selectedJob.proposal_status === 'sent' ? '#2D7A3A' : '#f5f5f3', color: selectedJob.proposal_status === 'sent' ? '#fff' : '#555', border:'0.5px solid #ddd', borderRadius:6, cursor:'pointer', fontWeight:600 }}>✉ SENT</button>
                      </div>
                    </div>
                    {!collapsed.gp && (<>
                    <div style={{ marginBottom: 14 }}>
                      {savedQuotes.filter(q => q.quote_type !== 'countertops').length > 0 && (
                        <div style={{ marginBottom: 10 }}>
                          <label style={lbl}>Price From Saved Quote</label>
                          <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                            {savedQuotes.filter(q => q.quote_type !== 'countertops').map(q => (
                              <button key={q.id} onClick={()=>applyQuoteToProposal(q)} style={{ padding:'5px 12px', fontSize:11, borderRadius:6, cursor:'pointer', background: propQuoteId===q.id ? '#3C3489' : '#f5f5f3', color: propQuoteId===q.id ? '#fff' : '#555', border:'0.5px solid #ddd' }}>
                                {propQuoteId===q.id ? '✓ ' : ''}{q.manufacturer} · ${Number(q.gross_amount||0).toLocaleString(undefined,{maximumFractionDigits:0})} · {new Date(q.created_at).toLocaleDateString()}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                      <label style={lbl}>Manufacturer Gross Cost ($ — from Leedo printable summary)</label>
                      <input type="number" min="0" value={proposalGross} placeholder="e.g. 140000" onChange={e => setProposalGross(e.target.value)} style={{ width: 160, padding: '7px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13, marginBottom: 10 }} />
                      <div style={{ display:'flex', gap:10, marginBottom:10 }}>
                        <div>
                          <label style={lbl}>Freight $ (pass-through)</label>
                          <input type="number" min="0" value={proposalFreight} placeholder="0" onChange={e=>setProposalFreight(e.target.value)} style={{ width:120, padding:'7px 10px', border:'0.5px solid #ccc', borderRadius:6, fontSize:13 }}/>
                        </div>
                        <div>
                          <label style={lbl}>Mfr Tax $ (pass-through)</label>
                          <input type="number" min="0" value={proposalMfrTax} placeholder="0" onChange={e=>setProposalMfrTax(e.target.value)} style={{ width:120, padding:'7px 10px', border:'0.5px solid #ccc', borderRadius:6, fontSize:13 }}/>
                        </div>
                      </div>
                      {specLib.length > 0 && (
                        <div style={{ margin:'8px 0' }}>
                          <div style={{ fontSize:11, fontWeight:600, color:'#3C3489', marginBottom:4 }}>Attach Spec Literature <span style={{ fontWeight:400, color:'#999' }}>(matches to this job's specs in green)</span></div>
                          <div style={{ display:'flex', flexWrap:'wrap', gap:4 }}>
                            {specLib.map(r => {
                              const specText = [selectedJob.door_style, selectedJob.cabinet_construction, selectedJob.box_construction, selectedJob.drawer_box].filter(Boolean).join(' ').toLowerCase()
                              const tagList = (r.tags || '').split(',').map(t => t.trim().toLowerCase()).filter(t => t.length > 2)
                              const match = tagList.some(t => specText.includes(t) || t.split(/[\s/-]+/).some(w => w.length > 3 && specText.includes(w)))
                              const on = litSelected.includes(r.id)
                              return (
                                <label key={r.id} style={{ display:'flex', alignItems:'center', gap:4, fontSize:11, padding:'3px 8px', borderRadius:6, cursor:'pointer', border:'0.5px solid ' + (on ? '#3C3489' : '#e0e0e0'), background: on ? '#f0eff9' : '#fff', color: match ? '#2D7A3A' : '#555', fontWeight: match ? 700 : 400 }}>
                                  <input type="checkbox" checked={on} onChange={()=>setLitSelected(pv => on ? pv.filter(x => x !== r.id) : [...pv, r.id])} style={{ width:12, height:12 }}/>
                                  {r.title.length > 38 ? r.title.substring(0, 38) + '…' : r.title}
                                </label>
                              )
                            })}
                          </div>
                        </div>
                      )}
                      <label style={{ display:'flex', alignItems:'center', gap:8, marginBottom:12, cursor:'pointer', fontSize:12, color:'#555' }}>
                        <input type="checkbox" checked={applyDiscount} onChange={e=>setApplyDiscount(e.target.checked)} style={{ width:15, height:15, cursor:'pointer' }}/>
                        Apply dealer discount of
                        <input type="number" step="0.5" min="0" max="50" value={discountPct !== '' ? discountPct : ((selectedJob?.dealer_discount_pct || 0.05)*100)} onChange={e=>setDiscountPct(e.target.value)} onClick={e=>e.stopPropagation()} style={{ width:55, padding:'2px 6px', border:'0.5px solid #ccc', borderRadius:5, fontSize:12, margin:'0 4px' }}/>% to gross cost
                      </label>
                      <label style={{ display:'flex', alignItems:'center', gap:8, marginBottom:12, cursor:'pointer', fontSize:12, color:'#555' }}>
                        <input type="checkbox" checked={hideUnitPricing} onChange={e=>setHideUnitPricing(e.target.checked)} style={{ width:15, height:15, cursor:'pointer' }}/>
                        Hide unit breakdown — lump sum only (shows unit/amenity counts, no per-unit table)
                      </label>
                      <label style={{ display:'flex', alignItems:'center', gap:8, marginBottom:12, cursor:'pointer', fontSize:12, color:'#555' }}>
                        <input type="checkbox" checked={totalOnly} onChange={e=>setTotalOnly(e.target.checked)} style={{ width:15, height:15, cursor:'pointer' }}/>
                        Grand total only — hide Base/Freight/Tax/Hardware lines, show one TOTAL
                      </label>
                      <label style={{ display:'flex', alignItems:'center', gap:8, marginBottom:12, cursor:'pointer', fontSize:12, color:'#555' }}>
                        <input type="checkbox" checked={brandAs==='greenworks'} onChange={e=>setBrandAs(e.target.checked?'greenworks':'mdsg')} style={{ width:15, height:15, cursor:'pointer' }}/>
                        Bid under Greenworks umbrella (turnkey from Willy — no MDSG branding)
                      </label>
                      <div style={{ display:'flex', gap:10, alignItems:'flex-end', marginBottom:12 }}>
                        <div>
                          <label style={lbl}>Hardware Pieces</label>
                          <input type="number" min="0" value={hwPieces} placeholder="0" onChange={e=>setHwPieces(e.target.value)} style={{ width:100, padding:'7px 10px', border:'0.5px solid #ccc', borderRadius:6, fontSize:13 }}/>
                        </div>
                        <div>
                          <label style={lbl}>$/Piece (our cost)</label>
                          <input type="number" min="0" step="0.25" value={hwRate} onChange={e=>setHwRate(e.target.value)} style={{ width:90, padding:'7px 10px', border:'0.5px solid #ccc', borderRadius:6, fontSize:13 }}/>
                        </div>
                        {Number(hwPieces)>0 && <span style={{ fontSize:11, color:'#2D7A3A', paddingBottom:9 }}>= ${(Number(hwPieces)*Number(hwRate)).toLocaleString(undefined,{maximumFractionDigits:0})} cost → marked up with margin</span>}
                      </div>
                      <label style={lbl}>Gross Margin %</label>
                      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                        <input type="number" step="1" min="0" max="60" value={proposalMargin} onChange={e => setProposalMargin(e.target.value)} style={{ width: 80, padding: '7px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }} />
                        {marginPricePreview && <span style={{ fontSize: 12, color: '#3B6D11', fontWeight: 500 }}>→ sell price ≈ {marginPricePreview} (before freight/discount/tax)</span>}
                      </div>
                      <div style={{ display: 'flex', gap: 6 }}>
                        {[15, 20, 25, 30, 35].map(m => (<button key={m} onClick={() => setProposalMargin(m)} style={{ padding: '4px 9px', fontSize: 11, borderRadius: 6, cursor: 'pointer', background: Number(proposalMargin) === m ? '#3C3489' : '#f5f5f3', color: Number(proposalMargin) === m ? '#fff' : '#555', border: '0.5px solid #ddd' }}>{m}%</button>))}
                      </div>
                    </div>
                    <div style={{ marginBottom: 14 }}>
                      <label style={lbl}>Sales Tax %</label>
                      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                        <input type="number" step="0.01" min="0" max="20" value={proposalSalesTax} onChange={e => setProposalSalesTax(e.target.value)} style={{ width: 80, padding: '7px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }} />
                        <span style={{ fontSize: 12, color: '#555' }}>%</span>
                      </div>
                      <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                        {[0, 7.65, 8.00, 9.15].map(t => (<button key={t} onClick={() => setProposalSalesTax(t)} style={{ padding: '3px 8px', fontSize: 10, borderRadius: 6, cursor: 'pointer', background: Number(proposalSalesTax) === t ? '#3C3489' : '#f5f5f3', color: Number(proposalSalesTax) === t ? '#fff' : '#555', border: '0.5px solid #ddd' }}>{t === 0 ? 'None' : `${t}%`}</button>))}
                      </div>
                    </div>
                    <div style={{ marginBottom: 12 }}>
                      <label style={lbl}>Sender</label>
                      <select value={proposalSender} onChange={e => setProposalSender(e.target.value)} style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13 }}>
                        <option>Cole</option><option>Pam</option><option>Blake</option>
                      </select>
                    </div>
                    {[
                      ['includedInBid', 'Included in Bid', 40],
                      ['assembly', 'Assembly, Staging & Installation', 48],
                      ['notIncluded', 'Not Included in Bid (one bullet per line)', 90],
                      ['bottomNotes', 'Proposal Notes (bottom of PDF)', 48],
                      ['aliases', 'Unit Name Aliases — merge quote names into takeoff names (QUOTE NAME=TAKEOFF NAME, one per line, e.g. UNIT B=UNIT X-B)', 40],
                    ].map(([key, label, h]) => (
                      <div key={key} style={{ marginBottom: 12 }}>
                        <label style={lbl}>{label}</label>
                        <textarea value={bidSections[key]} onChange={e => setBidSections(p => ({ ...p, [key]: e.target.value }))} style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 11.5, height: h, resize: 'vertical', fontFamily: 'inherit' }} />
                      </div>
                    ))}
                    <button onClick={() => setBidSections(DEFAULT_BID_SECTIONS)} style={{ marginBottom: 14, padding: '4px 10px', fontSize: 11, borderRadius: 6, cursor: 'pointer', background: '#f5f5f3', color: '#555', border: '0.5px solid #ddd' }}>↺ Reset bid sections to defaults</button>
                    <div style={{ marginBottom: 16 }}>
                      <label style={lbl}>Notes (optional)</label>
                      <textarea value={proposalNotes} onChange={e => setProposalNotes(e.target.value)} placeholder="Any additional notes..." style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 12, height: 60, resize: 'vertical' }} />
                    </div>
                    <div style={{ marginBottom: 12 }}>
                      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
                        <span style={{ fontSize:11, fontWeight:600, color:'#888', textTransform:'uppercase', letterSpacing:0.4 }}>Saved Proposal Sets</span>
                        <button onClick={async()=>{ const nm = prompt('Name this proposal set (e.g. CD Set, Permit Set, Addendum 1):'); if(!nm || !nm.trim()) return; const entry = [nm.trim(), new Date().toISOString().split('T')[0], Number(selectedJob.os_bid_value)||0, selectedJob.proposal_status||'draft', authProfile?.name||'']; const sets = [...(selectedJob.proposal_sets||[]), entry]; await supabase.from('jobs').update({ proposal_sets: sets }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, proposal_sets: sets }) }} style={{ padding:'3px 10px', fontSize:10, background:'#3C3489', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>💾 Save Current as Set</button>
                      </div>
                      {(selectedJob.proposal_sets||[]).map((ps, i) => (
                        <div key={i} style={{ display:'flex', gap:10, alignItems:'center', fontSize:11.5, padding:'3px 0', borderTop:'0.5px dotted #eee' }}>
                          <span style={{ fontWeight:600, width:160 }}>{ps[0]}</span>
                          <span style={{ color:'#888' }}>{fmtD(ps[1])}</span>
                          <span style={{ fontWeight:600 }}>{ps[2] > 0 ? '$' + Number(ps[2]).toLocaleString(undefined,{maximumFractionDigits:0}) : '—'}</span>
                          <span style={{ fontSize:9, fontWeight:700, color: ps[3]==='sent' ? '#2D7A3A' : ps[3]==='final' ? '#e0a800' : '#999', textTransform:'uppercase' }}>{ps[3]}</span>
                          <span style={{ color:'#aaa', fontSize:10 }}>{ps[4]}</span>
                          <button onClick={async()=>{ if(!confirm('Remove this saved set?')) return; const sets = (selectedJob.proposal_sets||[]).filter((_,j)=>j!==i); await supabase.from('jobs').update({ proposal_sets: sets }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, proposal_sets: sets }) }} style={{ marginLeft:'auto', background:'none', border:'none', cursor:'pointer', color:'#A32D2D', fontSize:12 }}>✕</button>
                        </div>
                      ))}
                    </div>
                    <button onClick={generateProposal} disabled={proposalLoading} style={{ width: '100%', padding: 10, background: proposalLoading ? '#888' : '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: proposalLoading ? 'default' : 'pointer', fontSize: 13, fontWeight: 500 }}>
                      {proposalLoading ? 'Generating PDF...' : 'Generate & Download Proposal PDF'}
                    </button>
                  </>)}
                    </div>
                </div>

                <div>
                  <div style={card}>
                    <div style={{ fontWeight: 500, marginBottom: 16 }}><Chevron k="ps"/>Pricing Summary</div>
                    {!collapsed.ps && (<>
                    {[['Manufacturer Gross', selectedJob.manufacturer_gross_cost], ['Freight', selectedJob.freight_cost]].map(([label, value]) => (
                      <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: 13, borderBottom: '0.5px solid #f0f0ec' }}>
                        <span style={{ color: '#555' }}>{label}</span><span style={{ fontWeight: 500 }}>{fmt(value)}</span>
                      </div>
                    ))}
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: 13, borderBottom: '0.5px solid #f0f0ec', color: '#3B6D11' }}>
                      <span>Dealer Discount ({((selectedJob.dealer_discount_pct || 0.05) * 100).toFixed(0)}%)</span>
                      <span style={{ fontWeight: 500 }}>− {fmt((selectedJob.manufacturer_gross_cost || 0) * (selectedJob.dealer_discount_pct || 0.05))}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0 0', fontSize: 16, fontWeight: 500 }}>
                      <span>Bid to GC</span><span style={{ color: '#3C3489' }}>{fmt(selectedJob.bid_value)}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: 12 }}>
                      <span style={{ color: '#888' }}>Gross Margin</span>
                      <span style={{ color: (selectedJob.gross_margin_pct || 0) >= 0.25 ? '#3B6D11' : '#854F0B', fontWeight: 500 }}>{fmtPct(selectedJob.gross_margin_pct)}</span>
                    </div>
                  </>)}
                    </div>

                  <div style={card}>
                    <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:6 }}>
                      <div style={{ fontWeight:500 }}><Chevron k="tsk"/>Tasks{Array.isArray(selectedJob.tasks) && selectedJob.tasks.filter(t=>!t[3]).length > 0 && <span style={{ fontSize:11, color:'#888', fontWeight:400, marginLeft:8 }}>{selectedJob.tasks.filter(t=>!t[3]).length} open</span>}</div>
                    </div>
                    {!collapsed.tsk && (<>
                    {(selectedJob.tasks || []).map((t, i) => (
                      <div key={i} style={{ display:'flex', gap:8, alignItems:'center', padding:'2px 0', fontSize:12 }}>
                        <input type="checkbox" checked={!!t[3]} onChange={async()=>{ const nv = (selectedJob.tasks||[]).map((x,j)=> j===i ? [x[0],x[1],x[2],!x[3], !x[3] ? new Date().toISOString().split('T')[0] : null] : x); await supabase.from('jobs').update({ tasks: nv }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, tasks: nv }); loadJobs() }} style={{ width:15, height:15, cursor:'pointer' }}/>
                        <span style={{ flex:1, textDecoration: t[3] ? 'line-through' : 'none', color: t[3] ? '#999' : '#1a1a1a' }}>{t[0]}</span>
                        <span style={{ fontSize:10, fontWeight:600, color:'#3C3489', background:'#f0eff9', padding:'1px 8px', borderRadius:8 }}>{t[1] || '—'}</span>
                        {t[2] && <span style={{ fontSize:10, color: !t[3] && t[2] < todayISO ? '#A32D2D' : '#aaa' }}>{fmtD(t[2])}</span>}
                        <button onClick={async()=>{ const nv = (selectedJob.tasks||[]).filter((_,j)=>j!==i); await supabase.from('jobs').update({ tasks: nv }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, tasks: nv }); loadJobs() }} style={{ background:'none', border:'none', cursor:'pointer', color:'#A32D2D' }}>✕</button>
                      </div>
                    ))}
                    <div style={{ display:'flex', gap:6, marginTop:6 }}>
                      <input id="task-text" placeholder="Task…" style={{ flex:1, padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                      <select id="task-who" defaultValue={authProfile?.name || ''} style={{ padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}>
                        {['Cole','Pam','Vicki','Blake','Tabetha','Team'].map(o => <option key={o}>{o}</option>)}
                      </select>
                      <input id="task-due" type="date" style={{ padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                      <button onClick={async()=>{ const tx = document.getElementById('task-text'), w = document.getElementById('task-who'), d = document.getElementById('task-due'); if(!tx.value.trim()) return; const nv = [...(selectedJob.tasks||[]), [tx.value.trim(), w.value, d.value || null, false, null]]; await supabase.from('jobs').update({ tasks: nv }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, tasks: nv }); loadJobs(); tx.value=''; d.value='' }} style={{ padding:'4px 12px', fontSize:11, background:'#3C3489', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>+ Assign</button>
                    </div>
                    </>)}
                  </div>

                  <div style={card}>
                    <div style={{ display:'flex', alignItems:'center', gap:12, flexWrap:'wrap' }}>
                      <div style={{ fontWeight:500 }}><Chevron k="trk"/>ORDER TRACKING</div>
                      <div style={{ display:'flex', gap:4, alignItems:'center' }}>
                        <span style={{ fontSize:11, color:'#888' }}>Priority:</span>
                        {['low','normal','high','hot'].map(pr => (
                          <button key={pr} onClick={async()=>{ await supabase.from('jobs').update({ priority: pr }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, priority: pr }); loadJobs() }} style={{ padding:'3px 10px', fontSize:10, borderRadius:10, cursor:'pointer', textTransform:'capitalize', fontWeight:600, background:(selectedJob.priority||'normal')===pr ? ({ low:'#8a8a8a', normal:'#1B5EA6', high:'#e0a800', hot:'#A32D2D' })[pr] : '#f5f5f3', color:(selectedJob.priority||'normal')===pr ? '#fff' : '#888', border:'none' }}>{pr === 'hot' ? '🔥 hot' : pr}</button>
                        ))}
                      </div>
                      <button onClick={()=>openEmailPanel('generic')} style={{ padding:'3px 12px', fontSize:11, background:'#1B5EA6', color:'#fff', border:'none', borderRadius:6, cursor:'pointer', fontWeight:500 }}>✉ Email</button>
                      <label style={{ display:'flex', alignItems:'center', gap:4, fontSize:10, color: selectedJob.is_test ? '#8B6914' : '#bbb', cursor:'pointer' }}>
                        <input type="checkbox" checked={!!selectedJob.is_test} onChange={async e=>{ const v = e.target.checked; await supabase.from('jobs').update({ is_test: v }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, is_test: v }); loadJobs() }} style={{ width:13, height:13 }}/>🧪 Test job
                      </label>
                      <div style={{ display:'flex', gap:6, alignItems:'center' }}>
                        <span style={{ fontSize:11, color:'#888' }}>Next follow-up:</span>
                        <input type="date" value={selectedJob.next_followup_date || ''} onChange={async e=>{ const v = e.target.value || null; await supabase.from('jobs').update({ next_followup_date: v }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, next_followup_date: v }); loadJobs() }} style={{ padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                      </div>
                      <div style={{ display:'flex', gap:6, alignItems:'center' }}>
                        <span style={{ fontSize:11, color:'#888' }}>Ship:</span>
                        <input type="date" value={selectedJob.ship_date || ''} onChange={async e=>{ const v = e.target.value || null; await supabase.from('jobs').update({ ship_date: v }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, ship_date: v }) }} style={{ padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                        <span style={{ fontSize:11, color:'#888' }}>Delivery:</span>
                        <input type="date" value={selectedJob.est_delivery || ''} onChange={async e=>{ const v = e.target.value || null; await supabase.from('jobs').update({ est_delivery: v }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, est_delivery: v }); loadJobs() }} style={{ padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                        <label style={{ display:'flex', alignItems:'center', gap:5, fontSize:11, color: selectedJob.notify_delivery ? '#2D7A3A' : '#888', cursor:'pointer', fontWeight: selectedJob.notify_delivery ? 600 : 400 }}>
                          <input type="checkbox" checked={!!selectedJob.notify_delivery} onChange={async e=>{ const v = e.target.checked; if (v && !selectedJob.est_delivery) { alert('Set a delivery date first'); return } if (v && !selectedJob.gc_email) { if(!confirm('No GC email on this job — notices will go to Willy only. Continue?')) return } await supabase.from('jobs').update({ notify_delivery: v }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, notify_delivery: v }); await supabase.from('activity_log').insert({ job_id: selectedJob.id, user_name: authProfile?.name || 'MDSG', action: v ? 'Auto delivery notices ON (GC + Willy, weekly + 2-day)' : 'Auto delivery notices OFF' }) }} style={{ width:14, height:14, cursor:'pointer' }}/>
                          📣 Auto-notify GC + Willy
                        </label>
                      </div>
                    </div>
                    {!collapsed.trk && (<>
                    <div style={{ marginTop:10 }}>
                      <div style={{ fontSize:11, color:'#888', fontWeight:600, marginBottom:4 }}>KEY DATES</div>
                      {(selectedJob.key_dates || []).map((kd, i) => (
                        <div key={i} style={{ display:'flex', gap:8, alignItems:'center', padding:'2px 0', fontSize:12 }}>
                          <span style={{ width:220, fontWeight:600, color:'#555' }}>{kd[0]}</span>
                          <span>{fmtD(kd[1])}</span>
                          <button onClick={async()=>{ const kds = (selectedJob.key_dates||[]).filter((_,j)=>j!==i); await supabase.from('jobs').update({ key_dates: kds }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, key_dates: kds }) }} style={{ background:'none', border:'none', cursor:'pointer', color:'#A32D2D', fontSize:12 }}>✕</button>
                        </div>
                      ))}
                      <div style={{ display:'flex', gap:6, marginTop:6 }}>
                        <input id="kd-label" placeholder="Label (e.g. Samples due, Walk-through)" style={{ flex:1, padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                        <input id="kd-date" type="date" style={{ padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                        <button onClick={async()=>{ const l = document.getElementById('kd-label'); const d = document.getElementById('kd-date'); if(!l.value.trim()) return; const kds = [...(selectedJob.key_dates||[]), [l.value.trim(), d.value || '']]; await supabase.from('jobs').update({ key_dates: kds }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, key_dates: kds }); l.value=''; d.value='' }} style={{ padding:'4px 12px', fontSize:11, background:'#3C3489', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>+ Add</button>
                      </div>
                    </div>
                  </>)}
                    </div>

                  <div style={card}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                      <div style={{ fontWeight: 500 }}><Chevron k="shp"/>Shipments</div>
                      <button onClick={() => setShowShipmentForm(true)} style={{ fontSize: 11, padding: '4px 12px', background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer' }}>+ Add Load</button>
                    </div>
                    {!collapsed.shp && (<>
                    {showShipmentForm && (
                      <div style={{ background: '#f5f5f3', borderRadius: 8, padding: 14, marginBottom: 14 }}>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 8 }}>
                          <div><label style={lbl}>Load #</label><input type="number" min="1" value={newShipment.load_number} onChange={e => setNewShipment(p => ({ ...p, load_number: Number(e.target.value) }))} style={inp} /></div>
                          <div><label style={lbl}>Total Loads</label><input type="number" min="1" value={newShipment.total_loads} onChange={e => setNewShipment(p => ({ ...p, total_loads: Number(e.target.value) }))} style={inp} /></div>
                        </div>
                        <div style={{ marginBottom: 8 }}><label style={lbl}>Carrier</label><select value={newShipment.carrier} onChange={e => setNewShipment(p => ({ ...p, carrier: e.target.value }))} style={inp}>{CARRIERS.map(c => <option key={c}>{c}</option>)}</select></div>
                        <div style={{ marginBottom: 8 }}><label style={lbl}>Tracking Number</label><input value={newShipment.tracking_number} onChange={e => setNewShipment(p => ({ ...p, tracking_number: e.target.value }))} style={inp} /></div>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 8 }}>
                          <div><label style={lbl}>Expected Delivery</label><input type="date" value={newShipment.scheduled_date} onChange={e => setNewShipment(p => ({ ...p, scheduled_date: e.target.value }))} style={inp} /></div>
                          <div><label style={lbl}>Cabinets in Load</label><input type="number" value={newShipment.cabinet_count} onChange={e => setNewShipment(p => ({ ...p, cabinet_count: e.target.value }))} style={inp} /></div>
                        </div>
                        <div style={{ marginBottom: 8 }}><label style={lbl}>Floors / Units Covered</label><input value={newShipment.floors_covered} onChange={e => setNewShipment(p => ({ ...p, floors_covered: e.target.value }))} style={inp} /></div>
                        <div style={{ marginBottom: 8 }}><label style={lbl}>Site Contact</label><input value={newShipment.delivery_contact} onChange={e => setNewShipment(p => ({ ...p, delivery_contact: e.target.value }))} style={inp} /></div>
                        <div style={{ marginBottom: 12 }}><label style={lbl}>Notes</label><input value={newShipment.notes} onChange={e => setNewShipment(p => ({ ...p, notes: e.target.value }))} style={inp} /></div>
                        <div style={{ display: 'flex', gap: 8 }}>
                          <button onClick={createShipment} disabled={savingShipment} style={{ flex: 1, padding: '7px', background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12 }}>{savingShipment ? 'Saving...' : 'Add Shipment'}</button>
                          <button onClick={() => { setShowShipmentForm(false); setNewShipment(emptyShipment) }} style={{ flex: 1, padding: '7px', background: '#f5f5f3', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer', fontSize: 12 }}>Cancel</button>
                        </div>
                      </div>
                    )}
                    {shipments.length === 0 && !showShipmentForm && <div style={{ color: '#888', fontSize: 12 }}>No shipments yet</div>}
                    {shipments.map(s => (
                      <div key={s.id} style={{ border: '0.5px solid #e5e5e0', borderRadius: 8, padding: 12, marginBottom: 10, background: s.status === 'Delayed' ? '#FFF8F0' : '#fff' }}>
                        {editingShipment?.id === s.id ? (
                          <div>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 8 }}>
                              <div><label style={lbl}>Tracking #</label><input value={editingShipment.tracking_number || ''} onChange={e => setEditingShipment(p => ({ ...p, tracking_number: e.target.value }))} style={inp} /></div>
                              <div><label style={lbl}>Expected Date</label><input type="date" value={editingShipment.scheduled_date || ''} onChange={e => setEditingShipment(p => ({ ...p, scheduled_date: e.target.value }))} style={inp} /></div>
                            </div>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 8 }}>
                              <div><label style={lbl}>Floors / Units</label><input value={editingShipment.floors_covered || ''} onChange={e => setEditingShipment(p => ({ ...p, floors_covered: e.target.value }))} style={inp} /></div>
                              <div><label style={lbl}>Cabinets</label><input type="number" value={editingShipment.cabinet_count || ''} onChange={e => setEditingShipment(p => ({ ...p, cabinet_count: e.target.value }))} style={inp} /></div>
                            </div>
                            <div style={{ marginBottom: 10 }}><label style={lbl}>Notes</label><input value={editingShipment.notes || ''} onChange={e => setEditingShipment(p => ({ ...p, notes: e.target.value }))} style={inp} /></div>
                            <div style={{ display: 'flex', gap: 6 }}>
                              <button onClick={saveShipmentEdit} disabled={savingShipment} style={{ flex: 1, padding: '6px', background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 11 }}>Save</button>
                              <button onClick={() => setEditingShipment(null)} style={{ flex: 1, padding: '6px', background: '#f5f5f3', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer', fontSize: 11 }}>Cancel</button>
                            </div>
                          </div>
                        ) : (
                          <div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                              <div>
                                <div style={{ fontWeight: 500, fontSize: 13 }}>Load {s.load_number} of {s.total_loads}</div>
                                <div style={{ fontSize: 11, color: '#888', marginTop: 2 }}>{s.carrier}{s.tracking_number ? ` · ${s.tracking_number}` : ''}</div>
                              </div>
                              <ShipmentBadge status={s.status} />
                            </div>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4, fontSize: 12, marginBottom: 10 }}>
                              {s.scheduled_date && <div><span style={{ color: '#888' }}>Expected: </span>{s.scheduled_date}</div>}
                              {s.cabinet_count && <div><span style={{ color: '#888' }}>Cabinets: </span>{Number(s.cabinet_count).toLocaleString()}</div>}
                              {s.floors_covered && <div style={{ gridColumn: '1/-1' }}><span style={{ color: '#888' }}>Floors/Units: </span>{s.floors_covered}</div>}
                              {s.notes && <div style={{ gridColumn: '1/-1', color: '#888', fontStyle: 'italic' }}>{s.notes}</div>}
                            </div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                              <StatusButtons shipment={s} />
                              <div style={{ display: 'flex', gap: 6 }}>
                                <button onClick={() => setEditingShipment({ ...s })} style={{ fontSize: 10, padding: '3px 8px', background: '#f5f5f3', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer' }}>Edit</button>
                                <button onClick={() => deleteShipment(s.id)} style={{ fontSize: 10, padding: '3px 8px', background: '#FCEBEB', color: '#A32D2D', border: 'none', borderRadius: 6, cursor: 'pointer' }}>Remove</button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </>)}
                    </div>

                  {emailOpen && (
                      <div style={{ border:'0.5px solid #b9cbe0', background:'#f4f8fc', borderRadius:8, padding:14, marginBottom:12 }}>
                        <div style={{ display:'flex', justifyContent:'space-between', marginBottom:8 }}>
                          <div style={{ fontSize:12, fontWeight:600, color:'#1B5EA6' }}>Email — sends from {authProfile?.email} · logs to Activity <button onClick={()=>{ setSigDraft(authProfile?.signature || mySig()); setSigEditing(v=>!v) }} style={{ marginLeft:8, padding:'2px 8px', fontSize:10, background:'#f5f5f3', border:'0.5px solid #ddd', borderRadius:5, cursor:'pointer', fontWeight:400 }}>✎ signature</button></div>
                      {sigEditing && (
                        <div style={{ margin:'8px 0' }}>
                          <textarea value={sigDraft} onChange={e=>setSigDraft(e.target.value)} rows={9} style={{ width:'100%', padding:8, border:'0.5px solid #ccc', borderRadius:6, fontSize:11, fontFamily:'inherit' }}/>
                          <div style={{ display:'flex', gap:6, marginTop:4 }}>
                            <button onClick={async()=>{ await supabase.from('user_profiles').update({ signature: sigDraft }).eq('email', authProfile.email); setAuthProfile({ ...authProfile, signature: sigDraft }); setSigEditing(false) }} style={{ padding:'4px 12px', fontSize:11, background:'#3C3489', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>Save Signature</button>
                            <button onClick={()=>setSigEditing(false)} style={{ padding:'4px 12px', fontSize:11, background:'#f5f5f3', border:'0.5px solid #ddd', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                          </div>
                          <div style={{ fontSize:10, color:'#999', marginTop:2 }}>Paste your Outlook signature text here — it appends to every email you send from the OS.</div>
                        </div>
                      )}
                          <button onClick={()=>setEmailOpen(false)} style={{ background:'none', border:'none', cursor:'pointer', color:'#bbb' }}>✕</button>
                        </div>
                        <div style={{ display:'flex', gap:6, marginBottom:6, alignItems:'center' }}>
                          <label style={{ fontSize:11, color:'#888', width:52 }}>To:</label>
                          <input value={emailTo} onChange={e=>setEmailTo(e.target.value)} placeholder="email, email" style={{ flex:1, padding:'6px 10px', border:'0.5px solid #ccc', borderRadius:6, fontSize:12 }}/>
                          {REP_QUICKPICKS.filter(r=>r[1]).map(r => (
                            <button key={r[0]} onClick={()=>setEmailTo(t=>t ? t + ', ' + r[1] : r[1])} style={{ padding:'3px 8px', fontSize:10, background:'#fff', border:'0.5px solid #b9cbe0', borderRadius:5, cursor:'pointer', color:'#1B5EA6' }}>{r[0].split(' ')[0]}</button>
                          ))}
                        </div>
                        <div style={{ display:'flex', gap:6, marginBottom:6, alignItems:'center' }}>
                          <label style={{ fontSize:11, color:'#888', width:52 }}>Cc:</label>
                          <input value={emailCc} onChange={e=>setEmailCc(e.target.value)} placeholder="optional" style={{ flex:1, padding:'6px 10px', border:'0.5px solid #ccc', borderRadius:6, fontSize:12 }}/>
                        </div>
                        <div style={{ display:'flex', gap:6, marginBottom:6, alignItems:'center' }}>
                          <label style={{ fontSize:11, color:'#888', width:52 }}>Subject:</label>
                          <input value={emailSubject} onChange={e=>setEmailSubject(e.target.value)} style={{ flex:1, padding:'6px 10px', border:'0.5px solid #ccc', borderRadius:6, fontSize:12 }}/>
                        </div>
                        <textarea value={emailBody} onChange={e=>setEmailBody(e.target.value)} rows={5} style={{ width:'100%', padding:'8px 10px', border:'0.5px solid #ccc', borderRadius:6, fontSize:12, boxSizing:'border-box', marginBottom:8, fontFamily:'inherit' }}/>
                        <div style={{ display:'flex', gap:10, alignItems:'center' }}>
                          <button onClick={sendQuoteEmail} disabled={emailSending || !emailTo.trim()} style={{ padding:'7px 16px', fontSize:12, background:'#1B5EA6', color:'#fff', border:'none', borderRadius:6, cursor:'pointer', fontWeight:500 }}>{emailSending ? 'Sending…' : (emailAttachQuote ? 'Send with Quote attached' : 'Send')}</button>
                          <label style={{ display:'flex', alignItems:'center', gap:5, fontSize:11, color:'#555', cursor:'pointer' }}><input type="checkbox" checked={emailAttachQuote} onChange={e=>setEmailAttachQuote(e.target.checked)} disabled={!cabList} style={{ width:13, height:13 }}/>Attach Quote xlsx</label>
                          <label style={{ display:'flex', alignItems:'center', gap:5, fontSize:11, color:'#555' }}>Follow-up:<input type="date" value={emailFollowUp} onChange={e=>setEmailFollowUp(e.target.value)} style={{ padding:'3px 6px', border:'0.5px solid #ccc', borderRadius:5, fontSize:11 }}/></label>
                          {emailResult?.ok && <span style={{ fontSize:12, color:'#2D7A3A', fontWeight:600 }}>✓ Sent & logged</span>}
                          {emailResult?.error && <span style={{ fontSize:12, color:'#A32D2D' }}>✗ {emailResult.error}</span>}
                        </div>
                      </div>
                  )}

                  {/* ── Scope of Work ──────────────────────────────────── */}
                  <div style={card}>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
                      <div style={{ fontWeight: 500 }}><Chevron k="sow"/>Scope of Work</div>
                      <div style={{ display:'flex', gap:6 }}>
                        {!sowRows && !sowEditing && <button onClick={()=>{ setSowRows(sowTemplate()); setSowEditing(true) }} style={{ padding:'4px 12px', fontSize:11, background:'#3C3489', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>+ Start from Template</button>}
                        {sowRows && !sowEditing && <button onClick={async()=>{ const res = await fetch('/api/generate-sow', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ jobId: selectedJob.id }) }); if(res.ok){ const b = await res.blob(); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href=u; a.download=`${selectedJob.name.replace(/[^a-zA-Z0-9_-]/g,'_')}_Scope_of_Work.pdf`; a.click(); URL.revokeObjectURL(u) } else { const d = await res.json(); alert(d.error || 'SOW PDF failed') } }} style={{ padding:'4px 12px', fontSize:11, background:'#1B5EA6', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>🖨 Print / Share PDF</button>}
                        {sowRows && !sowEditing && <button onClick={()=>{ const fresh = sowTemplate(); const merged = sowRows.map(r => { if (r[1]) return r; const m = fresh.find(f => f[0] === r[0] && f[1]); return m ? [r[0], m[1]] : r }); setSowRows(merged); saveSow(merged) }} title="Fill empty fields from job data" style={{ padding:'4px 12px', fontSize:11, background:'#f5f5f3', border:'0.5px solid #ddd', borderRadius:6, cursor:'pointer' }}>↻ Pull Job Data</button>}
                        {sowRows && !sowEditing && <button onClick={()=>setSowEditing(true)} style={{ padding:'4px 12px', fontSize:11, background:'#f5f5f3', border:'0.5px solid #ddd', borderRadius:6, cursor:'pointer' }}>✎ Edit</button>}
                        {sowEditing && <button onClick={()=>saveSow(sowRows.filter(r=>r[0].trim()))} disabled={sowSaving} style={{ padding:'4px 12px', fontSize:11, background:'#2D7A3A', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>{sowSaving?'Saving...':'✓ Save'}</button>}
                      </div>
                    </div>
                    {!collapsed.sow && !sowRows && !sowEditing && <div style={{ fontSize:12, color:'#bbb' }}>No scope documented yet — start from the template and adapt per project.</div>}
                    {!collapsed.sow && sowRows && (
                      <div>
                        {sowRows.map((r, i) => (
                          <div key={i} style={{ display:'flex', gap:8, alignItems:'center', padding:'3px 0', borderTop: i>0 ? '0.5px dotted #eee' : 'none' }}>
                            {sowEditing ? (
                              <>
                                <input value={r[0]} onChange={e=>setSowRows(rs=>rs.map((x,j)=>j===i?[e.target.value,x[1]]:x))} style={{ width:260, padding:'3px 8px', border:'0.5px solid #ccc', borderRadius:4, fontSize:12, fontWeight:600 }}/>
                                <input value={r[1]} onChange={e=>setSowRows(rs=>rs.map((x,j)=>j===i?[x[0],e.target.value]:x))} style={{ flex:1, padding:'3px 8px', border:'0.5px solid #ccc', borderRadius:4, fontSize:12 }}/>
                                <button onClick={()=>setSowRows(rs=>rs.filter((_,j)=>j!==i))} style={{ background:'none', border:'none', cursor:'pointer', color:'#A32D2D', fontSize:13 }}>✕</button>
                              </>
                            ) : r[0].startsWith('— ') ? (
                              <span style={{ flex:1, fontSize:11, fontWeight:700, color:'#3C3489', letterSpacing:0.5, background:'#f0eff9', padding:'3px 8px', borderRadius:4 }}>{r[0].replace(/—/g,'').trim()}</span>
                            ) : (
                              <>
                                <span style={{ width:260, fontSize:12, fontWeight:600, color:'#555' }}>{r[0]}</span>
                                <span style={{ flex:1, fontSize:12, color: r[1] ? '#1a1a1a' : '#ccc' }}>{r[1] || '—'}</span>
                              </>
                            )}
                          </div>
                        ))}
                        {sowEditing && <button onClick={()=>setSowRows(rs=>[...rs, ['','']])} style={{ marginTop:8, padding:'4px 12px', fontSize:11, background:'#f5f5f3', border:'0.5px dashed #bbb', borderRadius:6, cursor:'pointer', color:'#555' }}>+ Add Row</button>}
                      </div>
                    )}
                  </div>

                  {['Awarded','Shop Drawings','Ordered','Delivered','Closeout'].includes(selectedJob.stage) && (
                  <div style={card}>
                    {(() => {
                      const inv = selectedJob.invoices || []
                      const cos = selectedJob.change_orders || []
                      const contract = Number(selectedJob.os_bid_value) || Number(selectedJob.bid_value) || 0
                      const coApproved = cos.filter(c => c[3] === 'approved').reduce((s, c) => s + (Number(c[2]) || 0), 0)
                      const revised = contract + coApproved
                      const billed = inv.reduce((s, i) => s + (Number(i[2]) || 0), 0)
                      const paid = inv.filter(i => i[3] === 'paid').reduce((s, i) => s + (Number(i[2]) || 0), 0)
                      const saveFin = async (patch) => { await supabase.from('jobs').update(patch).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, ...patch }) }
                      return (
                        <div>
                          <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8 }}>
                            <div style={{ fontWeight:500 }}><Chevron k="fin"/>Billing & Change Orders</div>
                            <span style={{ fontSize:11, color:'#888' }}>Contract {fmt(contract)}{coApproved > 0 ? ` + COs ${fmt(coApproved)} = ${fmt(revised)}` : ''} · Billed {fmt(billed)} · Paid {fmt(paid)}{billed - paid > 0 ? ` · AR ${fmt(billed - paid)}` : ''}</span>
                          </div>
                          {!collapsed.fin && (<>
                          <div style={{ fontSize:10, fontWeight:700, color:'#3C3489', letterSpacing:0.5, margin:'6px 0 2px' }}>INVOICES / PAY APPS</div>
                          {inv.map((r, i) => (
                            <div key={i} style={{ display:'flex', gap:8, alignItems:'center', padding:'2px 0', fontSize:12 }}>
                              <span style={{ width:90, fontWeight:600 }}>{r[0]}</span>
                              <span style={{ width:70, color:'#888' }}>{fmtD(r[1])}</span>
                              <span style={{ width:90, fontWeight:600 }}>{fmt(Number(r[2])||0)}</span>
                              <button onClick={()=>{ const nv = inv.map((x,j)=> j===i ? [x[0],x[1],x[2], x[3]==='paid'?'unpaid':'paid'] : x); saveFin({ invoices: nv }) }} style={{ padding:'2px 10px', fontSize:10, borderRadius:10, border:'none', cursor:'pointer', fontWeight:600, background: r[3]==='paid' ? '#2D7A3A' : '#f0d9a8', color: r[3]==='paid' ? '#fff' : '#7a5c00' }}>{r[3]==='paid' ? '✓ PAID' : 'UNPAID'}</button>
                              <button onClick={()=>{ if(!confirm('Remove invoice?')) return; saveFin({ invoices: inv.filter((_,j)=>j!==i) }) }} style={{ background:'none', border:'none', cursor:'pointer', color:'#A32D2D' }}>✕</button>
                            </div>
                          ))}
                          <div style={{ display:'flex', gap:6, margin:'4px 0 10px' }}>
                            <input id="inv-num" placeholder="Inv/App #" style={{ width:90, padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                            <input id="inv-date" type="date" style={{ padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                            <input id="inv-amt" type="number" placeholder="$" style={{ width:100, padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                            <button onClick={()=>{ const n = document.getElementById('inv-num'), d = document.getElementById('inv-date'), a = document.getElementById('inv-amt'); if(!n.value.trim() || !(Number(a.value)>0)) return; saveFin({ invoices: [...inv, [n.value.trim(), d.value || new Date().toISOString().split('T')[0], Number(a.value), 'unpaid']] }); n.value=''; d.value=''; a.value='' }} style={{ padding:'4px 12px', fontSize:11, background:'#3C3489', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>+ Invoice</button>
                          </div>
                          <div style={{ fontSize:10, fontWeight:700, color:'#3C3489', letterSpacing:0.5, margin:'6px 0 2px' }}>CHANGE ORDERS</div>
                          {cos.map((r, i) => (
                            <div key={i} style={{ display:'flex', gap:8, alignItems:'center', padding:'2px 0', fontSize:12 }}>
                              <span style={{ width:60, fontWeight:600 }}>{r[0]}</span>
                              <span style={{ flex:1, color:'#555' }}>{r[1]}</span>
                              <span style={{ width:90, fontWeight:600 }}>{fmt(Number(r[2])||0)}</span>
                              <button onClick={()=>{ const nv = cos.map((x,j)=> j===i ? [x[0],x[1],x[2], x[3]==='approved'?'pending':'approved', x[4]] : x); saveFin({ change_orders: nv }) }} style={{ padding:'2px 10px', fontSize:10, borderRadius:10, border:'none', cursor:'pointer', fontWeight:600, background: r[3]==='approved' ? '#2D7A3A' : '#f0d9a8', color: r[3]==='approved' ? '#fff' : '#7a5c00' }}>{r[3]==='approved' ? '✓ APPROVED' : 'PENDING'}</button>
                              <button onClick={()=>{ if(!confirm('Remove change order?')) return; saveFin({ change_orders: cos.filter((_,j)=>j!==i) }) }} style={{ background:'none', border:'none', cursor:'pointer', color:'#A32D2D' }}>✕</button>
                            </div>
                          ))}
                          <div style={{ display:'flex', gap:6, marginTop:4 }}>
                            <input id="co-num" placeholder="CO #" style={{ width:60, padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                            <input id="co-desc" placeholder="Description" style={{ flex:1, padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                            <input id="co-amt" type="number" placeholder="$ (± ok)" style={{ width:100, padding:'4px 8px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11 }}/>
                            <button onClick={()=>{ const n = document.getElementById('co-num'), ds = document.getElementById('co-desc'), a = document.getElementById('co-amt'); if(!n.value.trim() || !a.value) return; saveFin({ change_orders: [...cos, [n.value.trim(), ds.value.trim(), Number(a.value), 'pending', new Date().toISOString().split('T')[0]]] }); n.value=''; ds.value=''; a.value='' }} style={{ padding:'4px 12px', fontSize:11, background:'#3C3489', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>+ CO</button>
                          </div>
                          </>)}
                        </div>
                      )
                    })()}
                  </div>
                  )}

                  {['Awarded','Shop Drawings','Ordered','Delivered','Closeout'].includes(selectedJob.stage) && (
                  <div style={card}>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
                      <div style={{ fontWeight: 500 }}><Chevron k="pa"/>Post-Award Checklist{paRows && <span style={{ fontSize:11, color:'#888', fontWeight:400, marginLeft:8 }}>{paRows.filter(r=>r[2]).length}/{paRows.length} done</span>}</div>
                      <div style={{ display:'flex', gap:6 }}>
                        {!paRows && <button onClick={()=>{ const t = PA_TEMPLATE.map(r=>[r[0],r[1],false,null]); setPaRows(t); savePa(t) }} style={{ padding:'4px 12px', fontSize:11, background:'#3C3489', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>+ Start Checklist</button>}
                        {paRows && !paEditing && <button onClick={()=>setPaEditing(true)} style={{ padding:'4px 12px', fontSize:11, background:'#f5f5f3', border:'0.5px solid #ddd', borderRadius:6, cursor:'pointer' }}>✎ Edit Tasks</button>}
                        {paEditing && <button onClick={()=>savePa(paRows.filter(r=>r[1].trim()))} disabled={paSaving} style={{ padding:'4px 12px', fontSize:11, background:'#2D7A3A', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>{paSaving?'Saving...':'✓ Done Editing'}</button>}
                      </div>
                    </div>
                    {!collapsed.pa && paRows && (() => {
                      let lastPhase = null
                      return paRows.map((r, i) => {
                        const showPhase = r[0] !== lastPhase; lastPhase = r[0]
                        return (
                          <div key={i}>
                            {showPhase && <div style={{ fontSize:10, fontWeight:700, color:'#3C3489', letterSpacing:0.5, margin:'8px 0 2px' }}>{r[0]}</div>}
                            <div style={{ display:'flex', gap:8, alignItems:'center', padding:'2px 0' }}>
                              {paEditing ? (
                                <>
                                  <input value={r[0]} onChange={e=>setPaRows(rs=>rs.map((x,j)=>j===i?[e.target.value.toUpperCase(),x[1],x[2],x[3]]:x))} style={{ width:120, padding:'2px 6px', border:'0.5px solid #ccc', borderRadius:4, fontSize:11 }}/>
                                  <input value={r[1]} onChange={e=>setPaRows(rs=>rs.map((x,j)=>j===i?[x[0],e.target.value,x[2],x[3]]:x))} style={{ flex:1, padding:'2px 6px', border:'0.5px solid #ccc', borderRadius:4, fontSize:12 }}/>
                                  <button onClick={()=>setPaRows(rs=>rs.filter((_,j)=>j!==i))} style={{ background:'none', border:'none', cursor:'pointer', color:'#A32D2D' }}>✕</button>
                                </>
                              ) : (
                                <>
                                  <input type="checkbox" checked={!!r[2]} onChange={()=>togglePaTask(i)} style={{ width:15, height:15, cursor:'pointer' }}/>
                                  <span style={{ flex:1, fontSize:12, color: r[2] ? '#999' : '#1a1a1a', textDecoration: r[2] ? 'line-through' : 'none' }}>{r[1]}</span>
                                  {r[3] && <span style={{ fontSize:10, color:'#aaa' }}>{r[3]}</span>}
                                </>
                              )}
                            </div>
                          </div>
                        )
                      })
                    })()}
                    {!collapsed.pa && paEditing && <button onClick={()=>setPaRows(rs=>[...rs, ['PHASE','',false,null]])} style={{ marginTop:8, padding:'4px 12px', fontSize:11, background:'#f5f5f3', border:'0.5px dashed #bbb', borderRadius:6, cursor:'pointer', color:'#555' }}>+ Add Task</button>}
                  </div>
                  )}

                  {['Ordered','Delivered','Closeout'].includes(selectedJob.stage) && (
                  <div style={card}>
                    <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10 }}>
                      <div style={{ fontWeight:500 }}><Chevron k="punch"/>Punch List{Array.isArray(selectedJob.punch_list) && selectedJob.punch_list.length > 0 && <span style={{ fontSize:11, color:'#888', fontWeight:400, marginLeft:8 }}>{selectedJob.punch_list.filter(i=>i[1]).length}/{selectedJob.punch_list.length} done</span>}</div>
                      <button onClick={async()=>{
                        let tok = selectedJob.share_token
                        if (!tok) {
                          tok = (crypto.randomUUID() + crypto.randomUUID()).replace(/-/g,'')
                          await supabase.from('jobs').update({ share_token: tok }).eq('id', selectedJob.id)
                          setSelectedJob({ ...selectedJob, share_token: tok })
                        }
                        const url = window.location.origin + '/punch/' + tok
                        try { await navigator.clipboard.writeText(url); alert('Share link copied!\n\n' + url + '\n\nAnyone with this link can view and check off punch items for this job — send it to Willy or the GC super.') } catch { prompt('Copy this link:', url) }
                      }} style={{ marginLeft:'auto', padding:'4px 12px', fontSize:11, background:'#1B5EA6', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>🔗 Share Link</button>
                    </div>
                    {!collapsed.punch && (
                      <div>
                        {(selectedJob.punch_list || []).map((it, i) => (
                          <div key={i} style={{ display:'flex', gap:8, alignItems:'center', padding:'3px 0', fontSize:12 }}>
                            <input type="checkbox" checked={!!it[1]} onChange={async()=>{ const items = (selectedJob.punch_list||[]).map((x,j)=> j===i ? [x[0], !x[1], !x[1] ? new Date().toISOString().split('T')[0] : null, !x[1] ? (authProfile?.name||'') : ''] : x); await supabase.from('jobs').update({ punch_list: items }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, punch_list: items }) }} style={{ width:15, height:15, cursor:'pointer' }}/>
                            <span style={{ flex:1, textDecoration: it[1] ? 'line-through' : 'none', color: it[1] ? '#999' : '#1a1a1a' }}>{it[0]}</span>
                            {it[2] && <span style={{ fontSize:10, color:'#aaa' }}>{it[3] ? it[3] + ' · ' : ''}{it[2]}</span>}
                            <button onClick={async()=>{ const items = (selectedJob.punch_list||[]).filter((_,j)=>j!==i); await supabase.from('jobs').update({ punch_list: items }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, punch_list: items }) }} style={{ background:'none', border:'none', cursor:'pointer', color:'#A32D2D' }}>✕</button>
                          </div>
                        ))}
                        <div style={{ display:'flex', gap:6, marginTop:8 }}>
                          <input id="punch-new" placeholder="Add punch item…" style={{ flex:1, padding:'5px 10px', border:'0.5px solid #ccc', borderRadius:6, fontSize:12 }}/>
                          <button onClick={async()=>{ const el = document.getElementById('punch-new'); if(!el.value.trim()) return; const items = [...(selectedJob.punch_list||[]), [el.value.trim(), false, null, '']]; await supabase.from('jobs').update({ punch_list: items }).eq('id', selectedJob.id); setSelectedJob({ ...selectedJob, punch_list: items }); el.value='' }} style={{ padding:'5px 14px', fontSize:11, background:'#3C3489', color:'#fff', border:'none', borderRadius:6, cursor:'pointer' }}>+ Add</button>
                        </div>
                      </div>
                    )}
                  </div>
                  )}

                  {/* ── Cab List ───────────────────────────────────────── */}
                  <div style={card}>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
                      <div style={{ fontWeight:500 }}><Chevron k="cab"/>Cabinet List</div>
                      {cabList && !cabEditing && (
                        <div style={{ display:'flex', gap:6, alignItems:'center', flexWrap:'wrap' }}>
                          {['framed','frameless'].map(pl => (
                            <button key={pl} onClick={async()=>{ const upd2 = { ...cabList, product_line: pl }; await saveCabList(upd2, 'product line → ' + pl) }} style={{ padding:'4px 10px', fontSize:11, borderRadius:6, cursor:'pointer', textTransform:'capitalize', background:(cabList.product_line||'framed')===pl?'#3C3489':'#f5f5f3', color:(cabList.product_line||'framed')===pl?'#fff':'#888', border:'0.5px solid #ddd' }}>{pl}</button>
                          ))}
                          <button onClick={exportCabList} disabled={cabExporting} style={{ padding:'4px 12px', fontSize:11, background:'#2D7A3A', color:'#fff', border:'none', borderRadius:6, cursor:'pointer', fontWeight:500 }}>{cabExporting ? 'Exporting...' : '⬇ Export (2 files)'}</button>
                          <button onClick={startCabEdit} style={{ padding:'4px 12px', fontSize:11, background:'#3C3489', color:'#fff', border:'none', borderRadius:6, cursor:'pointer', fontWeight:500 }}>✎ Edit</button>
                          <label style={{ padding:'4px 12px', fontSize:11, background:'#f5f5f3', color:'#555', border:'0.5px solid #ddd', borderRadius:6, cursor:'pointer' }}>
                            {cabSeeding ? 'Importing...' : 'Re-import'}
                            <input type="file" accept=".xlsx,.xlsm" onChange={seedCabListFromExcel} style={{ display:'none' }} disabled={cabSeeding}/>
                          </label>
                          <label style={{ padding:'4px 12px', fontSize:11, background:'#f5f5f3', color:'#1B5EA6', border:'0.5px solid #ddd', borderRadius:6, cursor:'pointer' }}>
                            Leedo PDF
                            <input type="file" accept=".pdf" onChange={importLeedoSummary} style={{ display:'none' }} disabled={cabSeeding}/>
                          </label>
                          <select value={cabCopyTarget} onChange={e=>setCabCopyTarget(e.target.value)} style={{ padding:'4px 8px', fontSize:11, border:'0.5px solid #ddd', borderRadius:6, maxWidth:150 }}>
                            <option value="">Copy to job...</option>
                            {jobs.filter(j => j.id !== selectedJob.id).map(j => <option key={j.id} value={j.id}>{j.name}</option>)}
                          </select>
                          {cabCopyTarget && <button onClick={copyCabListToJob} style={{ padding:'4px 12px', fontSize:11, background:'#3C3489', color:'#fff', border:'none', borderRadius:6, cursor:'pointer', fontWeight:500 }}>Copy</button>}
                          <button onClick={openEmailPanel} style={{ padding:'4px 12px', fontSize:11, background:'#1B5EA6', color:'#fff', border:'none', borderRadius:6, cursor:'pointer', fontWeight:500 }}>✉ Email Quote</button>
                          <button onClick={async()=>{ if(!confirm('Clear the entire cabinet list for this job? This cannot be undone.')) return; await fetch('/api/cab-list', { method:'DELETE', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ jobId: selectedJob.id }) }); setCabList(null); setQuoteCheck(null) }} style={{ padding:'4px 12px', fontSize:11, background:'#fff', color:'#A32D2D', border:'0.5px solid #e0b4b4', borderRadius:6, cursor:'pointer', marginLeft:'auto' }}>Clear List</button>
                        </div>
                      )}
                      {cabEditing && (
                      <datalist id="leedo-sku-suggest">
                        {skuSuggest.map(it => <option key={it.sku} value={it.sku}>{it.description || ''}</option>)}
                      </datalist>
                    )}

                    {cabList && cabEditing && (
                        <div style={{ display:'flex', gap:6, alignItems:'center' }}>
                          {['framed','frameless'].map(pl => (
                            <button key={pl} onClick={()=>cabDraftUpdate(n=>{ n.product_line = pl })} style={{ padding:'4px 10px', fontSize:11, borderRadius:6, cursor:'pointer', textTransform:'capitalize', background:(cabDraft?.product_line||'framed')===pl?'#3C3489':'#f5f5f3', color:(cabDraft?.product_line||'framed')===pl?'#fff':'#888', border:'0.5px solid #ddd' }}>{pl}</button>
                          ))}
                          <button onClick={saveCabEdit} disabled={cabSaving} style={{ padding:'4px 14px', fontSize:11, background:'#2D7A3A', color:'#fff', border:'none', borderRadius:6, cursor:'pointer', fontWeight:600 }}>{cabSaving ? 'Saving...' : '✓ Save'}</button>
                          <button onClick={() => { setCabEditing(false); setCabDraft(null) }} style={{ padding:'4px 12px', fontSize:11, background:'#f5f5f3', color:'#555', border:'0.5px solid #ddd', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                        </div>
                      )}
                    </div>
                    {cabListLoading && <div style={{ fontSize:11, color:'#888' }}>Loading...</div>}
                    {!cabListLoading && !cabList && (
                      <div style={{ display:'flex', gap:10, alignItems:'center' }}>
                        <label style={{ padding:'8px 16px', fontSize:12, background:'#3C3489', color:'#fff', borderRadius:6, cursor:'pointer', fontWeight:500 }}>
                          {cabSeeding ? 'Importing...' : '⬆ Seed from Excel'}
                          <input type="file" accept=".xlsx,.xlsm" onChange={seedCabListFromExcel} style={{ display:'none' }} disabled={cabSeeding}/>
                        </label>
                        <span style={{ fontSize:11, color:'#888' }}>Product line:</span>
                        {['framed','frameless'].map(pl => (
                          <button key={pl} onClick={()=>setProductLine(pl)} style={{ padding:'6px 12px', fontSize:12, borderRadius:6, cursor:'pointer', textTransform:'capitalize', background:productLine===pl?'#3C3489':'#f5f5f3', color:productLine===pl?'#fff':'#555', border:'0.5px solid #ddd' }}>{pl}</button>
                        ))}
                        <label style={{ padding:'8px 16px', fontSize:12, background:'#1B5EA6', color:'#fff', borderRadius:6, cursor:'pointer', fontWeight:500 }}>
                          {cabSeeding ? 'Importing...' : '⬆ Import Leedo Summary (PDF)'}
                          <input type="file" accept=".pdf" onChange={importLeedoSummary} style={{ display:'none' }} disabled={cabSeeding}/>
                        </label>
                        <button onClick={startBlankCabList} style={{ padding:'8px 16px', fontSize:12, background:'#f5f5f3', color:'#555', border:'0.5px solid #ddd', borderRadius:6, cursor:'pointer' }}>Start Blank</button>
                        <span style={{ fontSize:11, color:'#bbb' }}>The editable cabinet list for this job lives here</span>
                      </div>
                    )}
                    {!cabListLoading && cabList && (() => {
                      const L = cabEditing ? cabDraft : cabList
                      const upd = cabDraftUpdate
                      return (
                      <div>
                        <div style={{ fontSize:11, color:'#888', marginBottom:10 }}>
                          {(() => {
                            const uts = L.unit_types || []
                            const totalUnits = uts.reduce((s,u)=>s+(Number(u.unit_quantity)||1),0)
                            const allPieces  = uts.reduce((s,u)=>s+([...(u.skus||[]),...(u.fillers||[])].reduce((x,r)=>x+(Number(r.quantity_per_unit)||0),0))*(Number(u.unit_quantity)||1),0)
                            const computedCabs = uts.reduce((s,u)=>s+(u.skus||[]).reduce((x,r)=>x+(Number(r.quantity_per_unit)||0),0)*(Number(u.unit_quantity)||1),0)
                            const trueCabs   = (cabEditing || L.sheet_totals?.cabinets == null) ? computedCabs : L.sheet_totals.cabinets
                            const extras     = Math.max(0, allPieces - trueCabs)
                            const kindCount = (k) => uts.filter(u => (u.kind || 'unit') === k).reduce((s,u)=>s+(Number(u.unit_quantity)||1),0)
                            const kindCabs  = (k) => uts.filter(u => (u.kind || 'unit') === k).reduce((s,u)=>s+(u.skus||[]).reduce((x,r)=>x+(Number(r.quantity_per_unit)||0),0)*(Number(u.unit_quantity)||1),0)
                            const nU = kindCount('unit'), nB = kindCount('bathroom'), nA = kindCount('amenity')
                            const kindStr = (nB > 0 || nA > 0)
                              ? `${nU} units (${kindCabs('unit').toLocaleString()} cabs)${nB > 0 ? ` · ${nB} bathrooms (${kindCabs('bathroom').toLocaleString()} cabs)` : ''}${nA > 0 ? ` · ${nA} amenities (${kindCabs('amenity').toLocaleString()} cabs)` : ''} · ${totalUnits} total areas`
                              : `${totalUnits} total units`
                            return `${uts.length} unit types · ${kindStr} · ${trueCabs.toLocaleString()} cabinets${extras > 0 ? ` · ${extras.toLocaleString()} additional pieces` : ''}`
                          })()}
                          {L.sheet_totals?.totalSF ? ` · ${L.sheet_totals.totalSF.toFixed(2)} SF countertop` : ''}
                          {L.product_line && <span style={{ color:'#3C3489', fontWeight:600, textTransform:'capitalize' }}> · {L.product_line}</span>}
                          {cabEditing && <span style={{ color:'#B8860B', fontWeight:600 }}> — EDITING</span>}
                        </div>
                        <div style={{ display: collapsed.cab ? 'none' : 'block', maxHeight:480, overflowY:'auto', border:'0.5px solid #eee', borderRadius:8 }}>
                          {(L.unit_types || []).map((ut, ui) => (
                            <div key={ui} style={{ borderBottom:'0.5px solid #eee' }}>
                              <div style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 12px', background:'#EEEDFE', fontSize:12, fontWeight:600, position:'sticky', top:0, zIndex:1 }}>
                                {cabEditing ? (
                                  <>
                                    <input value={ut.unit_type_name} onChange={e=>upd(n=>{n.unit_types[ui].unit_type_name=e.target.value})} style={{ flex:1, padding:'3px 8px', border:'0.5px solid #ccc', borderRadius:4, fontSize:12, fontWeight:600 }}/>
                                    {['unit','bathroom','amenity'].map(k => (
                                      <button key={k} onClick={()=>upd(n=>{n.unit_types[ui].kind=k})}
                                        style={{ padding:'2px 8px', fontSize:10, borderRadius:5, cursor:'pointer', textTransform:'capitalize',
                                          background:(ut.kind||'unit')===k?'#3C3489':'#fff', color:(ut.kind||'unit')===k?'#fff':'#888',
                                          border:'0.5px solid '+((ut.kind||'unit')===k?'#3C3489':'#ccc') }}>{k}</button>
                                    ))}
                                    <label style={{ fontSize:10, color:'#888' }}>Qty:</label>
                                    <input type="number" min="1" value={ut.unit_quantity} onChange={e=>upd(n=>{n.unit_types[ui].unit_quantity=Number(e.target.value)||1})} style={{ width:56, padding:'3px 6px', border:'0.5px solid #ccc', borderRadius:4, fontSize:12 }}/>
                                    <button title="Duplicate unit" onClick={()=>upd(n=>{ const cp=JSON.parse(JSON.stringify(n.unit_types[ui])); cp.unit_type_name=cp.unit_type_name+' COPY'; n.unit_types.splice(ui+1,0,cp) })} style={{ background:'none', border:'none', cursor:'pointer', color:'#3C3489', fontSize:13 }}>⧉</button>
                                    <button onClick={()=>{ if(confirm(`Delete unit ${ut.unit_type_name}?`)) upd(n=>{n.unit_types.splice(ui,1)}) }} style={{ background:'none', border:'none', cursor:'pointer', color:'#A32D2D', fontSize:14 }}>✕</button>
                                  </>
                                ) : (
                                  <>
                                    <span style={{ flex:1 }}>{ut.unit_type_name}</span>
                                    <span style={{ color:'#3C3489' }}>{ut.unit_quantity} unit{ut.unit_quantity!==1?'s':''} · {(ut.skus||[]).reduce((s,r)=>s+(Number(r.quantity_per_unit)||0),0)} cabs/unit{typeof ut.excelSubtotalSF==='number' ? ` · ${ut.excelSubtotalSF.toFixed(2)} SF` : ''}</span>
                                  </>
                                )}
                              </div>
                              {[...CAB_CATEGORIES, ...[...new Set([...(ut.skus||[]),...(ut.fillers||[])].map(r=>r.category).filter(cat=>cat&&!CAB_CATEGORIES.includes(cat)))]].map(cat => {
                                const skuRows = (ut.skus||[]).map((r,i)=>({...r,__f:false,__i:i})).filter(r=>((r.category==='TRIM'||r.category==='MOLDING')?'ACCESSORIES':(r.category||'BASES'))===cat)
                                const filRows = (ut.fillers||[]).map((r,i)=>({...r,__f:true,__i:i})).filter(r=>((r.category==='TRIM'||r.category==='MOLDING')?'ACCESSORIES':(r.category||'ACCESSORIES'))===cat)
                                const rows = [...skuRows, ...filRows]
                                if (!rows.length && !cabEditing) return null
                                return (
                                  <div key={cat}>
                                    <div style={{ display:'flex', justifyContent:'space-between', padding:'3px 12px', fontSize:10, color:'#888', fontWeight:600, letterSpacing:0.4, background:'#fafaf8' }}>
                                      {cat}
                                      {cabEditing && <button onClick={()=>upd(n=>{n.unit_types[ui].skus.push({ sku:'', quantity_per_unit:1, category:cat, hardware_count:0, location:'kitchen', hinge_side:'L/R', description:'', notes:'' })})} style={{ background:'none', border:'none', cursor:'pointer', color:'#3C3489', fontSize:10, fontWeight:600 }}>+ row</button>}
                                    </div>
                                    {rows.map((r) => (
                                      <div key={(r.__f?'f':'s')+r.__i} style={{ display:'flex', gap:10, alignItems:'center', padding:'3px 12px', fontSize:12, borderTop:'0.5px dotted #f0f0ec' }}>
                                        {cabEditing ? (
                                          <>
                                            <input type="number" min="0" value={r.quantity_per_unit} onChange={e=>upd(n=>{ const t=r.__f?n.unit_types[ui].fillers:n.unit_types[ui].skus; t[r.__i].quantity_per_unit=Number(e.target.value)||0 })} style={{ width:48, padding:'2px 6px', border:'0.5px solid #ccc', borderRadius:4, fontSize:12, textAlign:'right' }}/>
                                            <input list="leedo-sku-suggest" value={r.sku} onChange={e=>{ const s=e.target.value.toUpperCase(); fetchSkuSuggestions(s); upd(n=>{ const t=r.__f?n.unit_types[ui].fillers:n.unit_types[ui].skus; t[r.__i].sku=s; if(!r.__f){ const hw=calculateHardware(s); t[r.__i].hardware_count=hw.hardware ?? 0 } }) }} style={{ flex:1, padding:'2px 8px', border:'0.5px solid ' + (r.sku && !r.__f && isAppliance(r.sku) ? '#e0a800' : '#ccc'), borderRadius:4, fontSize:12, fontWeight:500 }}/>
                                            {!r.__f && r.sku && (
                                              <span style={{ fontSize:10, color: isAppliance(r.sku) ? '#B8860B' : '#bbb', whiteSpace:'nowrap' }}>
                                                {isAppliance(r.sku) ? 'appliance — excluded' : `${getSection(r.sku)} · HW ${calculateHardware(r.sku).hardware ?? '?'}`}
                                              </span>
                                            )}
                                            <button onClick={()=>upd(n=>{ const t=r.__f?n.unit_types[ui].fillers:n.unit_types[ui].skus; t.splice(r.__i,1) })} style={{ background:'none', border:'none', cursor:'pointer', color:'#ccc', fontSize:12 }}>✕</button>
                                          </>
                                        ) : (
                                          <>
                                            <span style={{ width:28, textAlign:'right', color:'#888' }}>{r.quantity_per_unit}</span>
                                            <span style={{ fontWeight:500, color:r.__f?'#888':'#222' }}>{r.sku}</span>
                                            {!r.__f && r.hardware_count > 0 && <span style={{ marginLeft:'auto', fontSize:10, color:'#bbb' }}>HW {r.hardware_count}</span>}
                                          </>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                )
                              })}
                            </div>
                          ))}
                          {cabEditing && (
                            <div style={{ padding:10 }}>
                              <button onClick={()=>upd(n=>{ if(!n.unit_types) n.unit_types=[]; n.unit_types.push({ unit_type_name:'NEW UNIT', unit_quantity:1, skus:[], fillers:[], is_ada:false, countertop_sf:0, excelSubtotalSF:null, excelSubtotalHW:null }) })} style={{ width:'100%', padding:8, fontSize:12, background:'#f5f5f3', border:'1px dashed #ccc', borderRadius:6, cursor:'pointer', color:'#3C3489', fontWeight:500 }}>+ Add Unit Type</button>
                            </div>
                          )}
                          {(L.unit_types || []).length === 0 && !cabEditing && (
                            <div style={{ padding:16, textAlign:'center' }}>
                              <button onClick={()=>{ const d = JSON.parse(JSON.stringify(cabList)); d.product_line = d.product_line || productLine; d.unit_types = [{ unit_type_name:'UNIT A', unit_quantity:1, kind:'unit', skus:[], fillers:[], is_ada:false, countertop_sf:0, excelSubtotalSF:null, excelSubtotalHW:null }]; setCabDraft(d); setCabEditing(true) }} style={{ padding:'10px 20px', fontSize:13, background:'#3C3489', color:'#fff', border:'none', borderRadius:8, cursor:'pointer', fontWeight:500 }}>+ Start Building — Add First Unit</button>
                            </div>
                          )}
                        </div>
                      </div>
                      )
                    })()}
                  </div>

                  {/* ── Job Files ──────────────────────────────────────── */}
                  <div style={card}>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
                      <div style={{ fontWeight:500 }}>Job Files</div>
                      <div style={{ display:'flex', gap:6, alignItems:'center' }}>
                        <select value={fileCategory} onChange={e=>setFileCategory(e.target.value)} style={{ ...inp, width:130, padding:'4px 8px', fontSize:11 }}>
                          {FILE_CATEGORIES.map(cat=><option key={cat}>{cat}</option>)}
                        </select>
                        <label style={{ padding:'4px 12px', fontSize:11, background:'#3C3489', color:'#fff', borderRadius:6, cursor:fileUploading?'wait':'pointer', fontWeight:500 }}>
                          {fileUploading ? 'Uploading...' : '+ Upload'}
                          <input type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.xlsm,.png,.jpg,.jpeg,.csv,.zip,.txt,.eml,.msg,.dwg" onChange={uploadJobFile} style={{ display:'none' }} disabled={fileUploading}/>
                        </label>
                      </div>
                    </div>
                    {filesLoading && <div style={{ fontSize:11, color:'#888' }}>Loading...</div>}
                    {!filesLoading && jobFiles.length === 0 && <div style={{ fontSize:11, color:'#bbb', padding:'6px 0' }}>No files yet — upload drawings, contracts, quotes, change orders</div>}
                    {FILE_CATEGORIES.map(cat => {
                      const catFiles = jobFiles.filter(f => f.category === cat)
                      if (!catFiles.length) return null
                      return (
                        <div key={cat} style={{ marginBottom:10 }}>
                          <div style={{ fontSize:10, color:'#888', fontWeight:600, textTransform:'uppercase', letterSpacing:0.4, marginBottom:4 }}>{cat}</div>
                          {catFiles.map(f => {
                            const parts = f.name.split('__')
                            const label = parts.length >= 3 ? parts.slice(2).join('__') : f.name
                            const sizeLabel = f.size > 0 ? (f.size > 1048576 ? (f.size/1048576).toFixed(1)+'MB' : Math.round(f.size/1024)+'KB') : ''
                            const dateLabel = f.created_at ? new Date(f.created_at).toLocaleDateString() : ''
                            const ext2 = label.split('.').pop().toLowerCase(); const icon = ext2==='pdf'?'📄':['doc','docx'].includes(ext2)?'📝':['xls','xlsx','csv'].includes(ext2)?'📊':['jpg','jpeg','png'].includes(ext2)?'🖼️':'📎'
                            return (
                              <div key={f.path} style={{ display:'flex', alignItems:'center', gap:8, padding:'5px 8px', borderRadius:6, background:'#f9f9f9', marginBottom:3 }}>
                                <span style={{ fontSize:13 }}>{icon}</span>
                                <button onClick={()=>downloadJobFile(f.path, label)} style={{ flex:1, textAlign:'left', background:'none', border:'none', cursor:'pointer', fontSize:11, color:'#3C3489', padding:0, fontWeight:500 }}>{label}</button>
                                {sizeLabel && <span style={{ fontSize:10, color:'#bbb' }}>{sizeLabel}{dateLabel ? ' · ' + dateLabel : ''}</span>}
                                <button onClick={()=>deleteJobFile(f.path)} style={{ background:'none', border:'none', cursor:'pointer', color:'#ccc', fontSize:13, lineHeight:1, padding:'0 2px' }}>✕</button>
                              </div>
                            )
                          })}
                        </div>
                      )
                    })}
                  </div>

                  

                  <div style={card}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                      <div style={{ fontWeight: 500 }}><Chevron k="rem"/>Reminders</div>
                      <button onClick={() => setShowReminderForm(true)} style={{ fontSize: 11, padding: '4px 10px', background: 'transparent', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer' }}>+ Add</button>
                    </div>
                    {!collapsed.rem && (<>
                    {showReminderForm && (
                      <div style={{ background: '#f5f5f3', borderRadius: 8, padding: 12, marginBottom: 12 }}>
                        <input type="date" value={newReminder.due_date} onChange={e => setNewReminder(p => ({ ...p, due_date: e.target.value }))} style={{ width: '100%', padding: '6px 8px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 12, marginBottom: 8 }} />
                        <select value={newReminder.reminder_type} onChange={e => setNewReminder(p => ({ ...p, reminder_type: e.target.value }))} style={{ width: '100%', padding: '6px 8px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 12, marginBottom: 8 }}>
                          <option>Bid Follow-up</option><option>Bid Deadline</option><option>Delivery Check</option><option>Payment</option><option>General</option>
                        </select>
                        <input placeholder="Message..." value={newReminder.message} onChange={e => setNewReminder(p => ({ ...p, message: e.target.value }))} style={{ width: '100%', padding: '6px 8px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 12, marginBottom: 8 }} />
                        <div style={{ display: 'flex', gap: 6 }}>
                          <button onClick={createReminder} style={{ flex: 1, padding: '6px', background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12 }}>Save</button>
                          <button onClick={() => setShowReminderForm(false)} style={{ flex: 1, padding: '6px', background: '#f5f5f3', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer', fontSize: 12 }}>Cancel</button>
                        </div>
                      </div>
                    )}
                    {(selectedJob.reminders || []).filter(r => !r.completed).map(r => (
                      <div key={r.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0', fontSize: 12, borderBottom: '0.5px solid #f0f0ec' }}>
                        <div><div>{r.message}</div><div style={{ color: '#888', fontSize: 11 }}>{r.due_date} · {r.reminder_type}</div></div>
                        <button onClick={() => completeReminder(r.id)} style={{ fontSize: 10, padding: '3px 8px', background: '#EAF3DE', color: '#3B6D11', border: 'none', borderRadius: 6, cursor: 'pointer' }}>Done</button>
                      </div>
                    ))}
                    {(selectedJob.reminders || []).filter(r => !r.completed).length === 0 && !showReminderForm && <div style={{ color: '#888', fontSize: 12 }}>No open reminders</div>}
                  </>)}
                    </div>

                  

                  {/* ── Countertop Proposal Configuration ─────────────────────── */}
                  <div style={{ ...card, borderColor: '#2D7A3A', marginBottom: 16 }}>
                    <div style={{ fontWeight: 500, fontSize: 14, marginBottom: 14 }}><Chevron k="ctp"/>Generate Countertop Proposal</div>
                    {!collapsed.ctp && (<>
                    <div style={{ margin:'0 0 14px', padding:'10px 12px', background:'#fbf9f4', border:'0.5px solid #e5ddc8', borderRadius:8 }}>
                      <label style={{ padding:'5px 12px', fontSize:11, background:'#8B6914', color:'#fff', borderRadius:6, cursor:'pointer', fontWeight:500 }}>
                        {ctQuoteUploading ? 'Parsing…' : '⬆ Upload CT Quote (Excel or PDF)'}
                        <input type="file" accept=".xlsx,.xls,.pdf" onChange={handleCtQuoteUpload} style={{ display:'none' }} disabled={ctQuoteUploading}/>
                      </label>
                      {ctQuoteResult?.summary && (
                        <div style={{ marginTop:10, fontSize:12 }}>
                          <div style={{ fontWeight:600, color:'#3B6D11' }}>✓ Parsed{ctQuoteResult.fabricator ? ' — ' + ctQuoteResult.fabricator : ''}{ctQuoteResult.summary.unitTypeCount > 0 ? ` — ${ctQuoteResult.summary.unitTypeCount} unit types · ${ctQuoteResult.summary.totalSets.toLocaleString()} sets` : ''}{ctQuoteResult.summary.totalSqft > 0 ? ` · ${ctQuoteResult.summary.totalSqft.toLocaleString()} sqft` : ''}{ctQuoteResult.summary.isOptions ? ` · ${ctQuoteResult.summary.materials.length} material OPTIONS` : ''}</div>
                          {ctQuoteResult.summary.materials.map(m2 => (
                            <div key={m2.code} style={{ display:'flex', alignItems:'center', gap:8, fontSize:11, color:'#555', paddingTop:3 }}>
                              <span style={{ flex:1 }}>{m2.code}: {m2.items} items · ${m2.total.toLocaleString()}{m2.sqft ? ` · ${m2.sqft.toLocaleString()} sqft` : ''}</span>
                              <button onClick={()=>setCtGross(String(m2.total))} style={{ padding:'2px 10px', fontSize:10, background: String(ctGross)===String(m2.total) ? '#2D7A3A' : '#fff', color: String(ctGross)===String(m2.total) ? '#fff' : '#2D7A3A', border:'0.5px solid #2D7A3A', borderRadius:5, cursor:'pointer' }}>{String(ctGross)===String(m2.total) ? '✓ Using' : 'Use for pricing'}</button>
                            </div>
                          ))}
                          {!ctQuoteResult.summary.isOptions && <div style={{ fontWeight:600, marginTop:4 }}>Grand total: ${ctQuoteResult.summary.grandTotal.toLocaleString()}</div>}
                          {ctQuoteResult.summary.isOptions && <div style={{ fontSize:11, color:'#8B6914', marginTop:4 }}>Options are alternatives — pick one above for pricing (not summed)</div>}
                          {ctQuoteResult.recorded ? <div style={{ color:'#2D7A3A', marginTop:2 }}>✓ Saved to quote history</div> : <div style={{ color:'#A32D2D', marginTop:2 }}>⚠ Quote history NOT saved</div>}
                        </div>
                      )}
                      {ctQuoteResult?.error && <div style={{ marginTop:8, fontSize:12, color:'#A32D2D' }}>✗ {ctQuoteResult.error}</div>}
                    </div>
                    <div style={{ marginBottom: 12 }}>
                      <label style={lbl}>Sender</label>
                      <select value={ctSender} onChange={e=>setCtSender(e.target.value)} style={{ ...inp, width: 180, marginBottom: 12 }}>
                        <option value="Cole">Cole Isetts — Sales Representative</option>
                        <option value="Pam">Pamela Isetts — President</option>
                        <option value="MDSG">MDSG Team</option>
                      </select>
                      <label style={lbl}>Waste Factor %</label>
                      <div style={{ display:'flex', gap:6, alignItems:'center', marginBottom:12 }}>
                        <input type="number" min="0" max="30" value={ctWastePct} onChange={e=>setCtWastePct(Number(e.target.value))} style={{ ...inp, width:70 }}/>
                        <span style={{ fontSize:11, color:'#2D7A3A' }}>{ctWastePct}% added to net SF for order quantity</span>
                      </div>
                      {savedQuotes.filter(q => q.quote_type === 'countertops').length > 0 && (
                        <div style={{ marginBottom: 10 }}>
                          <label style={lbl}>Price From Saved CT Quote</label>
                          <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                            {savedQuotes.filter(q => q.quote_type === 'countertops').map(q => (
                              <button key={q.id} onClick={()=>setCtGross(String(q.grand_total || q.gross_amount || ''))} style={{ padding:'5px 12px', fontSize:11, borderRadius:6, cursor:'pointer', background: String(ctGross)===String(q.grand_total || q.gross_amount) ? '#8B6914' : '#f5f5f3', color: String(ctGross)===String(q.grand_total || q.gross_amount) ? '#fff' : '#555', border:'0.5px solid #ddd' }}>
                                {String(ctGross)===String(q.grand_total || q.gross_amount) ? '✓ ' : ''}{q.manufacturer} · ${Number(q.grand_total || q.gross_amount || 0).toLocaleString(undefined,{maximumFractionDigits:0})} · {fmtD(q.created_at)}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                      <label style={lbl}>Countertop Material Cost ($ — from supplier quote)</label>
                      <input type="number" min="0" value={ctGross} placeholder="e.g. 48000" onChange={e=>setCtGross(e.target.value)} style={{ ...inp, width:160, marginBottom:10 }}/>
                      <label style={lbl}>Gross Margin %</label>
                      <div style={{ display:'flex', gap:6, alignItems:'center', marginBottom:10 }}>
                        <input type="number" step="1" min="0" max="60" value={ctMargin} onChange={e=>setCtMargin(e.target.value)} style={{ ...inp, width:70 }}/>
                        {Number(ctGross)>0 && Number(ctMargin)>0 && <span style={{ fontSize:11, color:'#2D7A3A', fontWeight:500 }}>→ sell ≈ ${Math.round(Number(ctGross)/(1-Number(ctMargin)/100)).toLocaleString()}</span>}
                      </div>
                      <div style={{ display:'flex', gap:6, marginBottom:10 }}>
                        {[15,20,25,30,35].map(m=><button key={m} onClick={()=>setCtMargin(m)} style={{ padding:'3px 9px', fontSize:11, borderRadius:6, cursor:'pointer', background:Number(ctMargin)===m?'#2D7A3A':'#f5f5f3', color:Number(ctMargin)===m?'#fff':'#555', border:'0.5px solid #ddd' }}>{m}%</button>)}
                      </div>
                      <div style={{ display:'flex', gap:16, flexWrap:'wrap', marginBottom:10 }}>
                        <label style={{ display:'flex', alignItems:'center', gap:6, cursor:'pointer', fontSize:12, color:'#555' }}>
                          <input type="checkbox" checked={hideUnitPricing} onChange={e=>setHideUnitPricing(e.target.checked)} style={{ width:14, height:14 }}/> Hide unit breakdown
                        </label>
                        <label style={{ display:'flex', alignItems:'center', gap:6, cursor:'pointer', fontSize:12, color:'#555' }}>
                          <input type="checkbox" checked={totalOnly} onChange={e=>setTotalOnly(e.target.checked)} style={{ width:14, height:14 }}/> Grand total only
                        </label>
                        <label style={{ display:'flex', alignItems:'center', gap:6, cursor:'pointer', fontSize:12, color:'#555' }}>
                          <input type="checkbox" checked={brandAs==='greenworks'} onChange={e=>setBrandAs(e.target.checked?'greenworks':'mdsg')} style={{ width:14, height:14 }}/> Greenworks umbrella
                        </label>
                      </div>
                      <label style={lbl}>Notes (appears on proposal)</label>
                      <textarea value={ctNotes} onChange={e=>setCtNotes(e.target.value)} style={{ width:'100%', padding:'7px 10px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11, height:52, resize:'vertical', fontFamily:'inherit', marginBottom:4 }}/>
                    </div>
                    {[
                      ['includedInBid', 'Included in Bid', 38],
                      ['assembly', 'Assembly, Staging & Installation', 44],
                      ['notIncluded', 'Not Included in Bid (one bullet per line)', 80],
                      ['bottomNotes', 'Proposal Notes', 44],
                    ].map(([key, label, h]) => (
                      <div key={key} style={{ marginBottom: 10 }}>
                        <label style={lbl}>{label}</label>
                        <textarea value={ctBidSections[key]} onChange={e=>setCtBidSections(p=>({...p,[key]:e.target.value}))} style={{ width:'100%', padding:'7px 10px', border:'0.5px solid #ccc', borderRadius:6, fontSize:11, height:h, resize:'vertical', fontFamily:'inherit' }}/>
                      </div>
                    ))}
                    <button onClick={()=>setCtBidSections(DEFAULT_CT_BID_SECTIONS)} style={{ marginBottom:10, padding:'3px 10px', fontSize:11, borderRadius:6, cursor:'pointer', background:'#f5f5f3', color:'#555', border:'0.5px solid #ddd' }}>↺ Reset to defaults</button>
                      <button onClick={generateCtProposal} disabled={ctGenerating} style={{ width: '100%', padding: 10, marginTop: 12, background: ctGenerating ? '#888' : '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: ctGenerating ? 'default' : 'pointer', fontSize: 13, fontWeight: 500 }}>
                        {ctGenerating ? 'Generating…' : '⬇ Generate Countertop Proposal PDF'}
                      </button>
                  </>)}
                    </div>

                  <div style={card}>
                    <div style={{ fontWeight: 500, marginBottom: 12 }}><Chevron k="log"/>Activity Log</div>
                    {!collapsed.log && (selectedJob.activity_log || []).sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 12).map(log => (
                      <div key={log.id} style={{ paddingBottom: 10, marginBottom: 10, borderBottom: '0.5px solid #f0f0ec', fontSize: 12 }}>
                        <div>{log.action}</div>
                        <div style={{ color: '#888', fontSize: 11, marginTop: 2, display:'flex', alignItems:'center' }}>{log.user_name} · {new Date(log.created_at).toLocaleDateString()}
                          <button onClick={async()=>{ if(!confirm('Remove this log entry?')) return; await supabase.from('activity_log').delete().eq('id', log.id); setSelectedJob({ ...selectedJob, activity_log: (selectedJob.activity_log||[]).filter(l=>l.id!==log.id) }) }} style={{ marginLeft:'auto', background:'none', border:'none', cursor:'pointer', color:'#ccc', fontSize:11 }}>✕</button>
                        </div>
                      </div>
                    ))}
                    {(selectedJob.activity_log || []).length === 0 && <div style={{ color: '#888', fontSize: 12 }}>No activity yet</div>}
                  </div>

                  
                </div>
              </div>
            </div>
          )}

          {/* SPEC LIBRARY VIEW */}
          {view === 'library' && (
            <div>
              <div style={card}>
                <div style={{ fontWeight:500, marginBottom:6 }}>Spec Literature Library</div>
                <div style={{ fontSize:12, color:'#888', marginBottom:10 }}>Upload manufacturer literature PDFs once, tag them with the specs they cover (door styles, Framed/Frameless, drawer box types). When generating a proposal, sheets matching that job's specs highlight automatically for attachment.</div>
                <label style={{ padding:'6px 14px', fontSize:12, background:'#3C3489', color:'#fff', borderRadius:6, cursor:'pointer', fontWeight:500 }}>
                  {libUploading ? 'Uploading…' : '⬆ Upload Literature PDF(s)'}
                  <input type="file" accept=".pdf" multiple style={{ display:'none' }} disabled={libUploading} onChange={async e=>{
                    const files = Array.from(e.target.files || []); if (!files.length) return
                    setLibUploading(true)
                    for (const f of files) {
                      const clean = f.name.replace(/[^a-zA-Z0-9._-]/g, '_')
                      const path = `_speclib/${Date.now()}_${clean}`
                      const { error } = await supabase.storage.from('job-files').upload(path, f)
                      if (error) { alert(`${f.name}: ${error.message}`); continue }
                      await supabase.from('spec_library').insert({ title: f.name.replace(/\.pdf$/i, '').replace(/_/g, ' '), file_path: path, tags: '' })
                    }
                    await loadSpecLib(); setLibUploading(false); e.target.value = ''
                  }}/>
                </label>
              </div>
              <div style={card}>
                {specLib.map(r => (
                  <div key={r.id} style={{ display:'flex', gap:8, alignItems:'center', padding:'5px 0', borderTop:'0.5px dotted #eee', fontSize:12 }}>
                    <input defaultValue={r.title} onBlur={async e=>{ if (e.target.value !== r.title) { await supabase.from('spec_library').update({ title: e.target.value }).eq('id', r.id); loadSpecLib() } }} style={{ flex:1, padding:'4px 8px', border:'0.5px solid #e5e5e5', borderRadius:5, fontSize:12, fontWeight:600 }}/>
                    <input defaultValue={r.tags} placeholder="tags: Shaker, Framed, dovetail…" onBlur={async e=>{ if (e.target.value !== r.tags) { await supabase.from('spec_library').update({ tags: e.target.value }).eq('id', r.id); loadSpecLib() } }} style={{ flex:1.4, padding:'4px 8px', border:'0.5px solid #e5e5e5', borderRadius:5, fontSize:11, color:'#3C3489' }}/>
                    <button onClick={async()=>{ const { data } = await supabase.storage.from('job-files').createSignedUrl(r.file_path, 300); if (data?.signedUrl) window.open(data.signedUrl, '_blank') }} style={{ padding:'3px 10px', fontSize:10, background:'#f5f5f3', border:'0.5px solid #ddd', borderRadius:5, cursor:'pointer' }}>View</button>
                    <button onClick={async()=>{ if(!confirm(`Delete "${r.title}" from the library?`)) return; await supabase.storage.from('job-files').remove([r.file_path]); await supabase.from('spec_library').delete().eq('id', r.id); loadSpecLib() }} style={{ background:'none', border:'none', cursor:'pointer', color:'#A32D2D', fontSize:13 }}>✕</button>
                  </div>
                ))}
                {specLib.length === 0 && <div style={{ fontSize:12, color:'#999' }}>Nothing yet — upload the Leedo literature PDFs to start.</div>}
              </div>
            </div>
          )}

          {/* FINANCIALS VIEW */}
          {view === 'financials' && (() => {
            const rows = jobs.filter(j => !j.is_test && ['Awarded','Shop Drawings','Ordered','Delivered','Closeout'].includes(j.stage)).map(j => {
              const inv = j.invoices || [], cos = j.change_orders || []
              const contract = Number(j.os_bid_value) || Number(j.bid_value) || 0
              const coA = cos.filter(c => c[3]==='approved').reduce((s,c)=>s+(Number(c[2])||0),0)
              const coP = cos.filter(c => c[3]==='pending').reduce((s,c)=>s+(Number(c[2])||0),0)
              const revised = contract + coA
              const billed = inv.reduce((s,i)=>s+(Number(i[2])||0),0)
              const paid = inv.filter(i=>i[3]==='paid').reduce((s,i)=>s+(Number(i[2])||0),0)
              return { j, contract, coA, coP, revised, billed, paid, ar: billed-paid, toBill: revised-billed }
            }).sort((a,b)=>b.revised-a.revised)
            const T = (k) => rows.reduce((s,r)=>s+r[k],0)
            return (
              <div>
                <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:10, marginBottom:14 }}>
                  {[['Under Contract (revised)', T('revised'), '#3C3489'], ['Billed to Date', T('billed'), '#1B5EA6'], ['Collected', T('paid'), '#2D7A3A'], ['AR Outstanding', T('ar'), T('ar') > 0 ? '#A32D2D' : '#2D7A3A'], ['Left to Bill (backlog)', T('toBill'), '#8B6914']].map(([l, v, c2]) => (
                    <div key={l} style={{ ...card, marginBottom:0, textAlign:'center' }}>
                      <div style={{ fontSize:10, color:'#888', fontWeight:600, textTransform:'uppercase', letterSpacing:0.3 }}>{l}</div>
                      <div style={{ fontSize:19, fontWeight:700, color:c2, marginTop:4 }}>{fmt(v)}</div>
                    </div>
                  ))}
                </div>
                {T('coP') > 0 && <div style={{ fontSize:12, color:'#8B6914', marginBottom:10 }}>⏳ {fmt(T('coP'))} in pending change orders (not counted until approved)</div>}
                <div style={card}>
                  <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr 1fr 1fr 1fr 1fr 1fr', gap:6, fontSize:12 }}>
                    {['JOB','CONTRACT','+COs','BILLED','PAID','AR','TO BILL'].map(h => <div key={h} style={{ fontWeight:600, color:'#888', fontSize:10 }}>{h}</div>)}
                    {rows.map(r => (
                      <React.Fragment key={r.j.id}>
                        <div onClick={()=>{ setSelectedJob(r.j); setView('job-detail') }} style={{ fontWeight:600, cursor:'pointer', color:'#1B5EA6' }}>{r.j.name}</div>
                        <div>{fmt(r.contract)}</div>
                        <div style={{ color: r.coA > 0 ? '#2D7A3A' : '#bbb' }}>{r.coA !== 0 ? fmt(r.coA) : '—'}</div>
                        <div>{fmt(r.billed)}</div>
                        <div style={{ color:'#2D7A3A' }}>{fmt(r.paid)}</div>
                        <div style={{ color: r.ar > 0 ? '#A32D2D' : '#bbb', fontWeight: r.ar > 0 ? 700 : 400 }}>{r.ar > 0 ? fmt(r.ar) : '—'}</div>
                        <div style={{ color:'#8B6914' }}>{r.toBill > 0 ? fmt(r.toBill) : '—'}</div>
                      </React.Fragment>
                    ))}
                  </div>
                  {rows.length === 0 && <div style={{ fontSize:12, color:'#999' }}>No jobs under contract yet — awarded jobs appear here with their billing.</div>}
                </div>
              </div>
            )
          })()}

          {/* REPORTS VIEW */}
          {view === 'reports' && (() => {
            const jobs_all = jobs; const jobsR = jobs.filter(j => !j.is_test)
            const OPEN_ST = ['RFQ', 'Open Proposals', 'On Hold']
            const WON_ST  = ['Awarded', 'Shop Drawings', 'Ordered', 'Delivered', 'Closeout']
            const monthKey = (d) => d ? String(d).substring(0, 7) : null
            const months = []
            for (let i = 5; i >= 0; i--) { const d = new Date(); d.setMonth(d.getMonth() - i); months.push(d.toISOString().substring(0, 7)) }
            const byMonth = months.map(m => ({
              m,
              won:  jobsR.filter(j => WON_ST.includes(j.stage) && monthKey(j.awarded_at) === m),
              bids: jobsR.filter(j => monthKey(j.bid_due_date) === m),
            }))
            const maxBar = Math.max(1, ...byMonth.map(x => Math.max(x.won.reduce((s,j)=>s+effVal(j),0), x.bids.reduce((s,j)=>s+effVal(j),0))))
            const owners = [...new Set(jobsR.map(j => j.owner).filter(Boolean))]
            const ownerRows = owners.map(o => {
              const js = jobsR.filter(j => j.owner === o)
              const won = js.filter(j => WON_ST.includes(j.stage)), lost = js.filter(j => j.stage === 'Lost')
              return { o, open: js.filter(j => OPEN_ST.includes(j.stage)), won, lost,
                openVal: js.filter(j => OPEN_ST.includes(j.stage)).reduce((s,j)=>s+effVal(j),0),
                wonVal: won.reduce((s,j)=>s+effVal(j),0),
                wr: (won.length+lost.length) > 0 ? Math.round(100*won.length/(won.length+lost.length)) : null }
            }).sort((a,b)=>b.wonVal-a.wonVal)
            const marginRows = jobsR.filter(j => Number(j.os_margin_pct) > 0 && !['Lost'].includes(j.stage))
              .sort((a,b)=>Number(b.os_bid_value||0)-Number(a.os_bid_value||0)).slice(0, 12)
            const aging = jobsR.filter(j => OPEN_ST.includes(j.stage) && j.bid_due_date && j.bid_due_date < todayISO)
              .map(j => ({ ...j, __d: daysPast(j.bid_due_date) })).sort((a,b)=>b.__d-a.__d).slice(0, 10)
            const emailStats = null
            return (
              <div>
                <div style={card}>
                  <div style={{ fontWeight: 500, marginBottom: 12 }}>Won $ vs Bid $ — last 6 months <span style={{ fontSize:10, color:'#999', fontWeight:400 }}>(won by award date · bids by bid-due date — award dates start counting from today forward)</span></div>
                  {byMonth.map(x => {
                    const wonV = x.won.reduce((s,j)=>s+effVal(j),0), bidV = x.bids.reduce((s,j)=>s+effVal(j),0)
                    return (
                      <div key={x.m} style={{ marginBottom: 8 }}>
                        <div style={{ fontSize: 11, color:'#888', marginBottom: 2 }}>{x.m}</div>
                        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                          <div style={{ height: 12, width: `${Math.round(70*bidV/maxBar)}%`, minWidth: bidV>0?4:0, background:'#b9cbe0', borderRadius: 3 }}/>
                          <span style={{ fontSize: 10, color:'#1B5EA6' }}>{bidV>0?fmt(bidV):''} bid ({x.bids.length})</span>
                        </div>
                        <div style={{ display:'flex', alignItems:'center', gap:8, marginTop:2 }}>
                          <div style={{ height: 12, width: `${Math.round(70*wonV/maxBar)}%`, minWidth: wonV>0?4:0, background:'#2D7A3A', borderRadius: 3 }}/>
                          <span style={{ fontSize: 10, color:'#2D7A3A' }}>{wonV>0?fmt(wonV):''} won ({x.won.length})</span>
                        </div>
                      </div>
                    )
                  })}
                </div>
                <div style={card}>
                  <div style={{ fontWeight: 500, marginBottom: 10 }}>Team Performance</div>
                  <div style={{ display:'grid', gridTemplateColumns:'120px 1fr 1fr 1fr 60px', gap:6, fontSize:12 }}>
                    <div style={{ fontWeight:600, color:'#888', fontSize:10 }}>OWNER</div><div style={{ fontWeight:600, color:'#888', fontSize:10 }}>OPEN PIPELINE</div><div style={{ fontWeight:600, color:'#888', fontSize:10 }}>WON</div><div style={{ fontWeight:600, color:'#888', fontSize:10 }}>LOST</div><div style={{ fontWeight:600, color:'#888', fontSize:10 }}>WIN %</div>
                    {ownerRows.map(r => (
                      <React.Fragment key={r.o}>
                        <div style={{ fontWeight:600 }}>{r.o}</div>
                        <div>{r.open.length} · {fmt(r.openVal)}</div>
                        <div style={{ color:'#2D7A3A' }}>{r.won.length} · {fmt(r.wonVal)}</div>
                        <div style={{ color:'#A32D2D' }}>{r.lost.length}</div>
                        <div>{r.wr !== null ? r.wr + '%' : '—'}</div>
                      </React.Fragment>
                    ))}
                  </div>
                </div>
                <div style={card}>
                  <div style={{ fontWeight: 500, marginBottom: 10 }}>Margin Leaders <span style={{ fontSize:10, color:'#999', fontWeight:400 }}>(OS-generated proposals, active jobs)</span></div>
                  {marginRows.map(j => (
                    <div key={j.id} onClick={()=>{ setSelectedJob(j); setView('job-detail') }} style={{ display:'flex', gap:10, fontSize:12, padding:'4px 0', borderTop:'0.5px dotted #eee', cursor:'pointer' }}>
                      <span style={{ flex:1, fontWeight:500 }}>{j.name}</span>
                      <span style={{ color:'#888' }}>{j.gc_name || ''}</span>
                      <span style={{ fontWeight:600 }}>{fmt(Number(j.os_bid_value)||0)}</span>
                      <span style={{ fontWeight:700, color: Number(j.os_margin_pct) >= 0.2 ? '#2D7A3A' : '#e0a800', width:52, textAlign:'right' }}>{fmtPct(Number(j.os_margin_pct))}</span>
                    </div>
                  ))}
                  {marginRows.length === 0 && <div style={{ fontSize:12, color:'#999' }}>Generate proposals to populate — margins record automatically.</div>}
                </div>
                <div style={card}>
                  <div style={{ fontWeight: 500, marginBottom: 10 }}>Stale Open Bids <span style={{ fontSize:10, color:'#999', fontWeight:400 }}>(past bid due date)</span></div>
                  {aging.map(j => (
                    <div key={j.id} onClick={()=>{ setSelectedJob(j); setView('job-detail') }} style={{ display:'flex', gap:10, fontSize:12, padding:'4px 0', borderTop:'0.5px dotted #eee', cursor:'pointer' }}>
                      <span style={{ flex:1, fontWeight:500 }}>{(j.priority==='hot')?'🔥 ':''}{j.name}</span>
                      <span style={{ color:'#888' }}>{j.gc_name || ''}</span>
                      <span style={{ color:'#A32D2D', fontWeight:600 }}>{j.__d}d overdue</span>
                    </div>
                  ))}
                  {aging.length === 0 && <div style={{ fontSize:12, color:'#2D7A3A' }}>✓ Nothing stale — every open bid is inside its due date.</div>}
                </div>
              </div>
            )
          })()}

          {/* CONTRACTORS VIEW */}
          {view === 'contacts' && (
            <div>
              {(() => {
                const BIDDING = ['RFQ', 'Open Proposals', 'On Hold']
                const WONISH  = ['Awarded', 'Shop Drawings', 'Ordered', 'Delivered', 'Closeout']
                const groups = {}
                jobs.forEach(j => {
                  const gc = (j.gc_name || '').trim() || '(No GC on record)'
                  groups[gc] = groups[gc] || []
                  groups[gc].push(j)
                })
                const rows = Object.entries(groups).map(([gc, js]) => {
                  const won = js.filter(j => WONISH.includes(j.stage))
                  const lost = js.filter(j => j.stage === 'Lost')
                  const bidding = js.filter(j => BIDDING.includes(j.stage))
                  const awardedVal = won.reduce((s, j) => s + effVal(j), 0)
                  const pipelineVal = bidding.reduce((s, j) => s + effVal(j), 0)
                  const contacts = [...new Set(js.map(j => j.gc_contact).filter(Boolean))]
                  const phones   = [...new Set(js.map(j => j.gc_phone).filter(Boolean))]
                  const emails   = [...new Set(js.map(j => j.gc_email).filter(Boolean))]
                  const lastContact = js.map(j => j.last_contacted_at).filter(Boolean).sort().pop() || null
                  const winDen = won.length + lost.length
                  return { gc, js, won, lost, bidding, awardedVal, pipelineVal, contacts, phones, emails, lastContact, winRate: winDen > 0 ? Math.round(100 * won.length / winDen) : null }
                }).sort((a, b) => (b.awardedVal + b.pipelineVal) - (a.awardedVal + a.pipelineVal))
                return rows.map(r => (
                  <div key={r.gc} style={{ ...card, marginBottom: 12 }}>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, flexWrap: 'wrap' }}>
                      <div style={{ fontWeight: 600, fontSize: 15 }}>{r.gc}</div>
                      <span style={{ fontSize: 11, color: '#888' }}>{r.contacts.join(' · ')}</span>
                      <span style={{ fontSize: 11, color: '#888' }}>{r.phones.join(' · ')}</span>
                      <span style={{ fontSize: 11, color: '#1B5EA6' }}>{r.emails.join(' · ')}</span>
                    </div>
                    <div style={{ display: 'flex', gap: 20, marginTop: 8, fontSize: 12, flexWrap: 'wrap' }}>
                      <span><b>{r.bidding.length}</b> bidding {r.pipelineVal > 0 ? `(${fmt(r.pipelineVal)})` : ''}</span>
                      <span><b>{r.won.length}</b> won {r.awardedVal > 0 ? `(${fmt(r.awardedVal)})` : ''}</span>
                      <span><b>{r.lost.length}</b> lost</span>
                      {r.winRate !== null && <span>win rate <b>{r.winRate}%</b></span>}
                      {r.lastContact && <span style={{ color: '#888' }}>last contact {r.lastContact}</span>}
                    </div>
                    <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
                      {r.js.sort((a, b) => (a.stage === 'Lost') - (b.stage === 'Lost')).map(j => (
                        <button key={j.id} onClick={() => { setSelectedJob(j); setView('job-detail') }} style={{ padding: '4px 10px', fontSize: 11, borderRadius: 6, cursor: 'pointer', border: '0.5px solid #ddd', background: j.stage === 'Lost' ? '#faf5f5' : '#f5f5f3', color: j.stage === 'Lost' ? '#A32D2D' : '#333' }}>
                          {(j.priority === 'hot') ? '🔥 ' : ''}{j.name} <span style={{ color: '#999' }}>· {j.stage}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                ))
              })()}
            </div>
          )}

          {/* SHIPMENTS VIEW */}
          {view === 'shipments' && (
            <div>
              {delayedCount > 0 && (
                <div style={{ background: '#FCEBEB', border: '0.5px solid #E24B4A', borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontSize: 12, color: '#A32D2D' }}>
                  ⚠ {delayedCount} shipment{delayedCount > 1 ? 's' : ''} marked as delayed
                </div>
              )}
              <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, overflow: 'hidden' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                  <thead><tr style={{ background: '#f5f5f3' }}>
                    {['Job', 'GC', 'Load', 'Carrier', 'Tracking #', 'Expected', 'Floors / Units', 'Cabinets', 'Status', ''].map(h => (
                      <th key={h} style={{ padding: '10px 12px', textAlign: 'left', fontWeight: 500, color: '#888', borderBottom: '0.5px solid #e5e5e0', fontSize: 10, textTransform: 'uppercase', letterSpacing: 0.4 }}>{h}</th>
                    ))}
                  </tr></thead>
                  <tbody>
                    {allActiveShipments.length === 0
                      ? <tr><td colSpan={10} style={{ padding: 24, textAlign: 'center', color: '#888' }}>No active shipments</td></tr>
                      : allActiveShipments.map(s => (
                          <tr key={s.id} style={{ borderBottom: '0.5px solid #f0f0ec', background: s.status === 'Delayed' ? '#FFF8F0' : '' }}>
                            <td style={{ padding: '10px 12px', fontWeight: 500, cursor: 'pointer', color: '#3C3489' }} onClick={() => { const job = jobs.find(j => j.id === s.job_id); if (job) { setSelectedJob(job); setView('job-detail') } }}>{s.jobs?.name || '—'}</td>
                            <td style={{ padding: '10px 12px', color: '#555' }}>{s.jobs?.gc_name || '—'}</td>
                            <td style={{ padding: '10px 12px', color: '#555' }}>{s.load_number} of {s.total_loads}</td>
                            <td style={{ padding: '10px 12px', color: '#555' }}>{s.carrier}</td>
                            <td style={{ padding: '10px 12px', color: '#555', fontFamily: 'monospace', fontSize: 11 }}>{s.tracking_number || '—'}</td>
                            <td style={{ padding: '10px 12px', color: s.status === 'Delayed' ? '#A32D2D' : '#555', fontWeight: s.status === 'Delayed' ? 500 : 400 }}>{s.scheduled_date || '—'}</td>
                            <td style={{ padding: '10px 12px', color: '#555' }}>{s.floors_covered || '—'}</td>
                            <td style={{ padding: '10px 12px', color: '#555' }}>{s.cabinet_count ? Number(s.cabinet_count).toLocaleString() : '—'}</td>
                            <td style={{ padding: '10px 12px' }}><ShipmentBadge status={s.status} /></td>
                            <td style={{ padding: '10px 12px' }}>
                              <select value={s.status} onChange={e => updateShipmentStatus(s.id, e.target.value, s.job_id)} style={{ padding: '4px 6px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 11, cursor: 'pointer' }}>
                                <option>Scheduled</option><option>In Transit</option><option>Delivered</option><option>Delayed</option>
                              </select>
                            </td>
                          </tr>
                        ))
                    }
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* AGENT PIPELINE — new unified dark UI, always mounted so state survives navigation */}
          <div style={{ display: view === 'agent-pipeline' ? 'block' : 'none' }}>
            <AgentPipeline jobs={jobs} onComplete={() => { loadJobs(); setView('jobs') }} />
          </div>

          {/* UPLOAD MFR QUOTE */}
          {view === 'takeoff' && (
            <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, padding: 32, textAlign: 'center', maxWidth: 500, margin: '0 auto' }}>
              <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 8 }}>Upload Manufacturer Quote PDF</div>
              <div style={{ fontSize: 12, color: '#888', marginBottom: 24 }}>Select a job then upload the PDF. Claude extracts all unit types, SKUs, and pricing automatically.</div>
              <select onChange={e => setSelectedJob(jobs.find(j => j.id === e.target.value))} style={{ width: '100%', padding: '8px 10px', border: '0.5px solid #ccc', borderRadius: 6, fontSize: 13, marginBottom: 16 }}>
                <option value="">Choose a job...</option>
                {jobs.map(j => <option key={j.id} value={j.id}>{j.name}</option>)}
              </select>
              {selectedJob && (
                <label style={{ display: 'block', border: '1.5px dashed #ccc', borderRadius: 8, padding: 32, cursor: 'pointer', background: '#fafaf8' }}>
                  <div style={{ fontSize: 13, color: '#555' }}>{quoteUploading ? 'AI is parsing your quote...' : 'Drop PDF here or click to upload'}</div>
                  <div style={{ fontSize: 11, color: '#999', marginTop: 4 }}>Leedo · Skyline · SMART · Ukon</div>
                  <input type="file" accept=".pdf,.xlsx,.xlsm" onChange={handleQuoteUpload} style={{ display: 'none' }} disabled={quoteUploading} />
                </label>
              )}
            </div>
          )}

          {/* REMINDERS */}
          {view === 'reminders' && (
            <div style={{ background: '#fff', border: '0.5px solid #e5e5e0', borderRadius: 10, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead><tr style={{ background: '#f5f5f3' }}>
                  {['Due Date', 'Job', 'Type', 'Message', 'Assigned To', ''].map(h => (
                    <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 500, color: '#888', borderBottom: '0.5px solid #e5e5e0', fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.4 }}>{h}</th>
                  ))}
                </tr></thead>
                <tbody>
                  {visibleReminders.length === 0
                    ? <tr><td colSpan={6} style={{ padding: 24, textAlign: 'center', color: '#888' }}>No upcoming reminders</td></tr>
                    : visibleReminders.map(r => {
                        const isOverdue = r.due_date <= new Date().toISOString().split('T')[0]
                        return (
                          <tr key={r.id} style={{ borderBottom: '0.5px solid #f0f0ec', background: isOverdue ? '#FCEBEB' : '' }}>
                            <td style={{ padding: '10px 14px', fontWeight: 500, color: isOverdue ? '#A32D2D' : '#333' }}>{r.due_date}</td>
                            <td style={{ padding: '10px 14px' }}>{r.jobs?.name || '—'}</td>
                            <td style={{ padding: '10px 14px', color: '#555' }}>{r.reminder_type}</td>
                            <td style={{ padding: '10px 14px', color: '#555' }}>{r.message}</td>
                            <td style={{ padding: '10px 14px', color: '#555' }}>{r.assigned_to}</td>
                            <td style={{ padding: '10px 14px' }}><button onClick={() => completeReminder(r.id)} style={{ fontSize: 10, padding: '3px 10px', background: '#EAF3DE', color: '#3B6D11', border: 'none', borderRadius: 6, cursor: 'pointer' }}>Mark Done</button></td>
                          </tr>
                        )
                      })
                  }
                </tbody>
              </table>
            </div>
          )}

        </div>
      </div>

      {/* New Job Modal */}
      {showNewJob && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
          <div style={{ background: '#fff', borderRadius: 12, padding: 28, width: 440, maxHeight: '80vh', overflowY: 'auto' }}>
            <div style={{ fontWeight: 500, fontSize: 15, marginBottom: 20 }}>New Job</div>
            {[{ label: 'Project Name *', key: 'name' }, { label: 'General Contractor', key: 'gc_name' }, { label: 'Address', key: 'address' }, { label: 'City', key: 'city' }].map(field => (
              <div key={field.key} style={{ marginBottom: 14 }}>
                <label style={lbl}>{field.label}</label>
                <input value={newJob[field.key] || ''} onChange={e => setNewJob(p => ({ ...p, [field.key]: e.target.value }))} style={inp} />
              </div>
            ))}
            {[{ label: 'Owner', key: 'owner', options: ['Cole', 'Pam', 'Blake'] }, { label: 'Manufacturer', key: 'manufacturer', options: ['TBD', 'Leedo', 'Skyline', 'SMART', 'Ukon', 'Multiple'] }].map(field => (
              <div key={field.key} style={{ marginBottom: 14 }}>
                <label style={lbl}>{field.label}</label>
                <select value={newJob[field.key]} onChange={e => setNewJob(p => ({ ...p, [field.key]: e.target.value }))} style={inp}>
                  {field.options.map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
            ))}
            <div style={{ marginBottom: 20 }}>
              <label style={lbl}>Bid Due Date</label>
              <input type="date" value={newJob.bid_due_date || ''} onChange={e => setNewJob(p => ({ ...p, bid_due_date: e.target.value }))} style={inp} />
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={createJob} style={{ flex: 1, padding: 8, background: '#3C3489', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 13 }}>Create Job</button>
              <button onClick={() => setShowNewJob(false)} style={{ flex: 1, padding: 8, background: '#f5f5f3', border: '0.5px solid #ccc', borderRadius: 6, cursor: 'pointer', fontSize: 13 }}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
